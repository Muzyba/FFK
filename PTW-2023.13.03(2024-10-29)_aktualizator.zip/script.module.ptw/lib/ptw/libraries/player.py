# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import codecs
import gzip
import json
import os
import re
import sys
from urllib.parse import quote_plus, unquote_plus

import six
import xbmc

from ptw.libraries import bookmarks
from ptw.libraries import cleantitle
from ptw.libraries import control
from ptw.libraries.log_utils import log, fflog
from ptw.libraries import playcount
from ptw.libraries import trakt



class player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.totalTime = None
        self.currentTime = None
        self.content = None
        self.title = None
        self.year = None
        self.name = None
        self.season = None
        self.episode = None
        self.DBID = None
        self.imdb = None
        self.tvdb = None
        self.tmdb = None
        self.ids = None
        self.offset = None
        self.is_active = True


    # większość wywowałań tej funkcji wstawia zamiast tmdb "tvdb"
    def run(self, title, year, season, episode, imdb, tvdb, tmdb, url, meta, handle=None):
        try:
            control.execute('Dialog.Close(notification,true)')
            control.sleep0(200)
            control.dialog.notification('FanFilm', 'uruchamianie odtwarzania ...', time=1500, sound=False)
            control.sleep(300)

            self.totalTime = 0
            self.currentTime = 0

            self.content = "movie" if season is None or episode is None else "episode"

            self.title = title
            self.year = year
            self.name = (
                quote_plus(title) + quote_plus(" (%s)" % year)
                if self.content == "movie"
                else quote_plus(title) + quote_plus(" S%01dE%01d" % (int(season), int(episode)))
            )
            self.name = unquote_plus(self.name)  # to jakieś awaryjne do wyszukania informacji z bilioteki, ale jak tytuł jest w meta, to do playera idzie z meta

            self.season = "%01d" % int(season) if self.content == "episode" else None
            self.episode = "%01d" % int(episode) if self.content == "episode" else None

            self.DBID = None  # jakiś reset zmiennej chyba

            self.imdb = imdb if not imdb is None else "0"
            self.tmdb = tmdb if not tmdb is None else "0"
            self.tvdb = tvdb if not tvdb is None else "0"

            #self.ids = {"imdb": self.imdb, "tmdb": self.tmdb}  # brak tvdb
            self.ids = {"imdb": self.imdb, "tvdb": self.tvdb, "tmdb": self.tmdb}
            self.ids = dict((k, v) for k, v in self.ids.items() if not v == "0")  # znacznik dla wtyczki script.trakt, aby mogła rozpoznawać filmy

            self.offset = bookmarks.get(self.content, imdb, season, episode)

            #fflog(f"{self.imdb=} {self.tmdb=} {self.ids=} {self.offset=}", 1)
            fflog(f"{self.ids=}  {self.offset=}", 1)

            poster, thumb, fanart, clearlogo, clearart, discart, meta = self.getMeta(meta)

            fflog(f'{control.setting("player.strip_headers_from_link")=}', 0)  # to jakby też (patrz komentarz poniżej)
            if control.setting("player.strip_headers_from_link") == "true":
                url = url.split("|")[0]

            fflog(f'{url=}', 0)  # dziwne, ale to pomaga uzwględnić zmianę powyższego ustawienia bez konieczności ponownego szukania źródeł (tylko musi być chyba zmienna w logu)

            # Create a playable item with a path to play.
            item = control.item(path=url, offscreen=True)  # offscreen=True means that the item is not meant for displaying (only to pass info to the Kodi player)

            if self.content == "movie":
                item.setArt(
                    {
                        "icon": thumb,
                        "thumb": thumb,
                        "poster": poster,
                        "fanart": fanart,
                        "clearlogo": clearlogo,
                        "clearart": clearart,
                        "discart": discart,
                    }
                )
            else:
                item.setArt(
                    {
                        "icon": thumb,
                        "thumb": thumb,
                        "tvshow.poster": poster,
                        "season.poster": poster,
                        "fanart": fanart,
                        "clearlogo": clearlogo,
                        "clearart": clearart,
                    }
                )
            item.setInfo(type="video", infoLabels=control.metadataClean(meta))

            vtag = item.getVideoInfoTag()
            castwiththumb = meta.get("castwiththumb")
            if castwiththumb:
                castwiththumb = [xbmc.Actor(**a) for a in castwiththumb]
                vtag.setCast(castwiththumb)

            fflog("trying to start playback")

            handle = int(sys.argv[1]) if not handle else handle
            handle = handle if isinstance(handle, int) else -1
            #if "plugin" in control.infoLabel("Container.PluginName") and control.setting("hosts.mode") != "1" or int(sys.argv[1]) < 0:
            if handle < 0 or control.setting("player.dont_use_setResolvedUrl") == "true":
                fflog(f'{handle=}')
                fflog(f'not resolved method')
                control.player.play(url, item)
            else:
                fflog(f'setResolvedUrl method')
                control.resolve(handle, True, item)

            # if control.condVisibility('System.HasAddon(script.trakt)'):
            control.window.setProperty("script.trakt.ids", json.dumps(self.ids))  # znacznik dla wtyczki script.trakt, aby mogła rozpoznawać filmy

            self.keepPlaybackAlive()  # podtrzymywanie, aby skrypt się nie zakończył

            control.window.clearProperty("script.trakt.ids")

            fflog(f'end of player script')
        except Exception:
            control.infoDialog('wystąpił jakiś błąd', heading="FanFilm Player", icon="ERROR", time=2900)
            # log("player_fail", "module")
            fflog("player fail")
            from ptw.debug import log_exception, fflog_exc
            fflog_exc(1)
            return


    def getMeta(self, meta):
        try:
            poster = meta["poster"] if "poster" in meta.keys() else ""
            thumb = meta["thumb"] if "thumb" in meta.keys() else "" or poster
            fanart = meta["fanart"] if "fanart" in meta.keys() else ""
            clearlogo = meta["clearlogo"] if "clearlogo" in meta.keys() else ""
            clearart = meta["clearart"] if "clearart" in meta.keys() else ""
            discart = meta["discart"] if "discart" in meta.keys() else ""

            fflog(f'[getMeta] 1 case', 0)
            return poster, thumb, fanart, clearlogo, clearart, discart, meta
        except:
            pass

        try:
            if not self.content == "movie":
                raise Exception()

            meta = control.jsonrpc(
                '{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "year", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "plot", "plotoutline", "tagline", "thumbnail", "file"]}, "id": 1}'
                % (self.year, str(int(self.year) + 1), str(int(self.year) - 1))
            )
            meta = six.ensure_text(meta, errors="ignore")
            meta = json.loads(meta)["result"]["movies"]

            t = cleantitle.get(self.title)
            meta = [
                i
                for i in meta
                if self.year == str(i["year"])
                and (
                    t == cleantitle.get(i["title"])
                    or t == cleantitle.get(i["originaltitle"])
                )
            ][0]

            for k, v in meta.items():
                if type(v) == list:
                    try:
                        meta[k] = str(" / ".join([six.ensure_str(i) for i in v]))
                    except:
                        meta[k] = ""
                else:
                    try:
                        meta[k] = str(six.ensure_str(v))
                    except:
                        meta[k] = str(v)

            if not "plugin" in control.infoLabel("Container.PluginName"):
                self.DBID = meta["movieid"]

            poster = thumb = meta["thumbnail"]

            fflog(f'[getMeta] 2 case', 0)
            return poster, thumb, "", "", "", "", meta
        except:
            pass

        try:
            if not self.content == "episode":
                raise Exception()

            meta = control.jsonrpc(
                '{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "year", "thumbnail", "file"]}, "id": 1}'
                % (self.year, str(int(self.year) + 1), str(int(self.year) - 1))
            )
            meta = six.ensure_text(meta, errors="ignore")
            meta = json.loads(meta)["result"]["tvshows"]

            t = cleantitle.get(self.title)
            meta = [
                i
                for i in meta
                if self.year == str(i["year"]) and t == cleantitle.get(i["title"])
            ][0]

            tvshowid = meta["tvshowid"]
            poster = meta["thumbnail"]

            meta = control.jsonrpc(
                '{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{ "tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["title", "season", "episode", "showtitle", "firstaired", "runtime", "rating", "director", "writer", "plot", "thumbnail", "file"]}, "id": 1}'
                % (tvshowid, self.season, self.episode)
            )
            meta = six.ensure_text(meta, errors="ignore")
            meta = json.loads(meta)["result"]["episodes"][0]

            for k, v in meta.items():
                if type(v) == list:
                    try:
                        meta[k] = str(" / ".join([six.ensure_str(i) for i in v]))
                    except:
                        meta[k] = ""
                else:
                    try:
                        meta[k] = str(six.ensure_str(v))
                    except:
                        meta[k] = str(v)

            if not "plugin" in control.infoLabel("Container.PluginName"):
                self.DBID = meta["episodeid"]

            thumb = meta["thumbnail"]

            fflog(f'[getMeta] 3 case', 0)
            return poster, thumb, "", "", "", "", meta
        except:
            pass

        poster, thumb, fanart, clearlogo, clearart, discart, meta = (
            "",
            "",
            "",
            "",
            "",
            "",
            {"title": self.name},
        )
        fflog(f'[getMeta] 4 case', 0)
        return poster, thumb, fanart, clearlogo, clearart, discart, meta


    def keepPlaybackAlive(self):
        fflog('start keepPlaybackAlive method')

        pname = "%s.player.overlay" % control.addonInfo("id")
        control.window.clearProperty(pname)

        if self.content == "movie":
            overlay = playcount.getMovieOverlay(playcount.getMovieIndicators(), self.imdb)
        elif self.content == "episode":
            overlay = playcount.getEpisodeOverlay(
                playcount.getTVShowIndicators(),
                self.imdb,
                self.tmdb,
                self.season,
                self.episode,
            )
        else:
            overlay = "6"

        fflog(f'waiting for player to start')
        for i in range(0, 10*60*1):  # 1 minuta na rozpoczęcie odtwarzania
            if self.isPlayingVideo() or not self.is_active:
                break
            xbmc.sleep(100)  # delay if loop
        if not self.isPlayingVideo():
            fflog(f'nie udało się rozpocząć odtwarzania')
            import xbmcgui
            control.dialog.notification('FanFilm', 'nie udało się rozpocząć odtwarzania', xbmcgui.NOTIFICATION_ERROR, time=3000, sound=True)

        if overlay == "7":  # obejrzany do konca już wcześniej był
            while self.isPlayingVideo():
                try:
                    self.currentTime = self.getTime()
                    self.totalTime = self.getTotalTime()
                except:
                    pass
                xbmc.sleep(2000)

        elif self.content == "movie":
            while self.isPlayingVideo():
                try:
                    self.currentTime = self.getTime()
                    self.totalTime = self.getTotalTime()

                    watcher = self.currentTime / self.totalTime >= 0.85  # traktować jako obejrzany
                    property = control.window.getProperty(pname)

                    if watcher == True and not property == "7":
                        control.window.setProperty(pname, "7")
                        playcount.markMovieDuringPlayback(self.imdb, "7")

                    elif watcher == False and not property == "6":
                        control.window.setProperty(pname, "6")
                        playcount.markMovieDuringPlayback(self.imdb, "6")
                except:
                    pass
                xbmc.sleep(2000)

        elif self.content == "episode":
            while self.isPlayingVideo():
                try:
                    self.currentTime = self.getTime()
                    self.totalTime = self.getTotalTime()

                    watcher = self.currentTime / self.totalTime >= 0.85
                    property = control.window.getProperty(pname)

                    if watcher == True and not property == "7":
                        control.window.setProperty(pname, "7")
                        playcount.markEpisodeDuringPlayback(
                            self.imdb, None, self.season, self.episode, "7"
                        )

                    elif watcher == False and not property == "6":
                        control.window.setProperty(pname, "6")
                        playcount.markEpisodeDuringPlayback(
                            self.imdb, None, self.season, self.episode, "6"
                        )
                except:
                    pass
                xbmc.sleep(2000)

        fflog('end of keepPlaybackAlive method')
        control.window.clearProperty(pname)


    def libForPlayback(self):
        try:
            if self.DBID is None:
                raise Exception()

            if self.content == "movie":
                rpc = (
                    '{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails", "params": {"movieid" : %s, "playcount" : 1 }, "id": 1 }'
                    % str(self.DBID)
                )
            elif self.content == "episode":
                rpc = (
                    '{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid" : %s, "playcount" : 1 }, "id": 1 }'
                    % str(self.DBID)
                )
            else:
                return

            control.jsonrpc(rpc)
            if control.setting("crefresh") == "true":
                control.refresh()
        except:
            pass


    def onPlayBackStarted(self):
        fflog('playback started')
        control.execute("Dialog.Close(notification,true)")
        if True:
            try:
                fflog( "# playing " + self.getPlayingFile(), 0)
            except:
                fflog( "# failed get what I'm playing #", 0)


    def onAVStarted(self):  # czasami dopiero po ponad 1 sekundzie odpala
        fflog('player has video and/or audiostream')
        #fflog(f"{self.getTotalTime()=}", 1)
        control.execute("Dialog.Close(all,true)")
        control.sleep0(200)
        if (
            control.setting("bookmarks") == "true"
            and int(self.offset) > 120
            and self.isPlayingVideo()
            and abs(int(self.offset) - self.getTime()) > 10 # 10 sekund tolerancji
        ):
            """
            if control.setting("bookmarks.auto") == "true":  # nie ma takiego settingsu
                self.seekTime(float(self.offset))
            else:
            """
            self.pause()
            control.sleep0(100)
            minutes, seconds = divmod(float(self.offset), 60)
            hours, minutes = divmod(minutes, 60)
            label = f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"
            label = control.lang2(12022).format(label)
            fflog('waiting for decision if continue from last point or start from begin')
            if (
                #control.setting("resume.source") == "1"  # nie ma takiego settingsu
                trakt.getTraktIndicatorsInfo()
                and trakt.getTraktCredentialsInfo() == True
            ):
                yes = control.yesnoDialog(
                    label + "[CR]  (Trakt scrobble)",
                    yeslabel=control.lang2(13404),
                    nolabel=control.lang2(12021),
                )
            else:
                yes = control.yesnoDialog(
                    label,
                    yeslabel=control.lang2(13404),
                    nolabel=control.lang2(12021),
                )
            if yes:
                fflog(f'user decided jump to {float(self.offset)=} sec. ({(float(self.offset)/60)} min.)')
                self.seekTime(float(self.offset))
                control.sleep0(1000)
            self.pause()
        else:
            if self.isPlayingVideo():
                if (
                    trakt.getTraktCredentialsInfo()
                    #and control.setting("trakt.scrobble") == "true"
                    and trakt.getTraktIndicatorsInfo()
                    and self.external_scrobble_is_disabled()
                ):
                    #self.currentTime = self.getTime()
                    #self.totalTime = self.getTotalTime()
                    #fflog(f'bookmarks set_scrobble (trakt)')
                    bookmarks.set_scrobble(
                        self.currentTime,
                        self.totalTime,
                        self.content,
                        self.imdb,
                        None,
                        self.season,
                        self.episode,
                        action="start",
                    )            
        #self.idleForPlayback()  # nie ma takiej funkcji tu


    def onPlayBackStopped(self):
        fflog('player has been stopped')  # czasami się nie chce pojawiać
        self.is_active = False

        if (self.totalTime == 0
            or self.currentTime == 0
           ):
            #fflog(f'nie rejestruję czasu')
            #control.sleep(1000)  # czemu taki długi czas ?
            control.sleep(100)  # eksperyment
            return  # a co z trakt ? Czy nie trzeda dać sygnału stop ?

        if self.currentTime > 120:  # 2 minuty
            #fflog(f'bookmarks (re)set | {self.imdb=} {self.currentTime=}')
            bookmarks.reset(
                self.currentTime,
                self.totalTime,
                self.content,
                self.imdb,
                self.season,
                self.episode,
            )

        # dla trakt musi pójść sygnał pause albo stop, dlatego dalsza część kodu musi być wykonana

        # rejestrację czasu w trakt wykonuje też wtyczka z repo Kodi script.trakt i może ona nadpisywać to co tu jest wysyłane (chociaż zależy od ustawień tam) 
        if (
            trakt.getTraktCredentialsInfo()
            #and control.setting("trakt.scrobble") == "true"
            and trakt.getTraktIndicatorsInfo()
            # można ewentualnie zrobić wykrywanie aktywnej takiej wtyczki i jej ustawień (tam też jest offset od ilu rejestrować), tylko wówczas jak coś zmieni się w tamtej wtyczce to tu może przestać działać, więc może lepiej niezależnie zapisywać
            #and (not external_script_trakt_enabled or int(external_scrobble_start_offset)*60 > self.currentTime and external_scrobble_movie != "true" if self.content == "movie" else external_scrobble_episode != "true") 
            and self.external_scrobble_is_disabled()
        ):
            #fflog(f'bookmarks set_scrobble (trakt)')
            bookmarks.set_scrobble(
                self.currentTime,
                self.totalTime,
                self.content,
                self.imdb,
                None,
                self.season,
                self.episode,
            )

        if float(self.currentTime / self.totalTime) >= 0.92:
            fflog(f'mark as watched (more than 92%)')
            self.libForPlayback()


    def onPlayBackEnded(self):  # materiał doszedł do końca
        fflog('playback Ended')
        self.libForPlayback()
        self.onPlayBackStopped()
        if control.setting("crefresh") == "true":
            control.refresh()


    def onPlayBackError(self):  # nie wiem, kiedy to się pojawia  # Will be called when playback stops due to an error. 
        fflog('playback ERROR')
        self.is_active = False
        #self.onPlayBackStopped()  # nie wiem, czy trzeba to ręcznie, czy Kodi sam trigernie ten callback


    def onPlayBackSeek(self, time, offset):
        fflog('playback Seek')
        if self.isPlayingVideo():
            if (
                trakt.getTraktCredentialsInfo()
                #and control.setting("trakt.scrobble") == "true"
                and trakt.getTraktIndicatorsInfo()
                and self.external_scrobble_is_disabled()
            ):
                #self.currentTime = self.getTime()  # ewentualnie (time / 1000)
                self.currentTime = time / 1000
                #self.totalTime = self.getTotalTime()
                #fflog(f'{time=} {offset=}')
                #fflog(f'{self.totalTime=} {self.currentTime=}')
                #fflog(f'bookmarks set_scrobble (trakt)')
                bookmarks.set_scrobble(
                    self.currentTime,
                    self.totalTime,
                    self.content,
                    self.imdb,
                    None,
                    self.season,
                    self.episode,
                    action="start",
                )


    def onPlayBackResumed(self):
        fflog('playback Resumed')
        if self.isPlayingVideo():
            if (
                trakt.getTraktCredentialsInfo()
                #and control.setting("trakt.scrobble") == "true"
                and trakt.getTraktIndicatorsInfo()
                and self.external_scrobble_is_disabled()
            ):
                #self.currentTime = self.getTime()
                #self.totalTime = self.getTotalTime()
                #fflog(f'{self.totalTime=} {self.currentTime=}')
                #fflog(f'bookmarks set_scrobble (trakt)')
                bookmarks.set_scrobble(
                    self.currentTime,
                    self.totalTime,
                    self.content,
                    self.imdb,
                    None,
                    self.season,
                    self.episode,
                    action="start",
                )


    def onPlayBackPaused(self):
        fflog('playback Paused')
        if self.isPlayingVideo():
            if (
                trakt.getTraktCredentialsInfo()
                #and control.setting("trakt.scrobble") == "true"
                and trakt.getTraktIndicatorsInfo()
                and self.external_scrobble_is_disabled()
            ):
                #self.currentTime = self.getTime()
                #self.totalTime = self.getTotalTime()
                #fflog(f'{self.totalTime=} {self.currentTime=}')
                #if self.currentTime > 
                #fflog(f'bookmarks set_scrobble (trakt)')
                bookmarks.set_scrobble(
                    self.currentTime,
                    self.totalTime,
                    self.content,
                    self.imdb,
                    None,
                    self.season,
                    self.episode,
                )


    def external_scrobble_is_disabled(self):
        external_script_trakt_id = "script.trakt"
        #external_script_trakt_exists = control.condVisibility(f"System.HasAddon({external_script_trakt_id})")
        #if external_script_trakt_exists:
        external_script_trakt_enabled = control.condVisibility(f"System.AddonIsEnabled({external_script_trakt_id})")
        if external_script_trakt_enabled:
            external_scrobble_movie = control.addon(external_script_trakt_id).getSetting("scrobble_movie")
            external_scrobble_episode = control.addon(external_script_trakt_id).getSetting("scrobble_episode")

        external_scrobble_is_disabled = (
                #not (external_script_trakt_exists and external_script_trakt_enabled)
                not external_script_trakt_enabled
                or (
                    external_scrobble_movie != "true" if self.content == "movie"
                    else external_scrobble_episode != "true"
                   )
            )
        #fflog(f'{external_scrobble_is_disabled=}')
        return external_scrobble_is_disabled
