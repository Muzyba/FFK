# -*- coding: utf-8 -*-
import sys, re, os, json
import hashlib
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import xbmcplugin
import resolveurl as urlresolver
import base64
import requests
from html import unescape

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
if sys.version_info >= (3,0,0):
# for Python 3
    from resources.lib.cmf3 import parseDOM
    import http.cookiejar as cookielib
    from urllib.parse import unquote,parse_qs, quote, urlencode, quote_plus, parse_qsl
    import urllib.parse as urlparse
    xrange = range
    unicode = str
else:
    # for Python 2
    from resources.lib.cmf2 import parseDOM

    import cookielib
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse
    from urlparse import parse_qs, parse_qsl
  

# Disable InsecureRequestWarning
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
  
  
cache = StorageServer.StorageServer("filmancc")  # dane w pliku %appdata%/Kodi/cachecommoncache.db


base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
addonId         = my_addon.getAddonInfo('id')
PATH            = my_addon.getAddonInfo('path')
try:
    DATAPATH = xbmcvfs.translatePath(my_addon.getAddonInfo('profile'))
except:
    DATAPATH = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES = PATH+'/resources/'
FANART = RESOURCES+'fanart.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )


if not (UA := my_addon.getSetting("UA").strip(' "\'')):
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0'


COOKIES = my_addon.getSetting("COOKIES").strip(' "\'')
if COOKIES and "=" not in COOKIES:
    COOKIES = "BKD_REMEMBER=" + COOKIES
else:
    COOKIES = re.sub('PHPSESSID=[^;]*;?', '', COOKIES).strip(' ;')
other_sess_mode = my_addon.getSetting("other_sess_mode") == "true"


fname = args.get('foldername',[''])[0]

mainurl = 'https://filman.cc/'
mybtn_user = ''
TIMEOUT = 10

BASEURL='https://filman.cc/'

COOKIEFILE = os.path.join(DATAPATH,'filmancookie')

sess=requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

sess2=requests.Session()



def addLinkItem(name, url, mode, page=1, iconimage='DefaultFolder.png', infoLabels=False, contextO=[''], IsPlayable=True, fanart=FANART, itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link': url, 'page': page, 'token': mybtn_user})

    # nowszy sposób
    # vtag = liz.getVideoInfoTag()
    # vtag.setTitle(name)
    # vtag.setPlot( infoLabels.get("plot") or "" )
    if not infoLabels:  # dla pozycji menu
        # xbmc.log(f'[filmancc] [addLinkItem] {infoLabels=}',1)
        infoLabels = {}
        # infoLabels={"title": name, 'plot': name}
        pass
    # infoLabels.update({"title": name,})  # bo title przykrywa label
    infoLabels.pop('href', None)
    infoLabels.pop('img', None)
    if 'true' in my_addon.getSetting('addYear'):
        if infoLabels.get('year'):
            name = f'{infoLabels["title"]} [LIGHT]({infoLabels["year"]})[/LIGHT]'
            # infoLabels["title"] = f'{infoLabels["title"]} [LIGHT]({infoLabels["year"]})[/LIGHT]'  # tylko to nie jest do końca poprawne, bo title przykrywa label, gdy źle sortowanie jest określone
            # infoLabels.pop('year', None)  # fix dla skórek, która wyświetla rok po tytule (aby nie było zdublowania roku)
    # xbmc.log(f'[filmancc] [addLinkItem] {infoLabels=}',1)

    liz = xbmcgui.ListItem(name)  # label

    if infoLabels:
        liz.setInfo(type="Video", infoLabels=infoLabels)  # deprecated
        # InfoTagVideo
        # tag = liz.getVideoInfoTag()
        # tag.setTitle(infoLabels["title"])
        # tag.setPlot(infoLabels["plot"])
        # tag.setYear(infoLabels["year"])
        # ...

    art_keys=['icon', 'thumb', 'poster', 'banner', 'landscape']
    if infoLabels and fanart is not None:
        art_keys.append('fanart')
        pass
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    # xbmc.log(f'[filmancc] [addLinkItem] {art=}',1)
    liz.setArt(art)
    
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    
    isp = []
    if 'DOWNLOAD' in contextO:
        # content = quote_plus(json.dumps(infoLabels))
        # isp.append(('[B]Download[/B]', 'RunPlugin(plugin://%s?mode=DOWNLOAD&ex_link=%s)' % (addonId, content)))
        pass
    if 'Komentarze' in contextO:
        isp.append(('[B]Komentarze[/B]', 'RunPlugin(plugin://%s?mode=Komentarze&ex_link=%s)' % (addonId, url)))
        pass
    liz.addContextMenuItems(isp, replaceItems=False)

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=False, totalItems=itemcount)

    # czemu taka dziwna konstrukcja z tym sortowaniem?  https://github.com/retrospect-addon/kodi.emulator.ascii/blob/master/xbmcplugin.py
    if False:
        # alternatywa
        labelMask = "%L"
        label2Mask = "%R, %Y, %P"
        if 'true' in my_addon.getSetting('addYear'):
            labelMask = "%L, %Y"
            label2Mask = "%R, %P"
        # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, labelMask=labelMask, label2Mask=label2Mask)  # to powinno być dopiero gdy zamykamy folder
        pass
    #xbmcplugin.setContent(addon_handle, 'files')
    return ok



def addDir(name, ex_link=None, page=1, mode='folder', iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART, contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link': ex_link, 'page': page, 'iconImage': iconImage, 'token': mybtn_user})
    # xbmc.log(f'[filmancc] {url=}',1)

    if not infoLabels:
        # xbmc.log(f'[filmancc] [addDir] {infoLabels=}',1)
        infoLabels = {}
        # infoLabels={"title": name, 'plot': name}
    # infoLabels.update({"title": name,})  # bo title przykrywa label
    if 'true' in my_addon.getSetting('addYear'):
        if infoLabels.get('year'):
            name = f'{infoLabels["title"]} [LIGHT][I]({infoLabels["year"]})[/I][/LIGHT]'
            # infoLabels["title"] = f'{infoLabels["title"]} [LIGHT][I]({infoLabels["year"]})[/I][/LIGHT]'  # uwaga: title przykrywa label
            # infoLabels.pop('year', None)  # fix dla skórek, która wyświetla rok po tytule (aby nie było zdublowania roku)
    infoLabels.pop('href', None)
    infoLabels.pop('img', None)
    # xbmc.log(f'[filmancc] [addDir] {name=}  {infoLabels=}',1)

    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)
    
    art_keys=['icon', 'thumb', 'poster', 'banner', 'landscape']
    if infoLabels and fanart is not None:
        art_keys.append('fanart')
        pass
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    li.setArt(art)
    
    if contextmenu:
        isp = contextmenu
        li.addContextMenuItems(isp, replaceItems=True)
    
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    #xbmcplugin.setContent(addon_handle, 'files')    



def encoded_dict(in_dict):
    out_dict = {}
    try:
        # Python 2
        iter_dict = in_dict.iteritems()
    except AttributeError:
        # Python 3
        iter_dict = in_dict.items()
    out_dict = {}
    for k, v in iter_dict:
   # for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict



def build_url(query):
    return base_url + '?' + urlencode(encoded_dict(query))



def listTv(ex_link):
    mlinks = getTvs(ex_link)
    items = len(mlinks)
    for f in mlinks:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode='getTvLinks', iconImage=f.get('img'), infoLabels={'plot':f.get('title')})



def listMovies(ex_link, page):
    # xbmc.log(f'[filmancc] [listMovies] {ex_link=} {page=}',1)

    page = int(page) if page else 1
    group = ''

    if '|'in ex_link:
        ex_link, group = ex_link.split('|')

    # xbmc.log(f'[filmancc] [listMovies] {ex_link=} {page=}',1)
    mlinks, mparams = getMovies(ex_link, page, group)

    if mparams[0]:
        # addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__M', page=mparams[0], IsPlayable=False)
        pass
    
    items = len(mlinks)
    
    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze'], IsPlayable=True, itemcount=items)
    
    if mparams[1]:
        # addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__M', page=mparams[1], IsPlayable=False)
        if mparams[2]:
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]} z {mparams[2]})[/I]', ex_link=ex_link, mode='ListMovies', page=mparams[1])
        else:
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]})[/I]', ex_link=ex_link, mode='ListMovies', page=mparams[1])

    #xbmcplugin.setContent(addon_handle, 'movies')



def listSeries(ex_link, page):
    # xbmc.log(f'[filmancc] [listSeries] {ex_link=} {page=}',1)
    page = int(page) if page else 1
    group = ''

    if '|'in ex_link:
        ex_link, group = ex_link.split('|')
    '''
    if group:
        mlinks, mparams = getSeries(ex_link,int(page),group)
    else:
        mlinks, mparams = getSeries(ex_link)
    '''
    mlinks, mparams = getSeries(ex_link, int(page), group)
    
    my_mode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'
    # xbmc.log(f'[filmancc] [listSeries] {my_mode=}',1)

    if mparams[0]:
        # addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__S', page=mparams[0], IsPlayable=False)
        pass

    items = len(mlinks)
    # xbmc.log(f'[filmancc] [listSeries] {items=}',1)

    for f in mlinks:
        isp = []
        isp.append(('[B]Komentarze[/B]', 'RunPlugin(plugin://%s?mode=Komentarze&ex_link=%s)' % (addonId, f.get('href'))))
        # addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), contextmenu=isp)#, infoLabels=f)
        addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), contextmenu=isp, infoLabels=f)

    if mparams[1]:
        # addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__S', page=mparams[1], IsPlayable=False)
        if mparams[2]:
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]} z {mparams[2]})[/I]', ex_link=ex_link, mode='ListSeriale', page=mparams[1])
        else:
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]})[/I]', ex_link=ex_link, mode='ListSeriale', page=mparams[1])
    #xbmcplugin.setContent(addon_handle, 'tvshows')



def getSeasons(ex_link):
    # xbmc.log(f'[filmancc] [getSeasons] {ex_link=}',1)

    if 'true' not in my_addon.getSetting('groupEpisodes'):
        return getEpisodes(ex_link)

    episodes = scanEpisodes(ex_link)
    if episodes:
        imag = episodes[0].get('img')#
        seasons = splitToSeasons(episodes)
        # xbmc.log(f'[filmancc] {seasons=}',1)
        if my_addon.getSetting('descSortEpisodes') != 'true':
            reverse_order = False  # (ascending order)
        else:
            reverse_order = True  # (descending order)
        cache.delete('season_%')
        for i in sorted(seasons.keys(), reverse=reverse_order):
            key = f'season_{seasons[i][0]["season"]}|' + hashlib.md5(ex_link.encode()).hexdigest()
            cache.set( key, str(seasons[i]) )
            # addDir(name=i, ex_link=quote(str(seasons[i])), iconImage=imag, mode='getEpisodes2')
            addDir(name=i, ex_link=f'season_{seasons[i][0]["season"]}|{ex_link}', iconImage=imag, mode='getEpisodes2')
    
        xbmcplugin.setContent(addon_handle, 'seasons')
        xbmcplugin.endOfDirectory(addon_handle,True)        
    else:
        sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Brak odcinków')



def getEpisodes(ex_link):
    # xbmc.log(f'[filmancc] [getEpisodes] {ex_link=}',1)

    if 'true' in my_addon.getSetting('groupEpisodes'):
        return getSeasons(ex_link)

    episodes = scanEpisodes(ex_link)
    # xbmc.log(f'[filmancc] {episodes=}',1)
    if episodes:
        if my_addon.getSetting('descSortEpisodes') != 'true':
            reverse_order = False  # (ascending order)
        else:
            reverse_order = True  # (descending order)
        # for f in episodes:  # kolejność jak na stronie
        for f in sorted(episodes, key=lambda x: (x['season'], x['episode']), reverse=reverse_order):
            addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze'], IsPlayable=True)

        xbmcplugin.setContent(addon_handle, 'episodes')
        xbmcplugin.endOfDirectory(addon_handle,True)
    else:
        sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Brak odcinków')



def getEpisodes2(ex_link):
    # xbmc.log(f'[filmancc] [getEpisodes2] {ex_link=}',1)

    season, ex_link = ex_link.split("|", 1)
    key = season + '|' + hashlib.md5(ex_link.encode()).hexdigest()
    episodes = []
    # episodes = eval(unquote(ex_link))
    episodes = cache.get(key)
    episodes = eval(episodes) if episodes else []
    # xbmc.log(f'[filmancc] {len(episodes)=}',1)
    if not episodes:
        episodes = scanEpisodes(ex_link)
        season = int(season.replace('season_', ''))
        episodes = [i for i in episodes if i["season"] == season]
        cache.set( key, str(episodes) )

    # for f in episodes:
    if my_addon.getSetting('descSortEpisodes') != 'true':
        reverse_order = False  # (ascending order)
    else:
        reverse_order = True  # (descending order)
    for f in sorted(episodes, key=lambda x: x['episode'], reverse=reverse_order):
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze'], IsPlayable=True, fanart=f.get('img'))
    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.endOfDirectory(addon_handle,True)



def listFS(ex_link):
    # xbmc.log(f'[filmancc] [listFS] {ex_link=}',1)
    mlinks, slinks = search(ex_link)

    for f in mlinks:  # filmy
        addLinkItem(name='F: '+f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze'], IsPlayable=True, itemcount=len(mlinks))

    my_mode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'
    # xbmc.log(f'[filmancc] [listFS] {my_mode=}',1)
    
    for f in slinks:  # seriale
        isp = []
        isp.append(('[B]Komentarze[/B]', 'RunPlugin(plugin://%s?mode=Komentarze&ex_link=%s)' % (addonId, f.get('href'))))
        addDir(name='S: '+f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, contextmenu=isp)

    xbmcplugin.setContent(addon_handle, 'files')


    
def getTvLinks(ex_link,rys):
    mlinks = getTvLink(ex_link,rys)
    items = len(mlinks)
    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='playTv', iconimage=rys, infoLabels={'plot':f.get('title')}, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=items)
    

    
def PlayTv(ex_link):
    stream_url = ex_link
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        



def getLinks(ex_link, get_download=False, name='', image=''):
    # xbmc.log(f'[filmancc] [getLinks] {ex_link=} {name=}',1)

    streams, meta = getVideos(ex_link)

    stream_url = ''
    if len(streams) > 0:
    
        t = [x.get('label') for x in streams]
        u = [x.get('url')   for x in streams]
        # h = [x.get('host')  for x in streams]

        al = "Z jakiego źródla pobieramy?"  if get_download  else "Host  |  Dodane  |  Wersja  | Jakość"

        if "zaskocz-mnie" in ex_link:
            oceny = f'[LIGHT][I]śr. ocen: {meta.get("rating")}  ({meta.get("votes")} głosujących)[/I][/LIGHT]' + "\n\n"
            xbmcgui.Dialog().ok( f'{meta.get("title")}  ({meta.get("year")}) ', oceny + meta.get("plot") )
            xbmc.sleep(200)
            al = f'{meta.get("title")}  ({meta.get("year")}) '

        def wybieranie_zrodla(preselect=-1):
            stream_url = ''
            select = xbmcgui.Dialog().select(al, t, preselect=preselect)
            if select > -1:
                link = u[select]
                link = parseVideoLink(link, [select])
                if not stream_url:
                    if '.mp4' in link:
                        stream_url = link + '|User-Agent='+quote(UA)
                    else:
                        try:
                            stream_url = urlresolver.resolve(link)
                        except Exception as e:
                            stream_url = ''
                            sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Może inny link będzie działał?' + '\n\n Resolveurl ERROR: [%s]'%str(e))
                            stream_url = wybieranie_zrodla(preselect=select)
            else:
                pass    
            return stream_url

        stream_url = wybieranie_zrodla()    

        if stream_url:
            if get_download:
                downloadPath = my_addon.getSetting('download.path')
                if downloadPath and downloadPath != '':
                    import resources.lib.downloader as dw
                    try:
                        dw.download(name, image, stream_url, downloadPath)
                    except:
                        xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i,%s)" % ( '[COLOR red] Bląd pobierania [/COLOR]', name, 5000, image))
                else:
                    xbmcgui.Dialog().ok("FilmanCC", "Ustaw docelowy folder!")
                    xbmc.executebuiltin("Addon.OpenSettings(%s)" % addonId)
            liz = xbmcgui.ListItem(path=stream_url)
            # meta.update({"plot": "[filmancc]"})
            if meta.get("ep_title"):
                meta.update({"title": meta.get("title") + " - " + meta.get("ep_title")})
            meta.pop("ep_title", None)
            liz.setInfo(type="Video", infoLabels=meta)
            # xbmc.log(f'[filmancc] [getLinks] {meta=}',1)
            xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        else:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
    else:
        if "zaskocz-mnie" in ex_link:
            # xbmcgui.Dialog().notification('[COLOR red][B]Informacja[/B][/COLOR]', 'Wylosowany materiał nie posiada żadnych linków, \nalbo link dostępny jest tylko dla premium. Spróbuj jeszcze raz.', xbmcgui.NOTIFICATION_INFO, 5000)
            xbmcgui.Dialog().ok('Spróbuj jeszcze raz', 'Wylosowany materiał nie posiada żadnych linków, \nalbo link dostępny jest tylko dla premium.')
        else:
            xbmcgui.Dialog().notification('[COLOR red][B]Informacja[/B][/COLOR]', 'Ten materiał nie posiada żadnych linków, \n albo link dostępny jest tylko dla premium.', xbmcgui.NOTIFICATION_INFO, 5000)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))



def getHistory():
    return cache.get('history').split(';')



def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history', ';'.join(history[:50]))



def remCache(entry):
    history = getHistory()
    # xbmc.log(f'[filmancc] {entry=}  {history=}',1)
    if history:
        history = [h for h in history if h != entry]
        cache.set('history', ';'.join(history[:50]))
    else:
        pass
        # delHistory()



def delHistory():
    cache.delete('history')



def login():
    dataPath = os.path.dirname(COOKIEFILE)
    
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)

    u = my_addon.getSetting('user')
    p = my_addon.getSetting('pass')
    l = my_addon.getSetting('login')

    logged = False

    if u and p and l == 'true':
        logged, dane = getLogin(u, p)
        if logged:
            if logged is not True:
                u = logged
            addLinkItem('#  [B]Zalogowany[/B] [LIGHT] jako[/LIGHT] [B]%s[/B]  [I]%s [/I]' % (u, dane), '', mode=' ', iconimage='DefaultUser.png', IsPlayable=False)
        else:
            xbmcgui.Dialog().notification('[COLOR red][B]Błąd logowania[/B][/COLOR]', '', xbmcgui.NOTIFICATION_INFO, 5000)
            sess.cookies.clear()
            sess.cookies.save(COOKIEFILE, ignore_discard = True)    
            addLinkItem('[B]Zaloguj[/B]', '', mode='Opcje', iconimage='DefaultUser.png', IsPlayable=False, infoLabels={'plot':'[B]Zaloguj[/B]'})
    else:
        global mybtn_user

        sess.cookies.clear()

        sess.headers.update({
                'Host': 'filman.cc',
                'User-Agent': UA,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'Referer': 'http://filman.cc/logowanie',
                'Upgrade-Insecure-Requests': '1',
                })

        if other_sess_mode:
            sess.headers.update({'Cookie': COOKIES,})
    
        url = 'https://filman.cc/logowanie'
        cont = sess.get(url)

        aa = sess.cookies
        
        my_cookies = requests.utils.dict_from_cookiejar(aa)
        found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
        
        mybtn_user = ';'.join(found)
        sess.cookies.save(COOKIEFILE, ignore_discard=True)        

        addLinkItem('[B]Zaloguj[/B]', '', mode='Opcje', iconimage='', IsPlayable=False)            

        
#from urlparse import urlparse
#from urlparse import urlsplit



def getLogin(u='', p=''):

    try:
        import kurw
        kurw.abc()
    except:
        pass
    
    fkukz = my_addon.getSetting('fjkukz')
    url ='https://filman.cc/logowanie'

    try:
        sess.cookies.clear()
        sess.headers = {
            'Host': 'filman.cc',
            'User-Agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'dnt': '1',
            'upgrade-insecure-requests': '1',
            'te': 'trailers',
        }
        if other_sess_mode:
            sess.headers.update({'Cookie': COOKIES,})
       
        response = sess.get('https://filman.cc/', verify=False)

        if not response:
            # xbmc.log(f'[filmancc] {response=}',1)
            xbmcgui.Dialog().notification('[COLOR red][B]Błąd serwera[/B][/COLOR]: '+str(response.status_code), str(response.reason), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmc.sleep(4000)
            # raise Exception()
            response.raise_for_status()

        response = sess.get('https://filman.cc/online', verify=False)

        # response = sess.get('https://filman.cc/logowanie', verify=False)

        if response.text.find('Wyloguj') < 1:
            xbmc.log('[filmancc] trzeba zalogować',1)

            data={
                "login": u,
                "password": p,
                "remember": 'on',
                "submit": ''}
            
            response = sess.post('https://filman.cc/logowanie', data=data, verify=False)
        else:
            xbmc.log('[filmancc] nie trzeba logować',1)
            pass

        ab = sess.cookies
        ad = response.cookies
        content = response.text
        
        mybtn_user = ''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
        # xbmc.log(f'[filmancc] {ab=} {ad=} {mybtn_user=}',1)        
    except Exception as e:
        content = ''
        if str(e):
            xbmc.log(f'[filmancc] {e}',1)

    dane = ''
    if content.find('Wyloguj') > 0:
        out = True
        try:
            user = parseDOM(content, "a", attrs={"id": "dropdown"})[0]
            user = re.sub("<[^>]+>", "", user).strip()
            user = user.replace("Zalogowany jako:", "")
            out = user if user else out
        except:
            pass
        sess.cookies.save(COOKIEFILE, ignore_discard = True)
        # dane = '[COLOR yellowgreen] darmowe[/COLOR]'
        my_addon.setSetting('zalog', 'true')
        try:
            content = sess.get('http://filman.cc/premium', cookies=sess.cookies).text
            danex = re.findall(' aktywne konto premium.+?<strong>(.+?)</strong>(.+?)<', content, re.DOTALL)
            if danex:
                my_addon.setSetting('prem', 'true')
                dane = '[COLOR orangered] premium do %s %s[/COLOR]'%(danex[0][0], danex[0][1])
                sess.cookies.save(COOKIEFILE, ignore_discard = True)
            else:
                my_addon.setSetting('prem', 'false')
        except Exception as e:
            my_addon.setSetting('prem', 'false')
            if str(e):
                xbmc.log(f'[filmancc] {e}',1)
                pass
            
    else:
        out = False
        my_addon.setSetting('zalog', 'false')
    return out, dane



def getUrlReq(url, ref, allow=True):
    # xbmc.log(f'[filmancc] [getUrlReq] {url=} {ref=} {allow=}',1)
    # allow = False
    #global mybtn_user
    if os.path.isfile(COOKIEFILE):
        sess.cookies.load()
        pass
    ab = sess.cookies
    
    headersy = {'User-Agent': UA, 'Referer': ref}
    if other_sess_mode:
        headersy={'User-Agent': UA, 'Referer': ref, 'Cookie': COOKIES,}
    sess.headers.update({
            'Host': 'filman.cc',
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': ref,
            'Upgrade-Insecure-Requests': '1',
            })
    if other_sess_mode:
        sess.headers.update({'Cookie': COOKIES,})       

    xbmc.log(f'[filmancc] {url=}', 0)
    content = sess.get(url, verify=False, cookies=sess.cookies, allow_redirects=allow)#.text
    # content=sess.get(url, verify=False, allow_redirects=allow)#.text
    
    if not content:
        # xbmc.log(f'[filmancc] {content=}',1)
        xbmcgui.Dialog().notification('[COLOR red][B]Błąd serwera[/B][/COLOR]: '+str(content.status_code), str(content.reason), xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmc.sleep(3000)
        # raise Exception()
        content.raise_for_status()

    # xbmc.log(f'{content.status_code=} \n{content.url=} \n{content.is_redirect=} \n{content.is_permanent_redirect=} \n{content.history=} \n{content.next=} \n{content.links=} \n{content.headers=} \n{content.cookies=}',1)
    if unquote(content.url) != url:
        xbmc.log(f'[filmancc] [getUrlReq] {url=} {content.url=}',1)

    if 'Security Check' in content.text:
        xbmc.log(f'[filmancc] jakiś Security Check',1)
        content = sess.get(url, headers=headersy)#.text    
        sess.cookies.save(COOKIEFILE, ignore_discard=True)

    if allow:
        content = content.text
    else:
        content = content

    mybtn_user = ''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
    # xbmc.log(f'[filmancc] DUPA {content=}',1)
    return content    #.text



def getTvs(url):
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    content = getUrlReq(url, url)
    out = []
    result = parseDOM(content, 'div', attrs={'class': "row tv-list"})[0]
    links = parseDOM(result, 'div', attrs={'class': "col-xs-6 col-sm-3"})
    for link in links:
        src = parseDOM(link, 'img', ret='src')[0]
        href = parseDOM(link, 'a', ret='href')[0]   
        title = parseDOM(link, 'a', ret='title')[0]  
        if href and title:
            if src.startswith('//'):
                src = 'http:' + src
            film = {
                'href'   : href,
                'title'  : title,
                'plot'   : '',
                # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                'img'    : src,
                }
            out.append(film)
    return out        



def getEpg(url):
    content = getUrl(url)
    plot = ''
    trwa = parseDOM(content, 'b')[0]
    czastrwa = parseDOM(content, 'p')[1]
    czastrwado = parseDOM(content, 'p')[2]
    dalej = parseDOM(content, 'table', attrs={'width': ".+?"})[0]
    plot += '[COLOR khaki]' + czastrwa + '-' + czastrwado + '[/COLOR] ' + trwa
    plot += '[CR]'
    try:
        typhourtitle = re.findall('<tr.+?title="(.+?)".+?<b>(.+?)<\/b.+?<td>(.+?)<\/td', dalej)#[0]
        for typ, hour, title in typhourtitle:
            plot += '[COLOR khaki]' + hour + '[/COLOR] ' + title
            plot += '[CR]'
    except:
        pass
    return plot



def getTvLink(url,imag):
    zalog = my_addon.getSetting('zalog')
    global mybtn_user
    
    mybtn_user = args.get('token',[''])[0]
    cuk = quote(mybtn_user)

    content=getUrlReq(url, url)
    out = []
    epgresult = parseDOM(content, 'div', attrs={'class': "epg"})#[0]
    plot = ''
    if epgresult:
        epgs = parseDOM(epgresult[0],'h4')
        if epgs:
            for epg in epgs:
                plot += '[COLOR khaki]'+epg+'[/COLOR] '
                plot += '[CR][CR]'
        else:
            epgs = parseDOM(epgresult[0],'span')
            if epgs:
                for epg in epgs:
                    plot += '[COLOR khaki]'+epg+'[/COLOR] '
                    plot += '[CR][CR]'                
    result = parseDOM(content, 'div', attrs={'class': "tab-content"})#[0]

    if result:
        result = result[0]
        co = 1    

        if 'tylko dla zalogowanych' in result:
            u = my_addon.getSetting('user')
            p = my_addon.getSetting('pass')

            logged, dane = getLogin(u, p)
            content = getUrlReq(url, url)
        tthrefs = re.findall('<iframe.+?src="(.+?)".+?"text-center">([^<]+).+?"text-center">([^<]+)', result, re.DOTALL)
        
        ids = [(a.start(), a.end()) for a in re.finditer('<div role="tabpanel"', result)]
        ids.append( (-1,-1) )
        out = []
        for i in range(len(ids[:-1])):

            odtw = result[ ids[i][1]:ids[i+1][0] ]
            if 'tab-pane fade" id="' in odtw:

                ab=re.findall('id="([^"]+).*?var player(.+?)watermark',odtw,re.DOTALL)
                if ab:
                    tyt = fname + ' - ' +ab[0][0]
                    info = tyt
                    href = re.findall('source\:\s*"([^"]+)',ab[0][1],re.DOTALL)[0]
                    link = url
                    film = {'href': href+'|User-Agent='+UA+'&Referer='+link, 'title': info, 'plot': plot, 'img': imag,}    
                    out.append(film)
            else:
                continue

    return out
    


def getMovies(url, page=1, group=''):
    # xbmc.log(f'[filmancc] [getMovies] {url=} {page=} ',1)
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk=quote(mybtn_user)

    if '?page=' in url:
        url = url.replace('?page=', '?page=%d' % page)
    elif page:
        url += '/' if url[-1] != '/' else ''
        url = url + '?page=%d' % page
    if group:
        url = url.split('?')[0]    

    # xbmc.log(f'[filmancc] [getMovies] {url=}',1)
    content = getUrlReq(url, url)

    out = []
    gr = False
    pr = False
    ids = []
    try:
        result = parseDOM(content, 'div', attrs={'class': "col-sm-9"})[1]
    except:
        result = content        #<ul class='clearfix pagination'>

    mdata = parseDOM(content, 'ul', attrs={'class': "clearfix pagination"})#[0]     #<ul class='clearfix pagination'>
    mdata = unquote(mdata[0]) if mdata else content
    gr = False
    
    if mdata.find( '?page=%d' % (page+1)) > -1:
        gr = page + 1

    last_page = parseDOM(mdata, 'li', attrs={'class': "next"})
    # xbmc.log(f'[filmancc] [getMovies] {last_page=}',1)
    if last_page:
        last_page = last_page[-1]
        last_page = re.search("data-pagenumber='(\d*)'", last_page)
        if last_page:
            last_page = int(last_page[1])
    # xbmc.log(f'[filmancc] [getMovies] {last_page=}',1)

    links = parseDOM(result, 'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) #[0]    col-xs-6 col-sm-3 col-lg-2 #<ul class='clearfix pagination'>        links=
    for link in links:
        src = parseDOM(link, 'img', ret='src')[0]
        href = parseDOM(link, 'a', ret='href')[0]   
        plot = parseDOM(link, 'a', ret='data-text')#[0]
        try:
            # title = parseDOM(link, 'div', attrs={'class': "title"})[0]  # to juz nie obowiązuje
            title = parseDOM(link, 'h1', attrs={'class': "film_title"})[0]
        except:
            # xbmc.log(f'[filmancc] [getMovies] awaryjne title',1)
            try:
                title = parseDOM(link, 'a', ret='title')[0]
            except:
                title = "brak tytułu!"
        # originaltitle = title.split(" / ", 1)[-1]
        # title = title.replace(" / " + originaltitle, "", 1)
        try:
            rating = parseDOM(link, 'div', attrs={'class': "rate"})[0]
            # xbmc.log(f'[filmancc] [getMovies] {rating=}',1)
            m = re.match(r"(\d+\.?\d*) \((\d+)\)", rating)
            rating, votes = m[1], m[2]
        except:
            rating = ''
            votes = ''
        try:
            year = int(parseDOM(link, 'div', attrs={'class': "film_year"})[0])
        except:
            year = ''
        if href and title:
            if src.startswith('//'):
                src = 'http:' + src
            film = {
                'href'   : href,
                'title'  : fixSC(title),
                # 'originaltitle': fixSC(originaltitle),
                'plot'   : fixSC(plot[0]) if plot else '',
                # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                'img'    : src,
                # "userrating": rating,  # eksperyment
                'rating' : rating,
                'votes'  : votes,
                'year'   : year,
                # "mediatype": 'movie',  # yatse ma z tym problem
                # "mediatype": 'video',  # fix dla yatse
                    }
            out.append(film)
        pr = page - 1 if page > 1 else False

    return (out, (pr,gr,last_page))    


    
def getSeries(url, page=1, group=''):
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    if '?page=' in url:
        url = url.replace('?page=', '?page=%d' %page)
    else:
        url += '/' if url[-1] != '/' else ''
        url = url + '?page=%d' %page
    if group:
        url = url.split('?')[0]
    content = getUrlReq(url, url)
    out = []
    gr = False
    pr = False
    ids = []

    if group:
        result = parseDOM(content, 'div', attrs={'id': "item-list", "class": "row series-list"}) 
        if 'Ostatnio dodane' in group:
            result = result[0]
        #else:
        #    result = result[1]
            
        links = parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) 
        for link in links:
            src = parseDOM(link, 'img', ret='src')[0]
            href = parseDOM(link, 'a', ret='href')[0]
            plot = parseDOM(link, 'a', ret='data-text')#[0]
            # title = parseDOM(link,'div', attrs={'class': "title"})#[0]  # to juz nie obowiązuje
            title = parseDOM(link, 'h1', attrs={'class': "film_title"})#[0]
            title2 = parseDOM(link,'a', ret='title')#[0]  
            title = title[0] if title else title2[0]
            try:
                rating = parseDOM(link, 'div', attrs={'class': "rate"})[0]
                # xbmc.log(f'[filmancc] [getMovies] {rating=}',1)
                m = re.match(r"(\d+\.?\d*)(?: \((\d*)\))?", rating)
                rating, votes = m[1], m[2]
            except:
                rating = ''
                votes = ''
            try:
                year = int(parseDOM(link, 'div', attrs={'class': "film_year"})[0])
            except:
                year = ''
            if href and title:
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href,
                    'title'  : fixSC(title),
                    'plot'   : fixSC(plot[0]) if plot else '',
                    # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                    'img'    : src,
                    'rating' : rating,
                    'votes'  : votes,
                    'year'   : year,
                        }
                out.append(film)    
    else:
        '''
        result = parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]     
        mdata = parseDOM(content,'div', attrs={'id': "item-list","class":"row series-list"}) [0]     
        mdata = unquote(mdata) if mdata else content
        gr = False
        '''
        try:
            result = parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]
        except:
            result = content        #<ul class='clearfix pagination'>

        mdata = parseDOM(content,'ul', attrs={'class': "clearfix pagination"})#[0]     #<ul class='clearfix pagination'>
        mdata = unquote(mdata[0]) if mdata else content
        gr = False
        if mdata.find( '?page=%d' % (page+1)) > -1:
            gr = page+1    

        last_page = parseDOM(mdata, 'li', attrs={'class': "next"})
        # xbmc.log(f'[filmancc] [getSeries] {last_page=}',1)
        if last_page:
            last_page = last_page[-1]
            last_page = re.search("data-pagenumber='(\d*)'", last_page)
            if last_page:
                last_page = int(last_page[1])
        # xbmc.log(f'[filmancc] [getSeries] {last_page=}',1)

        links = parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) 
        for link in links:
            src = parseDOM(link, 'img', ret='src')[0]
            href = parseDOM(link, 'a', ret='href')[0]
            plot = parseDOM(link, 'a', ret='data-text')#[0]
            title = parseDOM(link,'div', attrs={'class': "title"})#[0]  # to juz nie obowiązuje
            title = parseDOM(link, 'h1', attrs={'class': "film_title"})#[0]
            title2 = parseDOM(link,'a', ret='title')#[0]
            title = title[0] if title else title2[0]
            try:
                rating = parseDOM(link, 'div', attrs={'class': "rate"})[0]
                # xbmc.log(f'[filmancc] [getMovies] {rating=}',1)
                m = re.match(r"(\d+\.?\d*)(?: \((\d*)\))?", rating)
                rating, votes = m[1], m[2]
            except:
                rating = ''
                votes = ''
            try:
                year = int(parseDOM(link, 'div', attrs={'class': "film_year"})[0])
            except:
                year = ''
            if href and title:
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href,
                    'title'  : fixSC(title),
                    'plot'   : fixSC(plot[0]) if plot else '',
                    # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                    'img'    : src,
                    'rating' : rating,
                    'votes'  : votes,
                    'year'   : year,
                        }
                out.append(film)        
        pr = page - 1 if page > 1 else False

    return (out, (pr,gr,last_page))



def parseVideoLink(url, host=''):
    if 'cda' in host:
        return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
    elif 'alltube' in url:
        content = getUrlReq(url,url)
        outurl = ''
        href = re.compile('src="(.*?)"').findall(content)
        if href:
            href = [h for h in href if BRAMKA not in h]
            outurl = getHref(href[0])
            if outurl.startswith('//'):
                outurl = 'http:'+outurl
        return outurl
    elif str(host) in url:
        if url.startswith('//'):
            url = 'http:' + url
        return url
    else:
        return url



def getVideos(url):
    # xbmc.log(f'[filmancc] [getVideos] {url=}', 1)
    content = getUrlReq(url, url)

    # xbmc.log(f'[filmancc] [getVideos] {url=}  {content=}', 1)

    out=[]
    # if "/m/" in url:
    title = parseDOM(content, 'span', attrs={'itemprop': "title"})
    tv_title = parseDOM(content, 'h2',)
    ep_title = ""
    if tv_title:
        title = tv_title
        ep_title = parseDOM(content, 'h3',)
    ep_title = ep_title[0] if ep_title else ""
    title = title[0] if title else ""

    year = parseDOM(content, 'div', attrs={'class': "info"})
    if year:
        year = parseDOM(year, 'li')
        year = year[1] if year else 0
    else:
        year = 0

    plot = parseDOM(content, 'p', attrs={'class': "description"})
    plot = plot[0] if plot else ""
    plot = plot.replace("czytaj dalej", "")

    try:
        rating = parseDOM(content, 'span', attrs={'itemprop': "ratingValue"})[0]
        votes = parseDOM(content, 'span', attrs={'itemprop': "reviewCount"})[0]
    except:
        rating = votes = ""

    try:
        genre = parseDOM(content, 'li', attrs={'itemprop': "genre"})
        # xbmc.log(f'[filmancc] [getVideos] {len(genre)=} {genre=}',1)
        genre = " / ".join(genre)
        genre = stripHTMLTags(genre)
        # xbmc.log(f'[filmancc] [getVideos] {len(genre)=} {genre=}',1)
    except:
        genre = ""

    try:
        pass
        country = parseDOM(content, 'ul', attrs={'class': "country"})[0]
        # xbmc.log(f'[filmancc] [getVideos] {len(country)=} {country=}',1)
        country = parseDOM(country, 'li')[1:]
        country = " /".join(country)
        country = stripHTMLTags(country)
        # xbmc.log(f'[filmancc] [getVideos] {len(country)=} {country=}',1)
    except:
        country = ""

    try:
        director = parseDOM(content, 'ul', attrs={'itemprop': "director"})[0]
        director = stripHTMLTags(director)
        director = director.replace("\n", "").strip()
        # xbmc.log(f'[filmancc] [getVideos] {director=}',1)
        pass
    except:
        director = ""
        pass

    # xbmc.log(f'[filmancc] [getVideos] {title=} {ep_title=} {year=} \n {plot=} \n {rating=} {votes=}', 1)
    try:
        result = parseDOM( (parseDOM(content, 'table', attrs={'id': "links"})[0]), 'tbody' )
        hrefok = ''
        if result:
            # xbmc.log(f'[filmancc]  {result[0]=}', 1)
            links = re.findall('"link-to-video">(.+?)td class="vote', result[0], re.DOTALL)
            if not links:
                # xbmc.log(f'[filmancc]  {links=}', 1)
                # links = re.findall('"link-to-video">(.+?)<\/td', result[0], re.DOTALL)
                links = re.findall('"link-to-video">(.+?)<\/tr', result[0], re.DOTALL)

            # xbmc.log(f'[filmancc] [getVideos] {len(links)=}',1)
            for link in links:
                # xbmc.log(f'[filmancc] {link=}',1)

                if 'bez limitów' in link.lower():
                    # xbmc.log(f'[filmancc] link premium {link=}',1)
                    iframe = re.findall('a href="([^"]+)"', link)
                    # xbmc.log(f'[filmancc] link premium {iframe=}',1)
                    prem2 = True
                else:
                    iframe = re.findall('data\-iframe="([^"]+)"', link)
                    prem2 = False

                try:
                    decodiframe = base64.b64decode(iframe[0])
                    decodiframe = decodiframe.decode(encoding='utf-8', errors='strict') if sys.version_info >= (3,0,0) else decodiframe
                    decodiframe = decodiframe.replace('\/','/')
                    # xbmc.log(f'\n[filmancc] {decodiframe=}',1)
                    if prem2:
                        # xbmc.log(f'\n[filmancc] {decodiframe=}',1)
                        dod = re.findall("""attr\(\\'href\\'\)\)\s*\+\s*\\'(.+?)\\'""", content, re.DOTALL)[0]
                        # xbmc.log(f'[filmancc] do premium {dod=}',1)
                        dod = '|referer=https://filman.cc/&user-agent=Mozilla'
                        hrefok = decodiframe + dod
                        # xbmc.log(f'[filmancc] [getVideos] link premium {hrefok=}',1)
                    else:
                        hrefok = re.findall("""src['"]:['"](.+?)['"]\,""", decodiframe)[0]
                        # xbmc.log(f'[filmancc] link {hrefok=}',1)
                    info = ''.join(re.compile('>(.*?)<', re.DOTALL).findall(link))
                    info = re.sub(' {2,}', ' | ', fixSC(info))#.strip()
                    info = re.sub('\(.+?\)', '', info)
                    info = info.replace(' dodane ', ' | dodane ')
                    info = info.replace('dodane ', '')
                    info = info.strip(" |")
                    cols = info.split(' | ')
                    if hrefok:
                        film = {
                                'url': hrefok,
                                'label': info,
                                'quality': cols[-1],
                                'ago': cols[1].replace('dodane ', ''),
                                }
                        # xbmc.log(f'[filmancc] [getVideos] {film=}', 1)
                        out.append(film)
                except:
                    pass
            if not links:
                czy_konto_premium = my_addon.getSetting('prem')
                if 'true' in czy_konto_premium:
                    xbmc.log(f'[filmancc] [getVideos] brak linków',1)
                else:
                    xbmc.log(f'[filmancc] [getVideos] brak linków, lub jest tylko link premium, do którego nie masz uprawnień',1)
    except:
        pass

    # xbmc.log(f'[filmancc] [getVideos] {len(out)=}', 1)
    # xbmc.log(f'[filmancc] [getVideos] {out=}', 1)
    out = sort_by_ago(out)

    meta = {
            'title': fixSC(title),
            'ep_title': fixSC(ep_title),
            'year': year,
            'plot': fixSC(plot),
            'rating' : rating,
            'votes': votes,
            'genre': genre,
            "country": country,
            "director": director,
            # "writer": writer,
            # "mediatype": mediatype,
            # "cast": cast,
            }
    # xbmc.log(f'[filmancc] [getVideos] {meta=}', 1)

    return out, meta



def scanEpisodes(url):
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    content = getUrlReq(url, url)
    src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(content)
    src = src[-1] if src else ''
    out = []
    odcinki = content.find('Odcinki')
    odcinek = content.find('Dodaj odcinek')
    gdzie = re.findall('Odcinki(.+?)Dodaj odcinek', content, re.DOTALL)[0]
    if 'ten serial nie posiada' in gdzie:
        return out
    links = re.compile('<a href="(.*?)">(.*?)</a>', re.DOTALL).findall(gdzie)
    imgsrc = re.compile('class="col-sm-3">(.+?)<div', re.DOTALL).findall(content)    
    imgsrc = imgsrc[1] if imgsrc else ''
    imgsrc = re.compile('<img src="(.*?)"', re.DOTALL).findall(imgsrc)
    # imgsrc = imgsrc[-1]+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk if imgsrc else ''
    imgsrc = imgsrc[-1] if imgsrc else ''
    for h,t in links:
        t = fixSC(t.strip())
        t = re.sub(' +',' ',t)
        data = re.compile('[sS](\d+)[Ee](\d+)').findall(t)
        film = {
            'href' : h.strip(),
            'plot' : t,
            'title' : t,
            'img' : imgsrc,
            'season' : int(data[0][0]) if data else '',
            'episode' : int(data[0][1]) if data else '',
            'aired' : ''}
        out.append(film)
    return out



def splitToSeasons(dinput):
    out={}
    seasons = [x.get('season') for x in dinput]
    for s in set(seasons):
        out['Sezon %02d'%s]=[dinput[i] for i, j in enumerate(seasons) if j == s]
    return out


def getComments(url):
    # xbmc.log(f'[filmancc] [getComments] {url=}', 1)
    busy()
    content = getUrlReq(url, url)
    # xbmc.log(f'[filmancc] [getComments] {url=}  {content=}', 1)
    try:
        opis = parseDOM(content, 'p', attrs={'class': "description"})[0]
    except:
        opis = ""
    try:
        srednia_ocena = parseDOM(content, 'span', attrs={'itemprop': "ratingValue"})[0]
        ilosc_glosow = parseDOM(content, 'span', attrs={'itemprop': "reviewCount"})[0]
    except:
        srednia_ocena = ilosc_glosow = ""
    comments = parseDOM(content, 'div', attrs={'id': "comments"})
    # comments = parseDOM(comments, 'div', attrs={'class': "comment clearfix"})
    users = parseDOM(comments, 'b',)
    comments = parseDOM(comments, 'p', attrs={'class': "text-justify.+?"})
    # xbmc.log(f'[filmancc] [getComments] {len(comments)=}  \n{comments=} \n{users=}', 1)
    # out = "\n\n".join(comments)
    out = ""
    if opis:
        # out += "[B]"
        # out += "[LIGHT]"
        out += f"{fixSC(opis)}\n\n"
        # out += "[/LIGHT]"
        # out += "[/B]"
        pass
    if srednia_ocena and ilosc_glosow:
        out += f"~[I]Średnia ocena ([LIGHT]wg użytkowników[/LIGHT]): [B]{srednia_ocena}[/B]  ([LIGHT]z[/LIGHT] [B]{ilosc_glosow}[/B] [LIGHT]oddanych głosów[/LIGHT])[/I]\n\n"
    if len(comments):
        for i, u in enumerate(users):
            out += f"\n[{u}]: \n[I][LIGHT]{unescape(stripHTMLTags(comments[i].replace('<br />', ''), exclude='n'))}[/LIGHT][/I]\n\n"
    else:
        out += "\nBRAK KOMENTARZY"
    idle()
    xbmcgui.Dialog().textviewer('Opis i Komentarze użytkowników', out)
    # return out


def stripHTMLTags(html, exclude=""):
    html = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", "", html)
    html = re.sub("<[^>]+>", "", html)
    return html


def getSort(mv='film', sc='category'):
    label = []
    value = []
    url = 'https://filman.cc/filmy/'
    if mv == 'film':
        content = getUrlReq(url, BASEURL)
        if sc == 'category':
            result = parseDOM(content,'ul', attrs={'id': "filter-category"})[0]
            value = parseDOM(result,'li', ret='data-id') #[0]
            label = parseDOM(result,'a')
        elif sc == 'year':
            result = parseDOM(content,'ul', attrs={'id': "filter-year"})[0]
            value = parseDOM(result,'li', ret='data-id') #[0]
            label = parseDOM(result,'a')
        # elif sc == 'country': 
            # result = parseDOM(content,'ul', attrs={'id': "filter-country"})[0]
            # value = parseDOM(result,'li', ret='data-id') #[0]
            # result = re.sub('    HiszpaniaWielka Brytania', 'Hiszpania/Wielka Brytania', result)
            # result = re.sub(r'\s+', ' ', result)
            # label = parseDOM(result,'a')
    elif mv == 'serial':
        pass
    return (label, value)



def search(pharse='dom'):
    # xbmc.log(f'[filmancc] [search] {pharse=}',1)
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    if "://" in pharse:
        url = pharse
    else:
        url = 'https://filman.cc/item?phrase=' + pharse
    content = getUrlReq(url, BASEURL)
    out1 = []  # na filmy
    out2 = []  # na seriale
    result = parseDOM(content, 'div', attrs={'id': "advanced-search"})
    if result:
        result = result[0]
    else:
        result = content
    links = parseDOM(result, 'div', attrs={'class': "poster"})
    years = parseDOM(result, 'div', attrs={'class': "film_year"})
    # titles = parseDOM(result, 'div', attrs={'class': "film_title"})  # można by wykorzystać
    # xbmc.log(f'[search] {len(links)=} {len(years)=} {len(titles)=}',1)  # uwaga na zmienną titles (czy nie zakomentowana)
    zgodnosc = len(links) == len(years)
    # xbmc.log(f'[search] {zgodnosc=}',1)
    # for link in links:
    for i, link in enumerate(links):
        # xbmc.log(f'{i=} {link=}',1)
        src = parseDOM(link, 'img', ret='src')[0]
        src = src.replace('thumb', 'big')
        href = parseDOM(link, 'a', ret='href')[0]
        # title = parseDOM(link,'a', ret='data-title')[0]  # bywa ucięty
        # title = parseDOM(link, 'div', attrs={'class': "title"})[0]  # nie zawsze występuje
        title = parseDOM(link, 'img', ret='alt')[0] 
        # title = titles[i]  # jak z rokiem
        plot = parseDOM(link, 'a', ret='data-text')[0] 
        if href and title:
            if src.startswith('//'):
                src = 'http:' + src
            item = {
                    'href' : href,
                    'title': fixSC(title),
                    'plot' : fixSC(plot),
                    # 'img'  : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                    'img'  : src,
                    'year': years[i],
                   }
            if '/m/' in item['href']:  # film
                out1.append(item)
            else:#elif '/s/' in item['href']: /serial-online/
                out2.append(item)
    return out1, out2  # filmy, seriale



def fixSC(pharse, exclude=""):
    if isinstance(pharse, unicode):
        if sys.version_info >= (3,0,0):
            pharse = pharse
        else:
            pharse = pharse.encode('utf-8')
    pharse = pharse.replace('&lt;br/&gt;', ' ')
   # s = 'JiNcZCs7'
   # pharse = re.sub(s.decode('base64'), '', pharse)
    if "\n" not in exclude and "n" not in exclude:
        pharse = pharse.replace('\n','').replace('\r','').replace('\t','')
    pharse = pharse.replace('&nbsp;','')
    pharse = pharse.replace('&quot;','"').replace('&amp;quot;','"')
    pharse = pharse.replace('&oacute;','ó').replace('&Oacute;','Ó')
    pharse = pharse.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    pharse = pharse.replace('&amp;','&')
    pharse = pharse.replace('\u0105','ą').replace('\u0104','Ą')
    pharse = pharse.replace('\u0107','ć').replace('\u0106','Ć')
    pharse = pharse.replace('\u0119','ę').replace('\u0118','Ę')
    pharse = pharse.replace('\u0142','ł').replace('\u0141','Ł')
    pharse = pharse.replace('\u0144','ń').replace('\u0143','Ń')
    pharse = pharse.replace('\u00f3','ó').replace('\u00d3','Ó')
    pharse = pharse.replace('\u015b','ś').replace('\u015a','Ś')
    pharse = pharse.replace('\u017a','ź').replace('\u0179','Ź')
    pharse = pharse.replace('\u017c','ż').replace('\u017b','Ż')
    return pharse


# Mnożniki jednostek czasu w sekundach
TIME_UNITS = {
    "minutę": 60,
    "minuty": 60,
    "minut": 60,
    "godzinę": 3600,
    "godziny": 3600,
    "godzin": 3600,
    "dzień": 86400,
    "dni": 86400,
    "tydzień": 604800,
    "tygodnie": 604800,
    "tygodni": 604800,
    "miesiąc": 2592000,
    "miesiące": 2592000,
    "miesięcy": 2592000,
    "rok": 31536000,
    "lata": 31536000,
    "lat": 31536000
}


# stworzone przez ChatGPT
def parse_time_string(time_str):
    """
    Przekształca słowny opis czasu w liczbę sekund temu.
    Obsługuje zarówno "1 rok temu", jak i "rok temu".
    """
    match = re.match(r"(?:\b(\d+)\b\s+)?(\w+)", time_str)
    if not match:
        return float('inf')  # Nieznany format – wrzucamy na koniec
    value, unit = match.groups()
    value = int(value) if value else 1  # Domyślnie 1, jeśli brak liczby
    multiplier = TIME_UNITS.get(unit, None)
    if multiplier is None:
        return float('inf')
    return value * multiplier


def sort_by_ago(data, key="ago"):
    """
    Sortuje listę słowników według czasu w polu 'key' (np. 'ago').
    """
    # return sorted(data, key=lambda x: parse_time_string(x[key]))
    return sorted(data, key=lambda x: (parse_time_string(x[key]), -int(x['quality'].replace('p',''))) )
    

def busy():
    Kodi = xbmc.getInfoLabel("System.BuildVersion")[:2]
    try:
        Kodi = int(Kodi)
        if Kodi > 17:
            if not xbmc.getCondVisibility("Window.IsActive(busydialognocancel)") and not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                xbmc.executebuiltin("ActivateWindow(busydialognocancel)")  # Kodi 18
        else:
            if not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                xbmc.executebuiltin("ActivateWindow(busydialog)")  # Kodi 17
    except Exception:
        pass


def idle(mode=0):
    if mode != 2 and xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog)")  # Kodi 17
    if mode != 1 and xbmc.getCondVisibility("Window.IsActive(busydialognocancel)"):
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")  # Kodi 18


mode = args.get('mode', None)

sortv = my_addon.getSetting('sortV')
sortn = my_addon.getSetting('sortN') if sortv else 'Daty dodania'
qualityv = my_addon.getSetting('qualityV')
qualityn = my_addon.getSetting('qualityN') if qualityv else 'Wszystkie'
versionv = my_addon.getSetting('versionV')
versionn = my_addon.getSetting('versionN') if versionv else 'Wszystkie'



def router(paramstring):

    args = dict(parse_qsl(paramstring))
    ex_link = args.get('ex_link', None)
    rys = args.get('iconImage', None)
    page = args.get('page', [1])[0]

    if args:    
        mode = args.get('mode', None)

        if 'filtr:' in mode:
            myMode = mode.split(":")[-1]
            
            if myMode == 'sort':
                label = [u'Daty dodania',    'Filmy z premium', 'Nowe linki', u'Liczba głosów', u'Premiera', u'Odsłony', u'Ocena', u'Ocena FilmWeb']
                value = ['sort:date',    'sort:direct',    'sort:link', 'sort:vote', 'sort:premiere', 'sort:view', 'sort:rate', 'sort:filmweb']    
                msg = 'Sortowanie'

            elif myMode == 'quality':
                label = [u'Wszystkie', u'360p', u'480p', u'720p', u'1080p']
                value = ['', 'quality:1', 'quality:2', 'quality:3', 'quality:4']
                msg = 'Jakość'

            elif myMode == 'version':
                label = ['Wszystkie','Dubbing',   'Dubbing Kino','ENG',      'Lektor',   'Lektor IVO','Napisy',  'Napisy_Tansl',        'PL']
                value = [''         ,'version:2', 'version:6',   'version:5','version:3','version:9', 'version:4','version:10','version:1']
                msg = 'Wersja'
                        
            if myMode in ['quality', 'version']:
                try:
                    sel = xbmcgui.Dialog().select('Wybierz wersje językową', label) #l1l1l11ll11l1l11_nktv_
                except:
                    sel = xbmcgui.Dialog().select('Wybierz wersje językową', label)
                if isinstance(sel, list):
                    if 0 in sel: sel=[0]
                    v = myMode+':'+','.join( [ value[i].replace(myMode+':', '') for i in sel])
                    n = ','.join( [ label[i] for i in sel])
                else:
                    if sel > -1:
                        v = value[sel]
                        n = label[sel]
                        my_addon.setSetting(myMode+'V', v)
                        my_addon.setSetting(myMode+'N', n)
                        xbmc.executebuiltin('Container.Refresh')
                    else:
                        pass
            else:
                sel = xbmcgui.Dialog().select(msg, label)
                if sel > -1:
                    v = value[sel]
                    n = label[sel]
                    my_addon.setSetting(myMode+'V', v)
                    my_addon.setSetting(myMode+'N', n)
                    xbmc.executebuiltin('Container.Refresh()')
                else:
                    pass
        
        elif mode == 'playTv':
            PlayTv(ex_link)
            xbmcplugin.setContent(addon_handle, 'movies')    
            xbmcplugin.endOfDirectory(addon_handle,True)    

        elif mode == 'ListTv':
            listTv(ex_link)
            xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, labelMask="%L", label2Mask="%R, %Y, %P")
            xbmcplugin.setContent(addon_handle, 'movies')        
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'getTvLinks':
            getTvLinks(ex_link, rys)
            xbmcplugin.setContent(addon_handle, 'movies')
            xbmcplugin.endOfDirectory(addon_handle,True)    

        elif mode == 'ListMovies':
            sr = '/'.join([x for x in [sortv, qualityv, versionv] if x]) if '/filmy/' in ex_link else ''
            sr = '' if sr in ex_link else sr
            listMovies(ex_link+sr, page)            
            xbmcplugin.setContent(addon_handle, 'movies')
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'ListMoviesKids':
            listMovies(ex_link, page)
            xbmcplugin.setContent(addon_handle, 'movies')
            xbmcplugin.endOfDirectory(addon_handle,True)    

        elif mode == 'Opcje':
            my_addon.openSettings()
            xbmc.executebuiltin('Container.Refresh()')
        
        elif mode == '__page__M':
            url = build_url({'mode': 'ListMovies',  'foldername': '', 'ex_link': ex_link, 'page': page})
            xbmc.executebuiltin('Container.Update(%s)'% url)
        
        elif mode == '__page__S':
            url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link': ex_link, 'page': page})
            xbmc.executebuiltin('Container.Update(%s)'% url)
        
        elif mode == 'getEpisodes':
            getEpisodes(ex_link)
        
        elif mode == 'getEpisodes2':
            getEpisodes2(ex_link)
            
        elif mode == 'ListSeriale':
            listSeries(ex_link, page)
            if 'Ostatnio dodane seriale' in ex_link:
                xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, labelMask="%L", label2Mask="%R, %Y, %P")
                pass
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, labelMask="%L", label2Mask="%R, %Y, %P")
            xbmcplugin.setContent(addon_handle, 'tvshows')
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'getSeasons':
            getSeasons(ex_link)
        
        elif mode == 'ListFS':
            listFS(ex_link)
            # nie wiem, które będzie najlepsze, trzeba potestować
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask="%R, %Y, %P")  # tu nie będzie się pokazywał atrybut label, tylko title
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, labelMask="%L", label2Mask="%R, %Y, %P")  # powinien pokazywać się atrybut label
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, labelMask="%T", label2Mask="%R, %Y, %P")  # atrybut title
            # xbmcplugin.setContent(addon_handle, 'files')  # FS to może być skrót od FilmSerial
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'getLinks':
            getLinks(ex_link)
        
        elif mode == 'Komentarze':
            # xbmc.log(f'[router] \n{ex_link=}',1)
            getComments(ex_link)
            xbmcplugin.endOfDirectory(addon_handle, True)

        elif mode == 'DOWNLOAD':
            data = eval(ex_link)
            download_path = my_addon.getSetting('download.path')
        
            if download_path:
                getLinks(data.get('href'), True, data.get('title'), data.get('img'))
            else:
                xbmcgui.Dialog().ok('Ustaw docelowy folder', 'Pobieranie nie powiodło się')
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'GatunekRok':
            param = ex_link.split('|')
            label, value = getSort(mv=param[0], sc=param[1])
            try:
                sel = xbmcgui.Dialog().select('Wybierz ', label)
            except:
                sel = xbmcgui.Dialog().select('Wybierz', label)
            if isinstance(sel, list):
                v = param[1]+':'+', '.join([value[i] for i in sel])
            else:
                if sel > -1:
                    sel = sel
                    v = param[1] + ':' + value[sel]
                    sr = '/'.join([x for x in [sortv, qualityv, versionv, v] if x])
                    listMovies('https://filman.cc/filmy/'+sr, 1)
                    xbmcplugin.setContent(addon_handle, 'movies')
                    xbmcplugin.endOfDirectory(addon_handle,True)
                else:
                    xbmc.executebuiltin('Container.Refresh()')            

        elif mode =='Szukaj':
            #global mybtn_user
            mybtn_user = args.get('token', [''])[0]
            addDir('[B][Nowe Szukanie ...][/B]', '', mode='SzukajNowe')
            history = getHistory()
            if not history == ['']:
                for entry in history:
                    contextmenu = []
                    contextmenu.append((u'Usuń z historii', 'Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link': entry, 'token': mybtn_user})),) #, 'token': mybtn_user})
                    contextmenu.append((u'Usuń całą historię', 'Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll', 'token': mybtn_user})),)
                    addDir(name=entry, ex_link=entry.replace(' ', '+'), mode='ListFS', fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(addon_handle,True,cacheToDisc=False)

        elif mode =='SzukajNowe':
            d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
            if d:
                setHistory(d)
                ex_link = d.replace(' ', '+')
                listFS(ex_link)
            # xbmcplugin.setContent(addon_handle, 'tvshows')
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode =='SzukajUsun':
            remCache(ex_link)
            mybtn_user = args.get('token', [''])[0]
            xbmc.executebuiltin('Container.Refresh(%s)'%  build_url({'mode': 'Szukaj', 'token': mybtn_user}))
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'SzukajUsunAll':
            delHistory()
            mybtn_user = args.get('token', [''])[0]
            xbmc.executebuiltin('Container.Refresh(%s)'%  build_url({'mode': 'Szukaj', 'token': mybtn_user}))
            xbmcplugin.endOfDirectory(addon_handle,True)

        elif mode == 'folder':
            pass

    else:
        login()

        if 'true' not in my_addon.getSetting('mono'):
            # addDir(name="Telewizja (LIVE)", ex_link='https://filman.cc/telewizja-online-pl', page=1, mode='ListTv', iconImage='DefaultFolder.png', fanart=FANART)
            addDir('[COLOR yellow][I]SZUKAJ ...[/I][/COLOR]', '', mode='Szukaj', iconImage='DefaultAddonsSearch.png')
            addDir(name="[COLOR lightgreen]Na czasie, na topie[/COLOR]", ex_link='https://filman.cc/online', page=1, mode='ListFS', iconImage='Default.png')
            addDir(name="[COLOR lightskyblue]Filmy[/COLOR]", ex_link='https://filman.cc/filmy/', page=1, mode='ListMovies', iconImage='DefaultMovies.png')
            addDir(name=" [LIGHT][Kategoria][/LIGHT]", ex_link='film|category', page=1, mode='GatunekRok', iconImage='DefaultGenre.png')
            addDir(name=" [LIGHT][Rok][/LIGHT]", ex_link='film|year', page=1, mode='GatunekRok', iconImage='DefaultYear.png')
            # addDir(name=" [LIGHT][Kraj][/LIGHT]", ex_link='film|country', page=1, mode='GatunekRok', iconImage='DefaultFolder.png', fanart=FANART)
            addDir(name="[COLOR cyan]Seriale[/COLOR]", ex_link='https://filman.cc/seriale/', page=1, mode='ListSeriale', iconImage='DefaultTVShows.png')
            # addDir(name=" [COLOR lightgreen]Ostatnio dodane seriale[/COLOR]", ex_link='https://filman.cc/seriale/|Ostatnio dodane seriale', page=1, mode='ListSeriale', iconImage='DefaultRecentlyAddedEpisodes.png')
            # addDir(name=" Popularne seriale", ex_link='https://filman.cc/seriale/|Popularne seriale', page=1, mode='ListSeriale', iconImage='DefaultFolder.png')
            # addDir(name=" Popularne tematy", ex_link='https://filman.cc/popularne', page=0, mode='ListPopularne', iconImage='DefaultFolder.png')
            addDir(name="[COLOR darkorange]Dla dzieci[/COLOR]", ex_link='https://filman.cc/dla-dzieci-pl/', page=1, mode='ListMovies', iconImage='DefaultAddonImages.png')
            # addDir(name="[COLOR magenta]Zaskocz mnie[/COLOR]", ex_link='https://filman.cc/zaskocz-mnie', page=0, mode='getMovie', iconImage='DefaultFolder.png')
            addLinkItem('[COLOR lightpink]Zaskocz mnie[/COLOR]', 'https://filman.cc/zaskocz-mnie', 'getLinks', iconimage='DefaultAddon.png', fanart=None, IsPlayable=True, infoLabels={"title": "niespodzianka", "plot": "losowo wybrany film"})
            addLinkItem("[COLOR powderblue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]", '', mode='filtr:sort', iconimage='DefaultAddonService.png', IsPlayable=False)
            addLinkItem("[COLOR powderblue]Jakość:[/COLOR] [B]"+qualityn+"[/B]", '', mode='filtr:quality', iconimage='DefaultAddonService.png', IsPlayable=False)
            addLinkItem("[COLOR powderblue]Wersja:[/COLOR] [B]"+versionn+"[/B]", '', mode='filtr:version', iconimage='DefaultAddonService.png', IsPlayable=False)
            addLinkItem('[I]-=Opcje=-[/I]', '', 'Opcje', iconimage='DefaultAddonProgram.png', IsPlayable=False)
        else:
            # addDir(name="Telewizja (LIVE)", ex_link='https://filman.cc/telewizja-online-pl', page=1, mode='ListTv', iconImage='DefaultFolder.png', fanart=FANART)
            addDir('[I]SZUKAJ ...[/I]', '', mode='Szukaj', iconImage='DefaultAddonsSearch.png')
            addDir(name="Na czasie, na topie", ex_link='https://filman.cc/online', page=1, mode='ListFS', iconImage='Default.png')
            addDir(name="Filmy", ex_link='https://filman.cc/filmy/', page=1, mode='ListMovies', iconImage='DefaultMovies.png')
            addDir(name=" [LIGHT][Kategoria][/LIGHT]", ex_link='film|category', page=1, mode='GatunekRok', iconImage='DefaultGenre.png')
            addDir(name=" [LIGHT][Rok][/LIGHT]", ex_link='film|year', page=1, mode='GatunekRok', iconImage='DefaultYear.png')
            # addDir(name=" [LIGHT][Kraj][/LIGHT]", ex_link='film|country', page=1, mode='GatunekRok', iconImage='DefaultFolder.png', fanart=FANART)
            addDir(name="Seriale", ex_link='https://filman.cc/seriale/', page=1, mode='ListSeriale', iconImage='DefaultTVShows.png')
            # addDir(name=" Ostatnio dodane seriale", ex_link='https://filman.cc/seriale/|Ostatnio dodane seriale', page=1, mode='ListSeriale', iconImage='DefaultRecentlyAddedEpisodes.png')
            # addDir(name=" Popularne seriale", ex_link='https://filman.cc/seriale/|Popularne seriale', page=1, mode='ListSeriale', iconImage='DefaultFolder.png')
            # addDir(name=" Popularne tematy", ex_link='https://filman.cc/popularne', page=0, mode='ListPopularne', iconImage='DefaultFolder.png')
            addDir(name="Dla dzieci", ex_link='https://filman.cc/dla-dzieci-pl/', page=1, mode='ListMovies', iconImage='DefaultAddonImages.png')
            # addDir(name="[COLOR magenta]Zaskocz mnie[/COLOR]", ex_link='https://filman.cc/zaskocz-mnie', page=0, mode='getMovie', iconImage='DefaultFolder.png')
            addLinkItem('Zaskocz mnie', 'https://filman.cc/zaskocz-mnie', 'getLinks', iconimage='DefaultAddon.png', fanart=None, IsPlayable=True, infoLabels={"title": "niespodzianka", "plot": "losowo wybrany film"})
            addLinkItem("[COLOR lightgrey]Sortowanie:[/COLOR] [B]"+sortn+"[/B]", '', mode='filtr:sort', iconimage='DefaultAddonService.png', IsPlayable=False)
            addLinkItem("[COLOR lightgrey]Jakość:[/COLOR] [B]"+qualityn+"[/B]", '', mode='filtr:quality', iconimage='DefaultAddonService.png', IsPlayable=False)
            addLinkItem("[COLOR lightgrey]Wersja:[/COLOR] [B]"+versionn+"[/B]", '', mode='filtr:version', iconimage='DefaultAddonService.png', IsPlayable=False)
            addLinkItem('[I]-=Opcje=-[/I]', '', 'Opcje', iconimage='DefaultAddonProgram.png', IsPlayable=False)

        xbmcplugin.setContent(addon_handle, 'files')
        xbmcplugin.endOfDirectory(addon_handle,True)

if __name__ == '__main__':
    router(sys.argv[2][1:])    
