"""
    FanFilm Project
"""

import os
import re
from urllib.parse import parse_qs, urlencode, quote_plus, unquote

from ptw.libraries import cleantitle, control, source_utils, log_utils
from ptw.debug import log_exception, fflog_exc, fflog


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.ext = ["mp4", "mkv", "flv", "avi", "mpg"]
        self.movie_path = control.setting("movie.download.path")
        self.tv_path = control.setting("tv.download.path")

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            # fflog(f'{title=} {localtitle=}')
            #title = re.sub(" ", "", title)  # why? downloader tego nie ma
            transname = re.sub(r"/|:|\*|\?|\"|<|>|\+|,|\.|", "", cleantitle.normalize(title))
            transname += " (%s)" % year
            dest = self.movie_path
            dest = control.transPath(dest)
            dest = os.path.join(dest, transname)
            return urlencode({"imdb": imdb, "title": title, "localtitle": localtitle, "year": year, "path": dest, "filename": transname, })
        except Exception:
            fflog_exc(1)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            # fflog(f'{tvshowtitle=} {localtvshowtitle=}')
            url = {"imdb": imdb, "tvdb": tvdb, "tvshowtitle": tvshowtitle, "year": year}
            url = urlencode(url)
            return url
        except Exception:
            #log_utils.log("pobrane - Exception", "sources")
            fflog_exc(1)

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            # fflog(f'{url=}')
            if url is None:
                return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, "") for i in url])
            #transname = unquote(quote_plus(re.sub(r"/|:|\*|\?|\"|<|>|", "", cleantitle.normalize(url["tvshowtitle"]), )))
            transname = re.sub(r"/|:|\*|\?|\"|<|>|", "", cleantitle.normalize(url["tvshowtitle"]))
            transname += f' ({url.get("year")})' if url.get("year") else ''  # dodanie roku do nazwy folderu i pliku
            dest = self.tv_path
            dest = control.transPath(dest)
            dest = os.path.join(dest, transname)
            dest = os.path.join(dest, "Season %01d" % int(season))

            (url["title"], url["premiered"], url["season"], url["episode"], url["path"], url["filename"],) = (
                title, premiered, season, episode, dest, transname)
            url = urlencode(url)
            return url
        except Exception:
            fflog_exc(1)

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # fflog(f'{url=}')
        try:
            if url is None:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, "") for i in data])
            path = data["path"]
            filename = data["filename"]
            year = data["year"] or ""

            if "tvshowtitle" in data:
                #filename = re.sub(r"\+", " ", data["filename"])  # pozbycie się plusów z nazwy ? a czemu nie przez zwykłe replace ?
                filename += " S%02dE%02d" % (int(data["season"]), int(data["episode"]),)
            else:
                filename = data["filename"]

            # fflog(f'{path=}')
            url = None
            if os.path.exists(path):
                #fflog(f'wariant 1')
                for r, d, f in os.walk(path):
                    for file in f:
                        # fflog(f'{filename=} {file=}')
                        if filename in file:
                        #if filename in file or filename in re.sub(r" \[.*\]", "", file):  # nie ma takiej potrzeby, bo te oznaczenia są na końcu nazwy
                            if [file.endswith(ext) for ext in self.ext]:
                                url = os.path.join(r, file)
                                #fflog(f'OK 1')
                                break
                        else:
                            #fflog(f'dupa 1')
                            pass
            # dla kompatybilności z wcześniej pobranymi, gdzie rok nie był zapisywany
            if not url and os.path.exists(path.replace(f" ({year})", "")):
                #fflog(f'wariant 2')
                filename = filename.replace(f" ({year})", "")
                for r, d, f in os.walk(path.replace(f" ({year})", "")):
                    for file in f:
                        # fflog(f'{filename=} {file=}')
                        if filename in file.replace(f" ({year})", ""):  # tu trzeba, bo rok dla serialu jest w "środku" (przed numerem odcinka)
                            if [file.endswith(ext) for ext in self.ext]:
                                url = os.path.join(r, file)
                                #fflog(f'OK 2')
                                break
                        else:
                            #fflog(f'dupa 2')
                            pass
            # jeszcze trzeba zrobić wariant, dla nazw, które mają na końcu identyfikator z bazy serwisu internetowego,
            # np. "/Blade Runner (2017) {tmdb=335984}/Blade Runner (2017) {tmdb=335984}.mkv"
            # https://kodi.wiki/view/Naming_video_files/Movies

            if url:

                size = ""
                import xbmcvfs
                try:
                    st = xbmcvfs.Stat(url)  # chyba to samo co os.stat(file_name with path)
                    size = st.st_size()
                except:
                    try:
                        with xbmcvfs.File(url) as f:
                            size = f.size()
                    except:
                        pass
                size = source_utils.convert_size(size)

                quality = source_utils.check_sd_url(file)

                #info0 = m[1] if (m := re.search(r" \[(.*)\]", file)) else ""  # pozyskane z nawiasów kwadratowych
                all_infos = re.findall(r"\s*\[(.*?)\]", file)  # może też być każdy parametr w innym nawiasie
                info0 = " / ".join(all_infos)

                lang, lang_info = source_utils.get_lang_by_type(file)

                info = re.sub(rf"\s*({lang}|{quality})\b", "", info0,  flags=re.I)
                info = re.sub(r"^\s[/|]\s|\s[/|]\s$|[/|]\s(?=[/|])", "", info)  # porządki
                info += f" / {lang_info}" if lang_info and lang_info not in info else ""
                info += f" | {size}" if size else ""

                sources.append({
                    #"source": "pobrane",
                    "source": "",  # aby nie dublować słowa, bo "provider" będzie i tak "pobrane"
                    "quality": "HD" if not info0 else quality,
                    "language": lang,
                    "url": url,
                    "info": info,
                    "direct": True,
                    "debridonly": False,
                    "size": size if size else "",
                    "filename": file,
                    # "on_account": True, # nie ma takiej potrzeby
                })

            fflog(f'przekazano źródeł: {len(sources)}')
            return sources
        except Exception:
            #log_utils.log("pobrane - Exception", "sources")
            fflog_exc(1)
            return sources

    def resolve(self, url):
        # fflog(f'{url=}')
        return url
