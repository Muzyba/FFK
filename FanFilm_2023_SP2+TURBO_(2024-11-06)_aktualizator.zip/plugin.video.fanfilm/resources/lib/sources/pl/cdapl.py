"""
    FanFilm Add-on
    Copyright (C) 2018 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import json
import requests
import urllib.parse as urllib
from html import unescape
from ptw.libraries import source_utils, cleantitle, client, control
from ptw.debug import log_exception, fflog_exc, fflog


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["cda.pl"]

        self.base_link = "https://www.cda.pl/"
        self.search_link = "video/show/%s?duration=dlugie&section=&quality=all&section=&s=best&section="
        self.search_link_ep = "video/show/%s?duration=srednie&section=&quality=all&section=&s=best&section="
        self.anime = False
        self.year = 0
        """
        self.headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/jxl,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3", "Accept-Encoding": "gzip, deflate, br", "DNT": "1",
            "Connection": "keep-alive", "Upgrade-Insecure-Requests": "1", "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "same-origin", "Sec-Fetch-User": "?1", "Pragma": "no-cache",
            "Cache-Control": "no-cache", "TE": "trailers", }
        """
        self.headers = {"User-Agent": "vlc"}
        # self.headers = {}


    def contains_all_words(self, str_to_check, words):
        if self.anime:
            words_to_check = str_to_check.split(" ")
            for word in words_to_check:
                try:
                    liczba = int(word)
                    for word2 in words:
                        try:
                            liczba2 = int(word2)
                            if (liczba != liczba2 and liczba2 != self.year and liczba != self.year):
                                return False
                        except:
                            continue
                except:
                    continue

        str_to_check = cleantitle.get_title(str_to_check).split()
        words = list(filter(None, words))
        if not words:
            fflog(f'{words=}')
            raise Exception("Błąd", "zmienna nie może być pusta")
        for word in words:
            word = cleantitle.get_title(word)
            if not word:
                continue
            if not word in str_to_check:
                return False
        return True


    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, year, True)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle), year


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        anime = source_utils.is_anime("show", "tvdb", tvdb)
        self.year = int(url[1])
        self.anime = anime
        if anime:
            epNo = " " + source_utils.absoluteNumber(tvdb, episode, season)
        if not anime or not epNo:
            epNo = " s" + season.zfill(2) + "e" + episode.zfill(2)
        return self.search_ep(url[0][0] + epNo, url[0][1] + epNo)


    def search_ep(self, title1, title2):
        try:
            titles = [cleantitle.normalize(cleantitle.getsearch(title1)),
                      cleantitle.normalize(cleantitle.getsearch(title2)), ]

            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów

            links = []

            #session = requests.session()
            #session.get("https://cda.pl")

            for title in titles:
                try:
                    if not title:
                        continue

                    url = urllib.urljoin(self.base_link, self.search_link_ep)
                    url = url % urllib.quote(str(title).replace(" ", "_"))

                    self.headers.update({"Referer": url})
                    # fflog(f'{url=}')
                    #result = session.get(url, headers=self.headers)
                    result = requests.get(url, headers=self.headers)
                    # fflog(f'{result=}')
                    result = result.text
                    # fflog(f'{result=}')
                    result = client.parseDOM(result, "div", attrs={"class": "video-clip-wrapper"})
                except:
                    continue

                for item in result:
                    try:
                        link = str(client.parseDOM(item, "a", ret="href")[0])

                        nazwa = str(client.parseDOM(item, "a", attrs={"class": "link-title-visit"})[0])
                        # nazwa = nazwa.replace("[", " ").replace("]", " ")  # zmieniłem w cleantitle.py
                        nazwa = nazwa.replace(".", " ")
                        name = cleantitle.normalize(cleantitle.getsearch(nazwa))
                        name = name.replace("  ", " ")

                        title = title.replace(".", " ")
                        title = title.replace("the ", " ")
                        title = title.replace("  ", " ")
                        words = title.split(" ")

                        title2 = title.replace("s01", "")
                        words2 = title2.split(" ")

                        title3 = title.replace("s01e", "")
                        words3 = title3.split(" ")

                        title4 = title.replace("s01e0", "")
                        words4 = title4.split(" ")

                        # fflog(f'{name=} | {title=} {words=} {year=}')
                        if(
                               self.contains_all_words(name, words)
                            or self.contains_all_words(name, words2)
                            or self.contains_all_words(name, words3)
                            or self.contains_all_words(name, words4)
                            ):
                            # fflog(f'pasuje {link=}')
                            links.append(link)
                        else:
                            # fflog(f'odrzucono,\n         bo {name=}, \na szukamy: {title=} -> {words=}  \n     lub  {title2=} ->   {words2=}  \n     lub  {title3=} ->    {words3=}  \n     lub  {title4=} ->     {words4=}')
                            pass
                    except:
                        continue

            return links
        except Exception as e:
            print(e)
            fflog_exc()
            return


    def search(self, title, localtitle, year, is_movie_search):
        try:
            title, localtitle = localtitle, title  # zamianka

            titles = [cleantitle.normalize(cleantitle.getsearch(title)),
                      cleantitle.normalize(cleantitle.getsearch(localtitle)), ]

            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów

            links = []
            #session = requests.session()
            #session.get("https://cda.pl")

            for title in titles:
                try:
                    if not title:
                        continue

                    url = urllib.urljoin(self.base_link, self.search_link)
                    url = url % urllib.quote(str(title).replace(" ", "_"))

                    self.headers.update({"Referer": url})
                    # fflog(f'{url=}')
                    #result = session.get(url, headers=self.headers)
                    result = requests.get(url, headers=self.headers)
                    # fflog(f'{result=}')
                    result = result.text
                    # fflog(f'{result=}')

                    # NB. Original query string below. It seems impossible to parse and
                    # reproduce query strings 100% accurately so the one below is given
                    # in case the reproduced version is not "correct".
                    # response = requests.get('https://www.cda.pl/video/show/w%C5%82adca_pier%C5%9Bcieni?duration=srednie&section=&quality=720p&section=&s=best&section=', headers=headers, cookies=cookies)
                    result = client.parseDOM(result, "div", attrs={"class": "video-clip-wrapper"})
                    # fflog(f'{len(result)=}')
                except:
                    continue
                # fflog(f'{len(result)=} {result=}')
                for item in result:
                    try:
                        link = str(client.parseDOM(item, "a", ret="href")[0])
                        # fflog(f'{link=}')

                        nazwa = str(client.parseDOM(item, "a", attrs={"class": "link-title-visit"})[0])
                        # fflog(f'{nazwa=}')
                        nazwa = nazwa.replace(".", " ")
                        name = cleantitle.normalize(cleantitle.getsearch(nazwa))
                        name = name.replace("  ", " ")

                        title = title.replace(".", " ")
                        title = title.replace("the ", " ")
                        title = title.replace("  ", " ")
                        words = title.split(" ")

                        # fflog(f'{name=} | {title=} {words=} {year=}')
                        if (
                            self.contains_all_words(name, words)
                            and (str(year) in name
                                 or str(int(year)-1) in name
                                 or not re.search(r"\b\d{4}\b", name)  # gdy nie ma w ogóle roku w nazwie pliku
                                )
                           ):
                            # fflog(f'może pasować {link=}')
                            links.append(link)
                        else:
                            # fflog(f'odrzucono {link=}')
                            # fflog(f'odrzucono, bo {name=}, a szukamy: {title=} -> {words=}   ({year=})')
                            pass
                        # fflog(f'\n')
                    except:
                        continue
            # fflog(f'{len(links)=} {links=}')
            if not links:
                fflog('nie znaleziono pasujących')
            return links
        except Exception as e:
            print(e)
            return


    def sources(self, links, hostDict, hostprDict):
        # fflog(f'{links=}')
        if links is None or not links:
            return []
        links = list(dict.fromkeys(links))  # pozbycie się duplikatów
        sources = []
        # session = requests.session()
        # session.get("https://cda.pl")
        user_max_quality = control.setting("hosts.quality")
        if user_max_quality == "":
            user_max_quality = "0"
        user_max_qmax = int(user_max_quality)
        quality_order = [2160, 1440, 1080, 720, 480]
        try:
            for lnk in links:
                try:
                    # fflog(f'{lnk=}')
                    if lnk is None:
                        return sources
                    url = urllib.urljoin(self.base_link, lnk)
                    # fflog(f'{url=} {lnk=}')
                    if "/folder/" in lnk:
                        continue
                    if url == lnk or "/vfilm" in lnk:
                        # fflog(f'materiał dostępny tylko dla premium ({lnk=})')
                        fflog('dostępny tylko dla premium')
                        continue

                    rozdz = "647x500"
                    rozdz = "620x368"  # nie wiem, czemu teraz taką daje
                    # ale chyba rozdzielczość może być dowolna
                    result2 = None
                    # fflog(f'adres odtwarzacza: {f"https://ebd.cda.pl/{rozdz}/" + url.split("/")[-1]}')
                    #result2 = client.request(f"https://ebd.cda.pl/{rozdz}/" + url.split("/")[-1], headers=self.headers)  # pierwotnie taka komenda była (client.request), tylko bez headers
                    if result2 is None:
                        # fflog(f'{result2=}')
                        result2 = requests.get(f"https://ebd.cda.pl/{rozdz}/" + url.split("/")[-1], headers=self.headers)
                        pass
                    # result2 = session.get(f"https://ebd.cda.pl/{rozdz}/" + url.split("/")[-1], headers=self.headers)
                    # fflog(f'{result2=}')

                    if result2 and not isinstance(result2, str):  # potrzebne gdy używam client.request
                        result2 = result2.text
                        # fflog(f'{result2=}')

                    try:
                        title = client.parseDOM(result2, "title")[0]
                        # fflog(f'{title=}')
                    except Exception:
                        # fflog_exc(1)
                        if result2 and (material_niedostepny := "Materiał na który wskazywał ten link został usunięty przez jego właściciela lub Administratora") in result2:
                            fflog(f'{material_niedostepny}')
                            pass
                        elif result2 and (material_niedostepny := "Ten film jest dostępny dla użytkowników premium") in result2:
                            fflog(f'{material_niedostepny}')
                            pass
                        else:
                            fflog(f'wystąpił jakiś błąd')
                            fflog(f'{result2=}')
                            pass
                        continue

                    lang, info = self.get_lang_by_type(title)
                    valid, host = source_utils.is_host_valid(url, hostDict)  # olać to, bo nie wiem czemu, ale czasami wypisuje mi, że "host='cda.pl' not valid - sorry" (ale mógł to być błąd w kodzie resolvera, bo grzebałem tam ;)
                    # fflog(f'{valid=} {host=} {lang=} {info=} {title=}')
                    # match = re.search(r'player_data="([^"]+)"', result2) or re.search(r"player_data='([^']+)'", result2)  # czy to nie bezpieczniejsze niż poniższy miks?
                    match = re.search(r'player_data="([^"]*)"', result2) or re.search(r"player_data='([^']*)'", result2)  # czy to nie bezpieczniejsze niż poniższy miks?
                    # match = re.search(r'player_data=("|\')([^\1]+)\1', result2)  # coś nie działa jak trzeba
                    # match = re.search(r'player_data=("|\')(.*?)\1', result2)  # to działa
                    if match and match.group(1):
                    # if match and match.group(2):
                        # fflog(f'{match=}')
                        pdata = json.loads(unescape(match.group(1)))
                        # pdata = json.loads(unescape(match.group(2)))
                        # fflog(f'{pdata=}')
                        vdata = pdata.get('video', {})
                        # fflog(f'{vdata=}')
                        qdata = vdata.get('qualities')
                        # fflog(f'{qdata=}')
                        fdata = vdata.get('file')  # zakodowany directlink
                        # fflog(f'{fdata=}')
                        cda_sources = [(q, '?wersja={0}'.format(q)) for q in qdata.keys()]
                        # fflog(f'{cda_sources=} {len(cda_sources)=}')
                        if len(cda_sources) > 0:
                            if not valid:  # olać to
                                fflog(f'{host=} not valid - sorry')
                                #continue  # olewam to, choć jak się takie coś pojawi, to może być problem z odtworzeniem (miałem tak, ale okazało się, że był błąd w kodzie resolvera)
                                pass
                            for q in reversed(cda_sources):
                                # fflog(f'{url=} {q=}')
                                #if len(cda_sources) == 1 or int(q[0].replace("p" ,"")) >= 480:
                                if quality_order[user_max_qmax] >= int(q[0].replace("p" ,"")):
                                    sources.append({
                                        "source": host,
                                        "quality": source_utils.label_to_quality(q[0]),
                                        "url": url + q[1],
                                        "language": lang,
                                        "info": info,
                                        "info2": title,
                                        "direct": False,  # jak False, to idzie przes resolvera (Gujala), a do True, to trzeba samemu dołożyć dekoder, więc może lepiej skorzystać z gotowca
                                        "debridonly": False,
                                    })
                                    break  # tylko maksymalną jakość
                    else:
                        fflog(f'wystąpił jakiś problem {match=}')

                except Exception:
                    fflog_exc(1)
                    continue

            # fflog(f'{sources=}')
            fflog(f'przekazano źródeł: {len(sources)}')
            return sources

        except Exception as e:
            print(e)
            fflog_exc(1)
            return sources


    def get_lang_by_type(self, lang_type):
        if "dubbing" in lang_type.lower():
            if "kino" in lang_type.lower():
                return "pl", "Dubbing Kino"
            return "pl", "Dubbing"
        elif "napisy pl" in lang_type.lower():
            return "pl", "Napisy"
        elif "napisy" in lang_type.lower():
            return "pl", "Napisy"
        elif "lektor pl" in lang_type.lower():
            return "pl", "Lektor"
        elif "lektor" in lang_type.lower():
            return "pl", "Lektor"
        elif "POLSKI" in lang_type.lower():
            return "pl", None
        elif "pl" in lang_type.lower():
            return "pl", None
        return "pl", None


    def cda_decode(self, a):
        a = a.replace("_XDDD", "")
        a = a.replace("_CDA", "")
        a = a.replace("_ADC", "")
        a = a.replace("_CXD", "")
        a = a.replace("_QWE", "")
        a = a.replace("_Q5", "")
        a = a.replace("_IKSDE", "")
        a = urllib_parse.unquote(a)
        a = ''.join([chr(33 + (ord(char) + 14) % 94) if 32 < ord(char) < 127 else char for char in a])
        a = a.replace(".cda.mp4", "")
        a = a.replace(".2cda.pl", ".cda.pl")
        a = a.replace(".3cda.pl", ".cda.pl")
        return "https://{0}.mp4".format(a)


    def resolve(self, url):
        #fflog(f' {url=}')
        url = str(url).replace("//", "/").replace(":/", "://")
        # url = url.split("?")[0]  # wycina jakość (ale KODI i tak wybiera maksymalną (bo to nie directlink), choć to może zależeć od ustawień jakiegoś dodatku)
        fflog(f'{url=}')
        return url
