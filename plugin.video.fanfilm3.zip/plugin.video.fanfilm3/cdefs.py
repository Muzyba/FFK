"""
FanFilm const (low-level developper) settings.
Do NOT change if you don't know what you doing.

Avoid imports here, please.
Supports `local.py` from plugin userdata folder. File is created if missing.

You can override settings in `local.py`.
Just in the same form as in section "CONST SETTINGS",
>>> const.name = value


Define new setting
------------------

To create new const settings (ex. `const.a.b.c` as `int`) you have to:
 - define the settings
 - assing the value

Define new settings in `class const` structure in "CONST DEFINITION" section.
Every section (ex. `a.b.`) must be a class with `@constdef` decorator.
The name after the last dot (ex. `c`) have to be defined as a class variable with a type annotations.
DO NOT assign default value here.
>>> @constdef
>>> class const:
>>>    @constdef
>>>    class a:
>>>        @constdef
>>>        class b:
>>>            c: int

And just assign values in following "CONST SETTINGS" section.
>>> const.a.b.c = value

Every value `const.x.y = value` must be defined in `class const` structure.
Every value defined settings in `class const` structure must be assigned.


Use const settings
------------------

And use in source code.
>>> from const import const
>>> if const.a.b.c == value: ...
"""

# Only safe imports here, double check BEFORE add something new.
import runpy
from pathlib import Path
from typing import Optional, Union, Any, Dict, Set, Tuple, Collection, Sequence, TypeVar, Type, TYPE_CHECKING
from typing_extensions import Literal
from lib.indexers.defs import DirItemSource, CodeId
if TYPE_CHECKING:
    from lib.ff.menu import ContentView

T = TypeVar('T')

#: ID of source color match: PROVIDER or (PROVIDER, SOURCE).
ExSourceId = Union[str, Tuple[str, str]]
#: Supported prgramt Tv services.
ProgramTvService = Literal['filmweb', 'onet']
#: 
ExtSourceId = str


def constdef(cls: Type[T]) -> T:
    """Const section definition decorator."""

    def __init__(self) -> None:
        cls = type(self)
        ann = getattr(cls, '__annotations__', {})
        for k, v in vars(cls).items():
            if not k.startswith('_'):
                if getattr(v, '_const_def', None):
                    object.__setattr__(self, k, v)
                elif k in ann:
                    name = f'{cls.__qualname__}.{k}'
                    raise TypeError(f'Value for {name!r} is FORBIDEN, assign it in "CONST SETTINGS"')
                else:
                    raise TypeError(f'Pure class {k!r} in {cls.__qualname__!r} is FORBIDEN, use @constdef')

    def __setattr__(self, key: str, value: Any) -> None:
        if not key.startswith('_'):
            cls = self.__class__
            if key not in getattr(cls, '__annotations__', {}):
                raise AttributeError(f'No const attribute {cls.__qualname__}.{key}')
            if getattr(constdef, '_locked', False) and (old := getattr(self, key, ...)) is not ...:
                print(f'WARNING: redefine {cls.__qualname__}: {old!r} -> {value!r}')
                raise RuntimeError(f'WARNING: redefine {cls.__qualname__}: {old!r} -> {value!r}')
        object.__setattr__(self, key, value)

    def __repr__(self) -> str:
        return f'<{self.__class__.__qualname__}>'

    cls.__init__ = __init__
    cls.__setattr__ = __setattr__
    cls.__repr__ = __repr__
    cls._const_def = True  # type: ignore
    return cls()


all_languages = (
    'aa', 'ab', 'ae', 'af', 'ak', 'am', 'an', 'ar', 'as', 'av', 'ay', 'az', 'ba', 'be', 'bg', 'bi', 'bm', 'bn', 'bo',
    'br', 'bs', 'ca', 'ce', 'ch', 'cn', 'co', 'cr', 'cs', 'cu', 'cv', 'cy', 'da', 'de', 'dv', 'dz', 'ee', 'el', 'en',
    'eo', 'es', 'et', 'eu', 'fa', 'ff', 'fi', 'fj', 'fo', 'fr', 'fy', 'ga', 'gd', 'gl', 'gn', 'gu', 'gv', 'ha', 'he',
    'hi', 'ho', 'hr', 'ht', 'hu', 'hy', 'hz', 'ia', 'id', 'ie', 'ig', 'ii', 'ik', 'io', 'is', 'it', 'iu', 'ja', 'jv',
    'ka', 'kg', 'ki', 'kj', 'kk', 'kl', 'km', 'kn', 'ko', 'kr', 'ks', 'ku', 'kv', 'kw', 'ky', 'la', 'lb', 'lg', 'li',
    'ln', 'lo', 'lt', 'lu', 'lv', 'mg', 'mh', 'mi', 'mk', 'ml', 'mn', 'mo', 'mr', 'ms', 'mt', 'my', 'na', 'nb', 'nd',
    'ne', 'ng', 'nl', 'nn', 'no', 'nr', 'nv', 'ny', 'oc', 'oj', 'om', 'or', 'os', 'pa', 'pi', 'pl', 'ps', 'pt', 'qu',
    'rm', 'rn', 'ro', 'ru', 'rw', 'sa', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sk', 'sl', 'sm', 'sn', 'so', 'sq', 'sr',
    'ss', 'st', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'ti', 'tk', 'tl', 'tn', 'to', 'tr', 'ts', 'tt', 'tw', 'ty',
    'ug', 'uk', 'ur', 'uz', 've', 'vi', 'vo', 'wa', 'wo', 'xh', 'xx', 'yi', 'yo', 'za', 'zh', 'zu',
)


# ----------------------------------------------------------------------------- #
# -----                          CONST DEFINITION                         ----- #
# ----------------------------------------------------------------------------- #


@constdef
class const:
    """Const (low-level developper) settings."""

    @constdef
    class debug:
        enabled: bool
        tty: bool
        crash_menu: bool
        autoreload: bool

    @constdef
    class debugger:
        enabled: bool

    @constdef
    class dev:

        @constdef
        class tmdb:
            api_key: Optional[str]
            session_id: Optional[str]

        @constdef
        class trakt:
            client: Optional[str]
            secret: Optional[str]

        @constdef
        class db:
            echo: bool

    @constdef
    class core:
        exit_every_nth: int
        volatile_dbid: bool
        volatile_seasons: bool

        @constdef
        class info:
            save_cache: bool
            copy_year: bool

    @constdef
    class media:
        @constdef
        class progress:
            as_watched: int

            @constdef
            class show:
                episodes_watched: bool

    @constdef
    class sources_dialog:
        index_color: str
        override_color: Dict[ExSourceId, str]
        show_empty: bool
        rescan_edit: bool
        external_quality_label: Dict[ExtSourceId, str]

        @constdef
        class edit_search:
            in_menu: bool
            in_dialog: bool
            in_filters: bool

    # ----- Folders -----
    @constdef
    class folder:
        cache_to_disc: bool
        wait_for_refresh_timeout: float
        refresh_delay: float
        db_save: bool
        script_autorefresh: bool
        previous_page: Literal['never', 'always', 'on_last_page']
        max_page_jump: int
        fanart_fallback: Optional[Literal['landscape', 'poster', 'thumb', 'banner', 'clearlogo']]

        @constdef
        class style:
            future: Optional[str]
            role: Optional[str]
            broken: Optional[str]

    # ----- Indexes -----
    @constdef
    class indexer:
        region: str

        @constdef
        class art:
            fake_thumb: bool

        @constdef
        class progressbar:
            style: str
            mode: Literal['none', 'watching', 'watched', 'percent', 'percent_and_watched']
            width: int

            @constdef
            class fill:
                color: str
                char: str

            @constdef
            class partial:
                color: str
                char: str

            @constdef
            class empty:
                color: str
                char: str

            @constdef
            class watched:
                color: str
                char: str

        @constdef
        class no_content:
            show_item: bool
            notification: bool

        @constdef
        class search:
            view: 'ContentView'
            clear_if_sure: bool

        # -- Directories: main menu
        @constdef
        class navigator:
            lists_submenu: bool

        # -- Directories: movies
        @constdef
        class movies:
            region: str
            discover_sort_by: Sequence[Literal['original_title.asc', 'original_title.desc',  # list in setting `movies.sort` order
                                               'popularity.asc', 'popularity.desc',
                                               'revenue.asc', 'revenue.desc',
                                               'primary_release_date.asc', 'primary_release_date.desc',
                                               'title.asc', 'title.desc',
                                               'vote_average.asc', 'vote_average.desc',
                                               'vote_count.asc', 'vote_count.desc']]
            missing_duration: int
            future_if_no_date: bool
            date_from_year: bool
            future_playable: bool

            @constdef
            class resume:
                watched_date_format: Optional[str]

            @constdef
            class top_rated:
                votes: Optional[int]

            @constdef
            class genre:
                votes: Optional[int]
                # menu: Set[int]

            @constdef
            class year:
                votes: Optional[int]

            @constdef
            class joke:
                production_company: bool
                keyword: bool

            @constdef
            class trending:
                service: Literal['tmdb', 'trakt']

            @constdef
            class cinema:
                last_days: int
                next_days: int
                use_region: bool

            @constdef
            class tv:
                page_size: int
                service: Union[ProgramTvService, Collection[ProgramTvService]]
                list_mode: Literal['media', 'mixed', 'folders']
                service_view: 'ContentView'

            @constdef
            class new:
                votes: Optional[int]

            @constdef
            class progressbar:
                style: str
                mode: Literal['none', 'watching', 'watched', 'percent', 'percent_and_watched']
                width: int

        # -- Directories: tv-shows
        @constdef
        class tvshows:
            region: str
            discover_sort_by: Sequence[Literal['first_air_date.asc', 'first_air_date.desc',  # list in setting `tvshows.sort` order
                                               'name.asc', 'name.desc',
                                               'original_name.asc', 'original_name.desc',
                                               'popularity.asc', 'popularity.desc',
                                               'vote_average.asc', 'vote_average.desc',
                                               'vote_count.asc', 'vote_count.desc']]
            future_if_no_date: bool

            @constdef
            class top_rated:
                votes: Optional[int]

            @constdef
            class genre:
                votes: Optional[int]
                # menu: Set[int]

            @constdef
            class year:
                votes: Optional[int]

            @constdef
            class joke:
                production_company: bool

            @constdef
            class trending:
                service: Literal['tmdb', 'trakt']

            @constdef
            class premiere:
                votes: Optional[int]

            @constdef
            class progress:
                episode_folder: bool
                episode_focus: bool
                episode_select: bool
                episode_label_style: Optional[str]

        # -- Directories: seasones
        @constdef
        class seasons:
            no_title_labels: Sequence[str]
            with_title_labels: Sequence[str]
            override_title_by_label: bool
            future_if_no_date: bool

        # -- Directories: episodes
        @constdef
        class episodes:
            missing_duration: int
            progress_if_aired: bool
            future_if_no_date: bool
            date_from_year: bool
            future_playable: bool
            continuing_numbers: bool
            label: str

            @constdef
            class resume:
                watched_date_format: Optional[str]

            @constdef
            class progressbar:
                style: str
                mode: Literal['none', 'watching', 'watched', 'percent', 'percent_and_watched']
                width: int

        # -- Directories: persons

        # -- Directories: stump indexers (keywords, companies)
        @constdef
        class stump:
            votes: Optional[int]

        # -- Directories: trakt lists
        @constdef
        class trakt:

            show_sync_entry: bool

            @constdef
            class collection:
                mixed: bool

            @constdef
            class recommendation:
                mixed: bool

            @constdef
            class mine:
                view: 'ContentView'

            @constdef
            class lists:
                watched_date_format: Optional[str]

            @constdef
            class progress:
                bar: bool
                page_size: int
                movies_page_size: int
                episodes_page_size: int
                shows_page_size: int
                shows_page_size_exact_match: bool

        # -- Directories: tmdb lists
        @constdef
        class tmdb:

            @constdef
            class favorite:
                mixed: bool

            @constdef
            class watchlist:
                mixed: bool

            @constdef
            class mine:
                view: 'ContentView'

        # -- Directories: tools
        @constdef
        class tools:
            view: 'ContentView'

    @constdef
    class indexer_group:

        # -- Genre menu
        @constdef
        class genres:
            translations: Dict[str, Dict[CodeId, str]]
            icons_set: Literal['fanfilm', 'kodi']
            icons: Dict[Literal['fanfilm', 'kodi'], Dict[CodeId, str]]

        # -- Language menu
        @constdef
        class languages:
            default: Set[CodeId]
            top: Set[CodeId]
            groups: Tuple[DirItemSource, ...]
            votes: Optional[int]

        # -- Country menu
        @constdef
        class countries:
            default: Set[CodeId]
            top: Set[CodeId]
            groups: Tuple[DirItemSource, ...]
            votes: Optional[int]

    # ----- tmdb.org settings -----
    @constdef
    class tmdb:
        append_seasons_count: int
        append_seasons_max_count: int
        # image_languages: Sequence[str]
        get_image_mode: Literal['append', 'pull', 'full', 'all']
        language_aliases: Sequence[Sequence[str]]

    # ----- trakt.tv settings -----
    @constdef
    class trakt:

        @constdef
        class page:
            limit: int

        @constdef
        class scan:
            @constdef
            class page:
                limit: int

        @constdef
        class sync:
            startup_interval: int
            interval: int
            cooldown: int
            notification_delay: int
            wait_for_service_timeout: float

        @constdef
        class auth:
            @constdef
            class qrcode:
                size: int

            @constdef
            class code:
                color: str

    # ----- justwatch.com settings -----
    @constdef
    class justwatch:
        episode_max_limit: int

    # ----- Library -----
    @constdef
    class library:
        flat_show_folder: bool

    # ----- Low level settings (don't change, you are warnend) -----
    @constdef
    class tune:
        sleep_step: float
        event_step: float

        @constdef
        class db:
            connection_timeout: float
            state_wait_read_interval: float

        @constdef
        class service:
            check_interval: float
            job_list_sleep: int
            group_update_timeout: float
            group_update_busy_dialog: bool
            focus_item_delay: float

            @constdef
            class http_server:
                port: int
                try_count: int
                wait_for_url: float

        @constdef
        class misc:

            @constdef
            class qrcode:
                size: int


# ----------------------------------------------------------------------------- #
# -----                              THE END                              ----- #
# ----------------------------------------------------------------------------- #


if TYPE_CHECKING:
    ConstRefBase = type(const)
else:
    ConstRefBase = object


class ConstRef(ConstRefBase):
    """Dynamic const reference."""

    def __init__(self, obj: object, *keys: str) -> None:
        self._obj = obj
        self._keys = keys

    if not TYPE_CHECKING:
        def __getattr__(self, key: str) -> Any:
            if key.startswith('_'):
                raise AttributeError(key)
            return ConstRef(self._obj, *self._keys, key)

    def __call__(self) -> Any:
        obj = self._obj
        for key in self._keys:
            obj = getattr(obj, key)
        return obj

    def __repr__(self) -> str:
        return f'CONST_REF({".".join(self._keys)})'


CONST_REF = ConstRef(const)
_loading: bool = False


def __getattr__(key: str) -> Any:
    """Return const settings directly as module value."""
    if key and key[0].islower():
        return getattr(const, key)
    raise AttributeError(f'Module {__name__} has o attribute {key!r}')


# dummy function
def setup_debugger():
    """Configure remote debugger. Override this in local.py."""
    from lib.ff.log_utils import fflog
    fflog('setup_debugger() is missing in local.py. Your debugger is not set.')


def run_debugger():
    """Run remote debugger connection."""
    if const.debugger.enabled:
        from lib.ff.log_utils import fflog_exc
        try:
            setup_debugger()
        except Exception:
            fflog_exc()


def _data_path() -> Path:
    """Returns plugin data folder path."""
    from xbmcaddon import Addon
    from xbmcvfs import translatePath
    return Path(translatePath(Addon().getAddonInfo('profile')))


def _check_const_assignment(const_obj: Any, *, obj: Any = None, keys: Sequence[str] = ()):
    """Check if all defined `class const` settings are assigned."""
    if obj is None:
        const_obj._refs = {}
        obj = const_obj
    cls = type(obj)
    elements = {k: v for k, v in vars(obj).items() if not k.startswith('_')}
    if ann := getattr(cls, '__annotations__', None):
        if missing := ann.keys() - elements.keys():
            sets = ', '.join(sorted(missing))
            raise TypeError(f'{cls.__qualname__}: missing settings: {sets}')
    # for sub in elements.values():
    for key, sub in elements.items():
        if isinstance(sub, ConstRef):
            const_obj._refs[(*keys, key)] = sub
        if getattr(sub, '_const_def', None):
            _check_const_assignment(const_obj=const_obj, obj=sub, keys=(*keys, key))


def _resolve_const_assignment(obj):
    """Check if all defined `class const` settings are assigned."""
    def xset(x: Any, keys: Sequence[str], value: Any) -> None:
        for key in keys[:-1]:
            x = getattr(x, key)
        setattr(x, keys[-1], value)

    refs = getattr(obj, '_refs', {})
    for keys, ref in refs.items():
        visited: Set[str] = {keys, ref._keys}
        while ref2 := refs.get(ref._keys):
            ref = ref2
            if ref._keys in visited:
                cycle = ', '.join('.'.join(('const', *keys)) for keys in visited)
                raise ValueError(f'Cycle const refernece: {cycle}')
            visited.add(ref._keys)
        xset(obj, keys, ref())


def const_done():

    global _loading
    if _loading or getattr(constdef, '_locked', False):
        return

    _check_const_assignment(const)

    # --- must be on the bottom of the file

    _local_path: Path = _data_path() / 'local.py'
    if not _local_path.exists():
        try:
            _local_path.write_text(('"""Local const settings."""\n\nfrom cdefs import const, CONST_REF\n\n\n'
                                    '# --- Your custom settings\n\n# const.NAME = VALUE\n'), encoding='utf-8')
        except IOError as exc:
            from lib.ff.log_utils import fflog
            fflog(f'Creating local file {_local_path} failed: {exc}')
    if _local_path.is_file():
        _loading = True
        try:
            globals().update((k, v)
                             for k, v in runpy.run_path(str(_local_path)).items()
                             if not k.startswith('__'))
        except IOError as exc:
            from lib.ff.log_utils import fflog
            fflog(f'Reading local file {_local_path} failed: {exc}')
        finally:
            _loading = False

    # resole references
    _resolve_const_assignment(const)
    # end of const definitions
    constdef._locked = True  # type: ignore
