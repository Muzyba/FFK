"""
Simple routing based on libka, without annotations.
"""

import re
import json
from urllib.parse import ParseResult, urlparse, urlunparse, parse_qsl, quote, quote_plus
from itertools import chain
from contextlib import contextmanager
from inspect import signature, Signature, getmodule, ismethod, isclass, currentframe
from types import FunctionType, MethodType, ModuleType
from pathlib import PurePosixPath as UPath, Path
from typing import (
    Optional, Union, Any,
    Tuple, List, Dict,
    Mapping,
    NamedTuple, Callable, Type, TypeVar,
    Generic, Generator,
    overload, cast,
    TYPE_CHECKING,
)
from typing_extensions import (
    ParamSpec, get_args, get_origin, Self, Literal,
    SupportsIndex, Protocol, TypeAlias, Annotated,
)
from attrs import define, frozen, field

from . import log_utils as logger
from .url import URL, item_iter
from .tricks import get_method_class, str_removeprefix, MISSING
from .types import is_optional, remove_optional
from ..defs import MediaRef

# type aliases
Args = Tuple[Any]
KwArgs = Dict[str, Any]
# Params = Dict[Union[str, int], Any]
Params = Dict[str, Any]
ArgType = Union[Type, Callable]

R = re.compile


T = TypeVar('T')


@define
class RouteCalling:
    method: Optional[Callable[..., None]] = None
    kwargs: KwArgs = field(factory=dict)

    def set(self, method: Callable[..., None], kwargs: KwArgs) -> None:
        self.method = method
        self.kwargs = kwargs

    def clear(self):
        self.method = None
        self.kwargs = {}


_ff_route_calling = RouteCalling()


# def ann_subtype(cls, ann, default=str):
#     """Remove Optional and returns subtype from PathArg (or `str` if none)."""
#     ann = remove_optional(ann)
#     origin = getattr(ann, '__origin__', ann)
#     try:
#         if origin is cls or issubclass(origin, cls):
#             return getattr(ann, '__args__', (default,))[0]
#     except TypeError:
#         pass
#     return None


def ann_type(ann: Annotated, cls: Optional[Type] = None) -> Tuple[Type, Tuple[Any, ...]]:
    """Check and return type and annotated details (meta)."""
    ann = remove_optional(ann)
    origin = get_origin(ann)
    if origin is not Annotated:
        return ann, ()
    args = get_args(ann)
    typ, meta = args[0], args[1:]
    if cls is None or cls in meta:
        return typ, meta
    return typ, ()


class _PathArg:
    """Path argument pseudo-type for annotations."""


class _Unsigned:
    """Unsigned[int] argument pseudo-type for annotations."""


class _Positive:
    """Positive[int] argument pseudo-type for annotations."""


PathArg: TypeAlias = Annotated[T, _PathArg]
Unsigned: TypeAlias = Annotated[T, _Unsigned]
Positive: TypeAlias = Annotated[T, _Positive]
# RegEx: TypeAlias = Annotated[T, _Positive]


def encode_params(params: Optional[KwArgs] = None, *, raw: Optional[KwArgs] = None) -> str:
    """
    Helper. Make query aparams with given data.

    Path is appended (if exists).
    All data from `params` are quoted.
    All data from `raw` are picked (+gzip +b64).
    """
    def quote_str_plus(s):
        if s is True:
            # Non-standard behavior !
            return 'true'
        if s is False:
            # Non-standard behavior !
            return 'false'
        if isinstance(s, (dict, list)):
            # Non-standard behavior !
            s = json.dumps(s)
        elif not isinstance(s, str):
            s = str(s)
        return quote_plus(s)

    params = item_iter(params)
    raw = item_iter(raw)
    return '&'.join(chain(
        ('%s=%s' % (quote_str_plus(k), quote_str_plus(v)) for k, v in params),
        # ('%s=%s' % (quote_str_plus(k), encode_data(v)) for k, v in raw).
    ))


def uint(v: str) -> int:
    """Make unsigned int."""
    val = int(v)
    if val < 0:
        raise ValueError(f'Negative uint {v!r}')
    return val


def pint(v: str) -> int:
    """Make positive int."""
    val = int(v)
    if val <= 0:
        raise ValueError(f'Non-positive int {v!r}')
    return val


def ufloat(v: str) -> float:
    """Make unsigned float."""
    val = float(v)
    if val < 0:
        raise ValueError(f'Negative ufloat {v!r}')
    return val


def mkbool(v: str) -> bool:
    """Make bool."""
    if isinstance(v, str):
        v = v.lower()
        if v in mkbool.true:
            return True
        if v in mkbool.false:
            return False
        raise ValueError(f'Unknown bool format {v!r}')
    return bool(v)


mkbool.true = {'true', 'on', '1', 'hi', 'high', 'up', 'enable', 'enabled'}
mkbool.false = {'false', 'off', '0', 'lo', 'low', 'down', 'disable', 'disabled'}


def mk_ref(v: str) -> MediaRef:
    """Make media reference. Type is unknown."""
    return MediaRef('', *map(int, v.split('/')[:3]))


def mk_path(v: str) -> Path:
    """Make Path()."""
    if v.startswith('./'):
        return Path(v[2:])
    if not v.startswith('/'):
        v = f'/{v}'
    return Path(v)


def mk_upath(v: str) -> UPath:
    """Make Path()."""
    if v.startswith('./'):
        return UPath(v[2:])
    if not v.startswith('/'):
        v = f'/{v}'
    return UPath(v)


def mk_url(v: str) -> URL:
    """Make Path()."""
    if not v.startswith('/'):
        v = f'/{v}'
    return URL(v)


class ArgDescr(NamedTuple):
    #: Argument type.
    type: ArgType
    #: Regex pattern to argument parse.
    pattern: str
    #: If True, regex is passed to `type`. If False, the string value.
    rx: bool = False


@define
class EntryParam:
    #: Param name.
    name: str
    #: Param type / function to create.
    types: Tuple[Union[Type, Callable[[str], Any]], ...]
    #: True if optional.
    optional: bool = False
    #: Ture, if param is used in the path.
    path_arg: bool = True
    #: Default value.
    default: Any = MISSING


@define
class RouteEntryMethodClass:
    type: Type
    name: str
    module: ModuleType
    is_method: bool = True


@define
class RouteEntry:
    #: Path regex.
    path: re.Pattern
    #: Method to call.
    method: Callable[..., None]
    #: Params defined in route path as "{param}, type is in method annotation.".
    params: Dict[str, EntryParam]
    #: Path for format in url_for().
    path_format: str = ''
    #: Label to show in folder, should be localized by L().
    label: str = ''
    #: Path prefix to modify group of routes.
    prefix: Optional[str] = None
    #: Only defined partially, pointer to method class.
    method_class: Optional[RouteEntryMethodClass] = None


# class RouteObject(Protocol):
class RouteObject:
    """Dummy class to map (sub) route target typing."""


@frozen
class RouteCall:
    """Call method data (for routing)."""
    route: RouteEntry
    method: Callable[..., None]
    kwargs: KwArgs = field(factory=dict)
    instance: Optional[object] = None

    def bind(self) -> Callable[..., None]:
        if ismethod(self.method) or self.instance is None or (self.route.method_class and not self.route.method_class.is_method):
            return self.method
        else:
            return MethodType(self.method, self.instance)

    # def call(self) -> Any:
    #     if ismethod(self.method) or self.instance is None or (self.route.method_class and not self.route.method_class.is_method):
    #         self.method(**self.kwargs)
    #     else:
    #         self.method(self.instance, **self.kwargs)


class RouteObjectProtocol(Protocol):
    """Dummy class to map (sub) route target typing."""
    _subobject_parent: 'RouteObject'
    _subobject_objects: Dict[str, 'RouteObject']


# class ForUrlFunctionType(Protocol):
#     """Type of Router.for_url."""
#     @contextmanager
#     def prefix(self, prefix: str): yield ...


# def for_url_decorator(func: Any) -> ForUrlFunctionType:
#     return func


class Router:
    """
    URL router to manage methods and paths.

    >>> @entry(path='/Foo/{a}/{b}')
    >>> def foo(a, /, b: int, c=1, *, d: int, e=2):
    >>>     print(f'foo(a={a!r}, b={b!r}, c={c!r}, d={d!r}, e={e!r})')
    >>>
    >>> def bar(a: PathArg, /, b: PathArg[int], c=1, *, d: int, e=2):
    >>>     print(f'bar(a={a!r}, b={b!r}, c={c!r}, d={d!r}, e={e!r})')
    >>>
    >>> rt = Router('plugin://this')
    >>> rt.url_for(foo, 11, 12, 13, d=14)  # plugin://this/Foo/11/12?c=13&d=14
    >>> rt.url_for(bar, 11, 12, 13, d=14)  # plugin://this/bar/11/12?c=13&d=14
    >>>
    >>> rt.dispatch('plugin://this/Foo/11/12?c=13&d=14')  # foo(a='11', b=12, c='13', d=14, e=2)
    >>> rt.dispatch('plugin://this/bar/11/12?c=13&d=14')  # bar(a='11', b=12, c='13', d=14, e=2)
    """

    SAFE_CALL = False

    # _SUBRE = r'(?:\\.|[^)])+'
    # _SUBRE = rf'(?:\\.|\({_SUBRE}\)|[^)])+'
    # _SUBRE = rf'(?:\\.|\({_SUBRE}\)|[^)])+'

    #: regex to find "<[type:]param>" in path.
    # _RE_PATH_ARG = re.compile(rf'<(?:re\((?P<re>{_SUBRE})\):|(?P<type>[-+]?\w+):)?(?P<name>[a-zA-Z]\w*|\d+)>')

    # _ARG_TYPES = {
    #     'str':    ArgDescr(str,    r'[^/]+'),
    #     'path':   ArgDescr(str,    r'.+'),
    #     'int':    ArgDescr(int,    r'[+-]?\d+'),
    #     'sint':   ArgDescr(int,    r'[+-]?\d+'),
    #     'signed': ArgDescr(int,    r'[+-]?\d+'),
    #     'uint':   ArgDescr(uint,   r'\d+'),
    #     '+int':   ArgDescr(uint,   r'\d+'),
    #     'pint':   ArgDescr(pint,   r'[1-9]\d*'),
    #     'float':  ArgDescr(float,  r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(:?[eE][+-]?\d+)?'),
    #     'bool':   ArgDescr(mkbool, r'true|false'),
    # }

    #: Regex for parse argument on the path: "/aa/{param}/cc".
    _RE_PATH_ARG = re.compile(r'\{(?P<name>[a-zA-Z]\w*)\}')

    #: Annotated typed, used on path (see _RE_PATH_ARG) and with PathArg[...].
    _ANN_TYPES = {
        str:             ArgDescr(str,      r'[^/]+'),
        UPath:           ArgDescr(mk_upath, r'.+'),
        Path:            ArgDescr(mk_path,  r'.+'),
        URL:             ArgDescr(mk_url,   r'.+'),
        int:             ArgDescr(int,      r'[+-]?\d+'),
        Unsigned[int]:   ArgDescr(uint,     r'\d+'),
        Positive[int]:   ArgDescr(pint,     r'[1-9]\d*'),
        float:           ArgDescr(float,    r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(:?[eE][+-]?\d+)?'),
        Unsigned[float]: ArgDescr(float,    r'(?:\d+(?:\.\d*)?|\.\d+)(:?[eE][+-]?\d+)?'),
        bool:            ArgDescr(mkbool,   r'true|false|0|1'),
        MediaRef:        ArgDescr(mk_ref,   r'(\d+)(?:/(\d+)(?:/(\d+))?)?'),
    }

    def __init__(self, url: Optional[Union[URL, str]] = None, obj: Optional[object] = None, *,
                 standalone: Optional[bool] = False, router: Optional['Router'] = None,
                 # addon: Optional['Addon'] = None,
                 ) -> None:
        #: Base URL of routing (plugin).
        self.url: URL = URL('plugin://plugin.video.fanfilm/') if url is None else URL(url)
        #: Root object to find subobjects / subroutes.
        self.obj: Optional[object] = obj
        #: Routes for decorators.
        self.routes: List[RouteEntry] = []
        #: Routes for decorators defined partially only.
        self.class_routes: Dict[Type, List[RouteEntry]] = {}
        #: Routes for decorators defined partially only.
        self.unkown_class_routes: Dict[Tuple[ModuleType, str], List[RouteEntry]] = {}

        if standalone is False:
            self.routes = default_router.routes  # link to routes (it's NOT a copy)
            self.class_routes = default_router.class_routes  # link to routes (it's NOT a copy)
            self.unkown_class_routes = default_router.unkown_class_routes  # link to routes (it's NOT a copy)
        if router is not None:
            self.routes.extend(router.routes)
            for cls, lst in router.class_routes.items():
                self.class_routes.setdefault(cls, []).extend(lst)
            for cls, lst in router.unkown_class_routes.items():
                self.unkown_class_routes.setdefault(cls, []).extend(lst)

    def set_default_route_object(self, obj: object) -> None:
        """Set obj for subrounting."""
        self.obj = obj

    def resolve_unkown_types(self) -> None:
        """Resolve all unknown method classes."""
        if self.unkown_class_routes:
            for (mod, cname), lst in self.unkown_class_routes.items():
                ctype = getattr(mod, cname)
                # class_routes = self.class_routes.setdefault(ctype, [])
                for route in lst:
                    assert route.method_class is not None
                    route.method_class.type = ctype
                    if isinstance(route.method, (staticmethod, classmethod)):
                        route.method = getattr(ctype, route.method.__name__)
                        # route.method_class = None
                        # self.routes.append(route)
                    # else:
                    #     class_routes.append(route)
                self.class_routes.setdefault(ctype, []).extend(lst)
            self.unkown_class_routes.clear()

    def _new_route(self, path: str, *, method: Callable, **kwargs) -> RouteEntry:
        """Add route (ex. from @route)."""

        def arg_pat(ann):
            otype = get_origin(ann)
            if otype is Union:
                types = get_args(ann)
            else:
                types = (ann,)
            found_arg_types: List[Tuple[Type, ArgDescr]] = []
            for typ in types:
                subtyp, meta = ann_type(typ)
                otype = get_origin(typ)
                if meta and isinstance(meta[0], re.Pattern):
                    at = ArgDescr(subtyp, f'(?:{meta[0].pattern})')
                elif otype is Literal:
                    type_args = get_args(typ)
                    if type_args:
                        apat = '|'.join(re.escape(a) for a in type_args)
                        at = ArgDescr(type(type_args[0]), f'(?:{apat})')
                    else:
                        at = self._ANN_TYPES[str]
                else:
                    try:
                        at = self._ANN_TYPES[typ]
                    except KeyError:
                        logger.error(f'Unsported argument type: typ={typ!r}')
                        continue
                found_arg_types.append((typ, at))
            try:
                types, ats = zip(*found_arg_types)
            except ValueError as exc:
                logger.fflog_exc()
                logger.fflog(f'ERRROR: can NOT create route for {path=}, {method=}, wrong {ann=}')
                return (), '--no-arg-pattern--'
            if len(ats) == 1:
                at_pat = ats[0].pattern
            else:
                at_pat = '|'.join(f'(?:{p.pattern})' for p in ats)
            return types, at_pat

        def mkarg(m: re.Match):
            nonlocal path_format, path_index
            name = m['name']
            par = sig.parameters[name]
            ann = remove_optional(par.annotation)
            path_format = f'{path_format}{m.string[path_index:m.start()]}{{{name}}}'
            path_index = m.end()
            types, at_pat = arg_pat(ann)
            if name.isdigit():
                params[int(name)] = entry = EntryParam(name, types)
                name = f'_{name}'
            else:
                params[name] = entry = EntryParam(name, types)
            if par.default is not par.empty:
                entry.default = par.default
            return fr'(?P<{name}>{at_pat})'

        def add_path_args(pat: str, sig: Signature) -> str:
            nonlocal path_format
            for p in sig.parameters.values():
                ht = remove_optional(p.annotation)
                if ht is not p.empty:
                    typ, meta = ann_type(ht, _PathArg)
                    if meta:
                        types, at_pat = arg_pat(typ)
                        if types:
                            if pat == '/':
                                pat = ''
                            if path_format == '/':
                                path_format = ''
                            params[p.name] = ep = EntryParam(p.name, tuple(types))
                            if p.default is not p.empty:
                                ep.default = p.default
                            sep = pat and '/'
                            if is_optional(p.annotation) or p.default is not p.empty:
                                ep.optional = True
                                pat = f'{pat}(?:{sep}(?P<{p.name}>{at_pat}))?'
                            else:
                                pat = f'{pat}{sep}(?P<{p.name}>{at_pat})'
                                path_format = f'{path_format}/{{{p.name}}}'
            return pat

        def add_sig_args(sig: Signature) -> None:
            for p in sig.parameters.values():
                if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY) and p.name not in params:
                    ht = remove_optional(p.annotation)
                    typ, meta = ann_type(ht, _PathArg)
                    if typ is None:
                        typ = str
                    opt = is_optional(p.annotation) or p.default is not p.empty
                    params[p.name] = ep = EntryParam(p.name, (typ,), optional=opt, path_arg=False)
                    if p.default is not p.empty:
                        ep.default = p.default

        assert path is not None
        func = method
        static = False
        if isinstance(method, classmethod):
            func = method.__wrapped__
        elif isinstance(method, staticmethod):
            func = method = method.__wrapped__
            static = True
        sig = signature(func)
        if '.' in func.__qualname__ and path.startswith('/'):
            path = path[1:]
        path = getattr(path, 'path', path)  # EndpointEntry - dack typing (libka)
        params: Dict[str, EntryParam] = {}
        path_format, path_index = '', 0
        pattern = self._RE_PATH_ARG.sub(mkarg, path)
        path_format = f'{path_format}{path[path_index:]}'
        pattern = add_path_args(pattern, sig)
        add_sig_args(sig)
        route = RouteEntry(re.compile(pattern), method, params=params, path_format=path_format, **kwargs)
        if static or ismethod(func) or (sig.parameters and next(iter(sig.parameters.values())).name in ('self', 'cls')):
            module = getmodule(func)
            if module is None:
                raise ValueError(f'No module for method {method}')
            route.method_class = RouteEntryMethodClass(type=get_method_class(func),
                                                       name=func.__qualname__.rpartition('.')[0],
                                                       module=module)
            if static:
                route.method_class.is_method = False
        # print(route)  # XXX
        return route

    def add_route(self, path: str, *,
                  method: Callable,
                  label: str = '',
                  prefix: Optional[str] = None,
                  ) -> RouteEntry:
        """Add route (ex. from @entry)."""
        route = self._new_route(path, method=method, label=label, prefix=prefix)
        if route.method_class:
            mcls = route.method_class
            if mcls.type:
                self.class_routes.setdefault(mcls.type, []).append(route)
            else:
                self.unkown_class_routes.setdefault((mcls.module, mcls.name), []).append(route)
        else:
            self.routes.append(route)
        return route

    @overload
    def url_for(self, **kwargs) -> Optional[URL]: ...

    @overload
    def url_for(self, method: Callable[..., Any], **kwargs) -> Optional[URL]: ...

    @overload
    def url_for(self, prefix: str, method: Callable[..., Any], **kwargs) -> Optional[URL]: ...

    @overload
    def url_for(self, target: RouteObject, **kwargs) -> Optional[URL]: ...

    def url_for(self, *args, **kwargs) -> Optional[URL]:
        """
        Determinate URL for given method or None.

        url_for(prefix, method, **params)
        url_for(method, **params)
        url_for(**params)
        """

        def dump_value(val: Any) -> str:
            if val is None:
                return ''
            if isinstance(val, bool):
                return 'true' if val else 'false'
                # return f'{int(val)}'
            if isinstance(val, (URL, Path, UPath)):
                return str_removeprefix(str(val), '/')
            # if isinstance(val, tuple):
            #     return ','.join(dump_value(v) for v in val)
            return f'{val}'

        def make_url(route: RouteEntry, prefix: str = '') -> Optional[URL]:
            # those args are obligated
            needed = {p.name for p in route.params.values() if not p.optional and p.default is MISSING}
            # if not all necessery arguments are present
            if not (needed - kwargs.keys()):
                # fill path with path-arguments
                defaults = {k: p.default for k, p in route.params.items() if p.default is not MISSING}
                path = route.path_format.format(**{k: dump_value(v) for d in (defaults, kwargs) for k, v in d.items()})
                # add optional path-arguments
                end = len(path)
                for p in route.params.values():
                    if p.path_arg and p.optional:
                        append, explicit = '', False
                        for explicit, val in ((True, kwargs.get(p.name, MISSING)), (False, p.default)):
                            if val is None or not str(val):
                                break
                            elif val is not MISSING:
                                append = dump_value(val)
                                break
                        if append:
                            path = f'{path}/{append}'
                            if explicit:
                                end = len(path)
                        else:
                            break
                # remove implicit path arguemnts (from method default args but not in for_url() args)
                path = path[:end]
                # find forbidden args in query
                # forbidden = {p.name for p in route.params.values() if p.path_arg and not p.optional}
                forbidden = {p.name for p in route.params.values() if p.path_arg}
                forbidden.update(('self', 'cls'))
                # build query
                query = encode_params({k: v for k, v in kwargs.items() if k not in forbidden})
                # build url
                if (not path or path.startswith('/')) and prefix.endswith('/'):
                    prefix = prefix[:-1]
                return URL(self.url.scheme, self.url.hostname, f'{prefix}{path}', '', query)
            # Missing same arguments.
            return None

        def find(method: Callable, routes: List[RouteEntry], prefix: str = '') -> Optional[URL]:
            for route in routes:
                if route.method == method:
                    url = make_url(route, prefix)
                    if url is not None:
                        return url

        method: Callable
        prefix: str = ''
        if len(args) == 2:
            prefix, method = args
        elif len(args) == 1:
            method, = args
        elif not args:
            # global name `_ff_route_calling` set by Router.call().
            if _ff_route_calling.method is None:
                raise RuntimeError('for_url() without method called outside @route')
            method = _ff_route_calling.method
            kwargs = {**_ff_route_calling.kwargs, **kwargs}
        else:
            raise TypeError(f'for_url() accepts max two positional arguments, got {len(args)}')

        # find in regular (global) routes
        url = find(method, self.routes)
        if url:
            return url
        # try to find in subobjects
        self.resolve_unkown_types()
        function: Optional[Callable]
        obj_type: Optional[Type]
        if isinstance(method, subobject) and prefix:
            return URL(self.url.scheme, self.url.hostname, f'{prefix}{method.name}', '', '')
        if callable(method):  # method, function or something
            try:
                instance = method.__self__
                if isclass(instance):
                    obj_type = instance
                    kwargs.setdefault('cls', instance)
                    if not prefix:
                        logger.fflog(f'WARNING: potentially subrouting wrong path for class method {method}')
                else:
                    obj_type = type(instance)
                    kwargs.setdefault('self', instance)
                function = getattr(obj_type, method.__name__)
            except AttributeError:
                instance = None
                obj_type = get_method_class(method)
                function = method
                if not prefix and obj_type is not None:
                    logger.fflog(f'WARNING: potentially subrouting wrong path for static method {method}')
        else:
            # instance by subobject?
            instance = method
            obj_type = type(instance)
            function = None
            kwargs.setdefault('self', instance)
        names = ['']  # last slash
        obj = instance
        while True:
            parent = getattr(obj, '_subobject_parent', None)
            if not parent:
                break
            names.insert(0, parent._subobject_objects[id(obj)])
            obj = parent
        path = '/'.join(names)
        if obj_type is not None:
            obj_types = getattr(obj_type, '__mro__', (obj_type,))
            for obj_type in obj_types:
                routes = self.class_routes.get(obj_type, [])
                if function is None:
                    for route in routes:
                        if route.path.fullmatch(''):
                            url = make_url(route, prefix=f'/{path}')
                            break
                else:
                    url = find(function, routes, prefix=f'/{path}')
                if url is not None:
                    break
        if url:
            return url
        ...

    @overload
    def route_redirect(self, **kwargs) -> Optional[URL]: ...

    @overload
    def route_redirect(self, method: Callable, **kwargs) -> Optional[URL]: ...

    @overload
    def route_redirect(self, prefix: str, method: Callable, **kwargs) -> Optional[URL]: ...

    # @overload
    # def route_redirect(self, url: str) -> Optional[URL]: ...

    def route_redirect(self, *args, **kwargs) -> Optional[URL]:
        """
        Mark current route as method or URL. Useful for for_url().

        route_redirect(prefix, method, **params)
        route_redirect(method, **params)
        route_redirect(**params)
        """
        method: Callable
        prefix: str = ''
        if len(args) == 2:
            prefix, method = args
        elif len(args) == 1:
            method, = args
        elif not args:
            # global name `_ff_route_calling` set by Router.call().
            if _ff_route_calling.method is None:
                raise RuntimeError('route_redirect() without method called outside @route')
            method = _ff_route_calling.method
            kwargs = {**_ff_route_calling.kwargs, **kwargs}
        else:
            raise TypeError(f'route_redirect() accepts max two positional arguments, got {len(args)}')
        _ff_route_calling.set(method, kwargs)

    @overload
    def url_proxy(self, **kwargs) -> Optional[URL]: ...

    @overload
    def url_proxy(self, method: Callable[..., Any], **kwargs) -> Optional[URL]: ...

    @overload
    def url_proxy(self, prefix: str, method: Callable[..., Any], **kwargs) -> Optional[URL]: ...

    @overload
    def url_proxy(self, target: RouteObject, **kwargs) -> Optional[URL]: ...

    def url_proxy(self, *args, **kwargs) -> Optional[URL]:
        """
        Like `url_for()` but use current route and put it in `url` arguemnt.

        Target must have `url` arguemnt (type of `Path`).
        """
        if _ff_route_calling.method is None:
            raise RuntimeError('url_proxy() without method called outside @route')
        method: Callable
        prefix: str = ''
        if len(args) == 2:
            prefix, method = args
        elif len(args) == 1:
            method, = args
        elif not args:
            method = _ff_route_calling.method
        else:
            raise TypeError(f'url_proxy() accepts max two positional arguments, got {len(args)}')
        # URL for current route method (called method)
        url = url_for(_ff_route_calling.method, **_ff_route_calling.kwargs)
        if url:
            url = url.without_remote()
        # url for proxy
        kwargs = {**_ff_route_calling.kwargs, **kwargs, 'url': url}
        return url_for(prefix, method, **kwargs)

    def find_call(self, url: URL, route: RouteEntry, params: Params, *, instance: Optional[object] = None) -> Optional[RouteCall]:
        """Find route method for call."""

        def set_arg(name: str, typ: Type, val: str) -> None:
            try:
                at = self._ANN_TYPES[typ]
            except KeyError:
                kwargs[name] = typ(val)
            else:
                kwargs[name] = at.type(val)

        kwargs = {**params, **url.args}
        method = route.method
        if isinstance(method, classmethod):
            method = method.__wrapped__
        sig = signature(method)
        # filter-out method missing arguments
        if not any(p.kind is p.VAR_KEYWORD for p in sig.parameters.values()):
            # has not **kwargs
            allowed = {p.name for p in sig.parameters.values() if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)}
            if kwargs.keys() - allowed:
                wrong = ', '.join(repr(k) for k in kwargs.keys() - allowed)
                logger.fflog(f'WARNING: method {method.__qualname__}() does not support argument(s): {wrong}')
                kwargs = {k: v for k, v in kwargs.items() if k in allowed}
        # check is all obligatory arguments are present
        obligatory = {p.name for p in sig.parameters.values()
                      if (p.name not in ('self', 'cls') and p.default is p.empty
                          and p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY))}
        if obligatory - kwargs.keys():
            return None
        # apply types
        for p in sig.parameters.values():
            ht = remove_optional(p.annotation)
            typ, meta = ann_type(ht, PathArg)
            if typ is not None and typ is not p.empty:
                val = kwargs.pop(p.name, None)
                if val is not None:
                    otype = get_origin(typ)
                    if otype is Union:
                        types = get_args(typ)
                    else:
                        types = (typ,)
                    for typ in types:
                        if get_origin(typ) is Literal:
                            aargs = get_args(typ)
                            for a in aargs:
                                if val == str(a):
                                    set_arg(p.name, type(a), val)
                                    break
                            else:
                                return None
                            break  # found arg
                        else:
                            try:
                                set_arg(p.name, typ, val)
                                break  # found arg
                            except (TypeError, ValueError):
                                pass
                    else:
                        raise ValueError(f'Can convert argument {p} for {method}')
        return RouteCall(method=method, kwargs=kwargs, instance=instance, route=route)

    def call(self, call: RouteCall) -> bool:
        """Call found route method."""
        route, method, kwargs, instance = call.route, call.method, call.kwargs, call.instance
        glob = method.__globals__
        ffunc = '__ff_route_function__'
        old = glob.get(ffunc, MISSING)
        glob[ffunc] = method
        try:
            if ismethod(method) or instance is None or (route.method_class and not route.method_class.is_method):
                _ff_route_calling.set(method, kwargs)
                method(**kwargs)
            else:
                _ff_route_calling.set(MethodType(method, instance), kwargs)
                method(instance, **kwargs)
        finally:
            _ff_route_calling.clear()
            if old is MISSING:
                del glob[ffunc]
            else:
                glob[ffunc] = old
        return True

    def find_dispatch(self, url: Union[URL, str], *, obj: Optional[object] = None) -> Optional[RouteCall]:
        """Find call for dispatched URL."""

        def find_call_class_method_for(subpath: str, obj_type: Type) -> Optional[RouteCall]:
            obj_types = getattr(obj_type, '__mro__', (obj_type,))
            for obj_type in obj_types:
                for route in self.class_routes.get(obj_type, ()):
                    m = route.path.fullmatch(subpath)
                    if m:
                        if call := self.find_call(url, route, m.groupdict(), instance=obj):
                            return call
            return None

        if isinstance(url, str):
            url = URL(url)
        if obj is None:
            obj = self.obj
        path = url.path
        if not path.startswith('/'):
            path = f'/{path}'
        for route in self.routes:
            m = route.path.fullmatch(path)
            if m:
                # print(m, m.groups(), m.groupdict())
                if call := self.find_call(url, route, m.groupdict()):
                    return call
        if obj:
            self.resolve_unkown_types()
            if path == '/' and (call := find_call_class_method_for('', type(obj))):
                return call
            parts = path.split('/')
            if parts[0] == '':  # omit first /
                parts = parts[1:]
            # try main object
            if call := find_call_class_method_for('/'.join(parts), type(obj)):
                return call
            # search subobjects
            for i, part in enumerate(parts):
                if part == '..':
                    logger.warning(f'Dangerous URL path {path!r}')
                    return
                if part in ('/', '.'):
                    continue
                try:
                    obj = getattr(obj, part)
                except AttributeError:
                    p = f'/{"/".join(parts[:i])}'
                    logger.fflog(f'Missing path or subobject {part!r} in {obj} with prefix {p!r}')
                    break
                obj_type = type(obj)
                subpath = '/'.join(parts[i+1:])
                self.resolve_unkown_types()  # again, getattr() could import new module
                if call := find_call_class_method_for(subpath, obj_type):
                    return call
        return None

    def dispatch(self, url: Union[URL, str], *,
                 missing: Optional[Callable[[URL], None]] = None,
                 obj: Optional[object] = None,
                 ) -> Any:
        """Dispatch given URL to registered routes."""
        if call := self.find_dispatch(url, obj=obj):
            return self.call(call)
        if missing:
            if isinstance(url, str):
                url = URL(url)
            missing(url)
        else:
            logger.fflog(f'ERROR: Unhandled url {str(url)!r}')


P = ParamSpec('P')
T = TypeVar('T')
RET = TypeVar('RET')
C = TypeVar('C', bound=Type[Any])
# D = TypeVar('D', bound=Union[Callable[P, None], Type[C]])


class subobject(Generic[T, RET]):
    """Subobject descriptor / porperty or decorator, used for subrouting."""

    def __init__(self, method: Optional[Callable[[T], RET]] = None, *, name: Optional[str] = None):
        self.method: Optional[Callable[[T], RET]] = method
        self.name: Optional[str] = name
        if name is None and method is not None:
            # "subobject" is used as decorator
            self.name = method.__name__

    def __call__(self, *args, **kwargs):
        logger.debug(f'subobject call {args}, {kwargs}')

    @overload
    def __get__(self: Self, instance: None, objtype: Optional[Type[T]] = None) -> Self: ...

    @overload
    def __get__(self: Self, instance: T, objtype: Optional[Type[T]] = None) -> RET: ...

    def __get__(self: Self, instance: Optional[T], objtype: Optional[Type[T]] = None) -> Union[Self, RET]:
        """Get descriptor value or instance."""
        if instance is None:
            return self
        try:
            return getattr(instance, f'_subobject_value_{self.name}')
        except AttributeError:
            if self.method is not None:
                # create on demand
                value = self.method(instance)
                self.__set__(instance, value)
                return value
            raise AttributeError(f'{instance.__class__.__name__!r} object has no attribute {self.name!r}') from None

    def __set__(self, instance: T, value: RET) -> None:
        """Set descriptor value."""
        try:
            dct = instance._subobject_objects
        except AttributeError:
            dct = instance._subobject_objects = {}
        dct[id(value)] = self.name
        value._subobject_parent = instance
        if not hasattr(instance, '_subobject_parent'):
            instance._subobject_parent = None
        setattr(instance, f'_subobject_value_{self.name}', value)

    def __delete__(self, instance) -> None:
        """Delete descriptor value."""
        delattr(instance, f'_subobject_value_{self.name}')

    def __set_name__(self, owner, name: str) -> None:
        """Set descriptor value name."""
        self.name = name


class Decorator(Protocol):
    def __call__(self, cls: C) -> C:
        ...


@overload
def route(func_or_path: Callable[P, None]) -> Callable[P, None]: ...


@overload
def route(func_or_path: Type[C]) -> Type[C]: ...


@overload
def route(func_or_path: str, *,
          router: Optional[Router] = None,
          prefix: Optional[str] = None,
          ) -> Callable[[Callable[P, None]], Callable[P, None]]:  ...


def _add_route_to_func(method: Callable, route: RouteEntry) -> None:
    """Add route to function/method."""
    routes = getattr(method, '_routes', None)
    if routes is None:
        routes = []
        setattr(method, '_routes', routes)
    routes.append(route)


def route(func_or_path, *,
          router: Optional[Router] = None,
          prefix: Optional[str] = None,
          split_underscore: bool = False,
          ) -> Callable:
    """
    @route decorator

    Use as simple endpoint entry decorator, with function name.
    >>> @route
    >>> def foo(a: PathArg[int], b: int) -> None: ...
    >>>
    >>> dispatch(URL('/foo/1?b=2'))
    >>> # foo(1, 2)

    Or decorator with arguemnts.
    >>> @route('/bar')
    >>> def foo(a: PathArg[int], b: int) -> None: ...
    >>>
    >>> @route('/bar/{a}')
    >>> def foo(a: int, b: int) -> None: ...
    >>>
    >>> dispatch(URL('/bar/1?b=2'))
    >>> # foo(1, 2)

    Could be used with subobject property.
    >>> class Root:
    >>>     @subobject
    >>>     def foo(self) -> 'Foo':
    >>>         return Foo(42)
    >>>
    >>> class Foo:
    >>>    def __init__(self, num: int) -> None:
    >>>        self.num = num
    >>>   @route
    >>>   def bar(self, PathArg[int], b: int) -> None: ...
    >>>
    >>> dispatch(URL('/foo/bar/1?b=2'))
    >>> # Foo(42).foo(1, 2)
    """
    if router is None:
        router = default_router

    def wrapper(func: Callable[P, None]) -> Callable[P, None]:
        route = router.add_route(path, method=func, prefix=prefix)
        _add_route_to_func(func, route)
        return func

    if callable(func_or_path):
        func: Callable = func_or_path
        path = f'/{func.__name__}'
        route = router.add_route(path, method=func, prefix=prefix)
        _add_route_to_func(func, route)
        return func
    elif isinstance(func_or_path, classmethod):
        clsmth: classmethod = func_or_path
        func = clsmth.__wrapped__
        path = f'/{func.__name__}'
        route = router.add_route(path, method=clsmth, prefix=prefix)
        _add_route_to_func(func, route)
        return func

    path: str = func_or_path
    return wrapper


def route_(func_or_path, *,
           router: Optional[Router] = None,
           prefix: Optional[str] = None,
           ) -> Callable:
    if router is None:
        router = default_router

    def wrapper(func: Callable[P, None]) -> Callable[P, None]:
        route = router.add_route(path, method=func, prefix=prefix)
        _add_route_to_func(func, route)
        return func

    if callable(func_or_path):
        func: Callable = func_or_path
        path = f'/{func.__name__}'.replace('_', '/')
        route = router.add_route(path, method=func, prefix=prefix)
        _add_route_to_func(func, route)
        return func
    elif isinstance(func_or_path, classmethod):
        clsmth: classmethod = func_or_path
        func = clsmth.__wrapped__
        path = f'/{func.__name__}'.replace('_', '/')
        route = router.add_route(path, method=clsmth, prefix=prefix)
        _add_route_to_func(func, route)
        return func

    path: str = func_or_path
    return wrapper


default_router = Router(standalone=True)

url_for = default_router.url_for
url_proxy = default_router.url_proxy
route_redirect = default_router.route_redirect
set_default_route_object = default_router.set_default_route_object
dispatch = default_router.dispatch
find_dispatched_call = default_router.find_dispatch


if __name__ == '__main__':
    # some tests...

    u = URL('http://a.b/c/d;z?e=1&f=2')
    print(repr(u))
    print(f'{u.query=!r}, {u.query}')
    print(u.args)
    print(f'e = {u.args["e"]!r}')
    print(repr(u.with_query('x=1&y=2')))
    print(repr(u.with_query({'x': 1, 'y': 2})))
    print(repr(u % {'x': 1, 'y': 2}))
    print(repr(u % {'x': 1, 'e': 9}))
    print(str(u % {'x': 1, 'e': 9, 'z': 'a,b/c'}))
    print((u % {'x': 1, 'e': 9, 'z': 'a,b/c'}).encode())
    with u.safe(','):
        print(repr(u % {'x': 1, 'e': '/El Niño/,путь'}))
    print(u['e'])

    # u = URL('/%D0%BF%D1%83%D1%82%D1%8C')
    # print(u)

    @route('/')
    def test_root():
        ...

    @route
    def foo():
        ...

    @route('/bar/{id}')
    def bar(id: Unsigned[int], num: Optional[PathArg[int]] = None, a: Optional[int] = 0, z=99, **kwargs):
        print(f'{id=}, {num=}, {a=}, {z=}, {kwargs=}')

    # @route('/baz/<re(:?(a|b)):id>')
    @route('/baz/{id}')
    def baz(id: Annotated[str, R('a|b')]):
        print(f'baz({id=})')

    @route('/baz2/{id}')
    def baz2(id: Annotated[int, R('1+')]):
        print(f'baz2({id=})')

    @route('/show/{dbid}')
    @route('/show/{dbid}/{season}')
    @route('/show/{dbid}/{season}/{episode}')
    def show(dbid: Positive[int], season: Optional[Unsigned[int]] = None, episode: Optional[Unsigned[int]] = None) -> None:
        print(f'show({dbid=}, {season=}, {episode=})')

    dispatch('/baz/a')
    dispatch('/baz/b')
    dispatch('/baz/c')
    dispatch('/baz2/1')
    dispatch('/baz2/11')
    dispatch('/baz2/12')

    from .. import cmdline_argv

    if len(cmdline_argv) < 1:
        # print(default_router.url_for(foo))
        # print(default_router.url_for(bar))
        # print(default_router.url_for(bar, id=567))
        # print(default_router.url_for(bar, id=678, num=-2))

        print(default_router.url_for(show))
        print(default_router.url_for(show, dbid=789))
        print(default_router.url_for(show, dbid=789, season=1))
        print(default_router.url_for(show, dbid=789, season=1, episode=2))
        print(default_router.url_for(show, dbid=789, season=1, episode=2, dupa=333))
        print(default_router.url_for(show, dbid=789, episode=99))
        exit()

    print(test_root._routes)
    print(foo._routes)
    print(bar._routes)
    print(baz._routes)
    print(default_router.routes)
    dispatch(URL(cmdline_argv[1]))

    @route
    def abc(a: PathArg[Literal['aa', 'bb', 99]], b: PathArg[int]) -> None:
        print(f'foo({a=}, {b=})')

    print(abc._routes)
    dispatch('/abc/aa/1')
    dispatch('/abc/99/1')
    print(url_for(abc, a='aa', b=3))
