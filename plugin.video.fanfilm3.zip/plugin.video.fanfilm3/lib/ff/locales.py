"""Simple locale tools."""

from pathlib import Path
import json
from typing import Optional, Dict
import requests

import xbmc
import xbmcaddon
import xbmcvfs

#: Base URL for languages translate.
LANG_URL = 'https://raw.githubusercontent.com/umpirsky/locale-list/master/data/{lang}/locales.json'
# 'https://raw.githubusercontent.com/umpirsky/language-list/master/data/{lang}/language.json'
# 'https://raw.githubusercontent.com/ihmpavel/all-iso-language-codes/master/data/{lang}/639-1.json'
#: Base URL for countries translate.
COUNTRY_URL = 'https://raw.githubusercontent.com/umpirsky/country-list/master/data/{lang}/country.json'
# 'https://raw.githubusercontent.com/stefangabos/world_countries/master/data/countries/{lang}/world.json'
# 'https://raw.githubusercontent.com/stefangabos/world_countries/master/data/countries/{lang}/countries.json

# -- for stefangabos/world_countries
# jdata = requests.get(COUNTRY_URL.format(lang=lang), timeout=5).json()
# trans = {e['alpha2'].upper(): e['name'] for e in jdata}


TranslationTable = Dict[str, Dict[str, str]]

#: Already readed language translations to speed up.
_all_lang_translations: TranslationTable = {}

#: Already readed country translations to speed up.
_all_country_translations: TranslationTable = {}

#: Path to cached locale files.
locale_path = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))) / 'locale'


def kodi_locale() -> str:
    """Return kodi locale (pl-PL)."""
    # For locale codes see: https://datahub.io/core/language-codes
    locale: str = xbmc.getLanguage(xbmc.ISO_639_1, True)  # locale: language with region
    if not locale or locale == '-':  # Kodi fack-up, eg. for en-NZ kodi returns "-"
        # incorrect ISO 639/1, contains ISO 3136/1 (country) but lower
        locale = xbmc.getLanguage(xbmc.ISO_639_1)
        locale, sep, region = locale.partition('-')
        if sep:
            locale = f'{locale}-{region.upper()}'
    if not locale:
        return 'en-US'
    return locale


def _translations(table: TranslationTable, fname: str, url: str, *, lang: Optional[str] = None) -> Dict[str, str]:
    """Return translatrions dict [lang]=name for given lang. Use kodi locale if None."""
    if not lang:
        lang = kodi_locale()
    lang, _, lngcountry = lang.replace('-', '_').partition('_')
    if lngcountry:
        locales = [f'{lang}_{lngcountry.upper()}', lang]
    else:
        locales = [lang]
    trans = None
    path = None
    for loc in locales:
        trans = table.get(loc)
        if trans is None:
            path = locale_path / loc / fname
            path.parent.mkdir(parents=True, exist_ok=True)
            trans = {}
            try:
                if path.exists():
                    trans = json.loads(path.read_text())
                else:
                    trans = requests.get(url.format(lang=loc), timeout=5).json()
            except requests.JSONDecodeError:
                pass
            else:
                table[loc] = trans
                break
    if trans:
        if path:
            path.write_text(json.dumps(trans, indent=2))
    else:
        xbmc.log(f'No country name for locale {locales[0]!r}', xbmc.LOGWARNING)
        table[loc] = {}
    return trans


def language_translations(lang: Optional[str] = None) -> Dict[str, str]:
    """Return language translatrions dict [lang]=name for given lang. Use kodi locale if None."""
    return _translations(_all_lang_translations, 'languages.json', LANG_URL, lang=lang)


def country_translations(lang: Optional[str] = None) -> Dict[str, str]:
    """Return language translatrions dict [lang]=name for given lang. Use kodi locale if None."""
    return _translations(_all_country_translations, 'countries.json', COUNTRY_URL, lang=lang)


if __name__ == '__main__':
    from argparse import ArgumentParser
    p = ArgumentParser()
    p.add_argument('code', help='lang (pl) or country (PL) code')
    p.add_argument('-L', '--lang', help='local language (pl_PL)')
    p.add_argument('-t', '--type', choices=('lang', 'country'), help='code type')
    a = p.parse_args()

    if not a.type:
        if a.code.islower():
            a.type = 'lang'
        elif a.code.isupper():
            a.type = 'country'
    if a.type == 'lang':
        print(f'Language {a.code!r}: {language_translations(lang=a.lang).get(a.code)!r}')
    elif a.type == 'country':
        print(f'Country {a.code!r}: {country_translations(lang=a.lang).get(a.code)!r}')
