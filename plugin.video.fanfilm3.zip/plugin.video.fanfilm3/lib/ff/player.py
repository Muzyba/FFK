# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from typing import Optional
import json
import sys
from ast import literal_eval

import xbmc
from xbmcplugin import setResolvedUrl
from xbmcgui import ListItem

from . import control
from .db import state
from .item import FFItem
from ..indexers.defs import VideoIds
from .log_utils import fflog, fflog_exc
from .control import close_busy_dialog


class player(xbmc.Player):
    def __init__(self):
        super().__init__()

    def run(self, ffitem: FFItem, url: str) -> None:
        fflog(f'[PLAYER] {url=}, ref={ffitem.ref:a}, {ffitem=}, dbid={ffitem.dbid}', stack_depth=2)
        try:
            vtag = ffitem.vtag
            imdb = vtag.getUniqueID('imdb') or '0'
            tmdb = int(vtag.getUniqueID('tmdb') or 0)
            ids = VideoIds(tmdb=tmdb, imdb=imdb).ids()

            # offset = bookmarks.get(content, imdb, season, episode)
            dummyFile = control.settings.getString("_proxy_path") + "stop.m3u8"

            empty = not url or url == "empty"
            if not url or url == "empty":
                url = dummyFile

            item = ffitem.clone()
            if url.startswith('DRM'):
                item = self.get_drm_item(url, item=item)
                if not item:
                    fflog('[DRM] could NOT resolve item')
            else:
                item.setPath(url)
            if item is None:
                empty = True
                url = dummyFile
                item = ListItem(path=dummyFile)

            # item.setInfo(type="video", infoLabels=control.metadataClean(meta))
            fflog(f'setResolvedUrl(url={url!r})')

            if empty:
                state.delete_all(module='player')
                state.multi_set(module='player', values=(
                    ('ff', True),
                    ('sources', False),
                    ('playing.empty', True),
                    ('playing.run', False),
                ))
                setResolvedUrl(int(sys.argv[1]), False, item)
            else:
                state.multi_set(module='player', values=(
                    ('ff', True),
                    ('media.ref', ffitem.ref.as_dict()),
                    ('media.imdb', imdb),
                    ('media.tmdb', tmdb),
                    ('media.season', ffitem.season),
                    ('media.episode', ffitem.episode),
                    ('media.dbid', ffitem.dbid),
                    ('media.real_type', ffitem.ref.real_type),
                    ('media.duration', ffitem.vtag.getDuration()),
                    ('sources', False),
                    ('playing.empty', False),
                    ('playing.run', True),
                ))
                setResolvedUrl(int(sys.argv[1]), True, item)
                close_busy_dialog()
                # self.updateInfoTag(ffitem)
            # if control.condVisibility('System.HasAddon(script.trakt)'):
            control.window().setProperty("script.trakt.ids", json.dumps(ids))

            # self.keepPlaybackAlive()
            # control.window().clearProperty("script.trakt.ids")
        except Exception:
            fflog_exc()

    def get_drm_item(self, url: str, *, item: Optional[FFItem] = None) -> Optional[FFItem]:
        import inputstreamhelper
        stream_data = url.split('|')[-1]
        stream_data = literal_eval(stream_data)

        is_helper = inputstreamhelper.Helper(stream_data["protocol"])
        if not is_helper.check_inputstream():
            return None

        if item is None:
            item = FFItem(path=stream_data['manifest'])
        else:
            item.setPath(stream_data['manifest'])
            item.vtag.setPath(stream_data['manifest'])
        item.setProperty('inputstream', is_helper.inputstream_addon)
        item.setMimeType(f'{stream_data["mimetype"]}')
        item.setProperty('inputstream.adaptive.manifest_type', stream_data["protocol"])
        item.setProperty('inputstream.adaptive.license_type', stream_data["licence_type"])
        item.setContentLookup(False)
        if stream_data.get('licence_url'):
            license_config = {'license_server_url': stream_data["licence_url"],
                              'headers': stream_data["licence_header"],
                              'post_data': stream_data["post_data"],
                              'response_data': stream_data["response_data"]
                              }
            item.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
        item.setProperty('IsPlayable', 'true')
        return item
