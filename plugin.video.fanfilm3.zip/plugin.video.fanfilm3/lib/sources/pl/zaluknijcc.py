# -*- coding: UTF-8 -*-
import re
from lib.ff.client import parseDOM
from requests.compat import urlparse
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["zaluknij.cc"]
        self.base_link = "https://zaluknij.cc"
        self.search_link = "https://zaluknij.cc/wyszukiwarka?phrase="
        self.useragent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0"
        self.headers2 = {
            'Referer': 'https://zaluknij.cc/',
            'user-agent': self.useragent,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3', }
        self.sess = requests.Session()

    def movie(self, imdb, title, localtitle, aliases, year):
        return self.search(title, localtitle, year, 'movie')

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        return self.search(tvshowtitle, localtvshowtitle, year, 'tvshow')

    def search(self, title, localtitle, year, type_):
        try:
            url = self.do_search(title, year, type_)
            if not url and localtitle:
                url = self.do_search(localtitle, year, type_)
            # Fix a title
            if not url:
                title = title[:-1]
                url = self.do_search(title, year, type_)
            if not url and localtitle:
                localtitle = localtitle[:-1]
                url = self.do_search(localtitle, year, type_)
            return url
        except Exception:
            pass

    def do_search(self, title, year, type_):
        search_url = f'{self.search_link}{title}'
        html = self.sess.get(search_url, headers=self.headers2, timeout=15, verify=False).text
        fout = []
        sout = []
        results = []
        out_url = ''
        links = parseDOM(html, 'div', attrs={'id': 'advanced-search'})[0]
        links = parseDOM(links, 'div', attrs={'class': r'col-sm-\d+'})
        for link in links:
            if 'href' in link:
                href = parseDOM(link, 'a', ret='href')[0]
                tytul = parseDOM(link, 'div', attrs={'class': 'title'})[0]
                if 'serial-online' in href or 'seasons' in href:
                    sout.append({'title': tytul, 'url': href})
                else:
                    fout.append({'title': tytul, 'url': href})
        if type_ == 'movie':
            results = fout
        if type_ == 'tvshow':
            results = sout
        results.sort(key=lambda k: len(k['title']), reverse=True)
        for url in results:
            date = ''
            if type_ == 'movie':
                date = str(url['url'])[-4:]
            if type_ == 'tvshow':
                html = self.sess.get(url['url'], headers=self.headers2, timeout=15, verify=False).text
                date = parseDOM(html, 'div', attrs={'class': 'info'})
                date = (parseDOM(date, 'li')[-1:])[0]
            if year and date.isnumeric():
                if (int(date) == int(year)):
                    out_url = url['url']
            else:
                out_url = url['url']
        return out_url

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        return self.search_ep(url, season, episode)

    def search_ep(self, url, season, episode):
        html = self.sess.get(url, headers=self.headers2, timeout=15, verify=False).text
        sesres = parseDOM(html, 'ul', attrs={'id': 'episode-list'})[0]
        sezony = re.findall(r'(<span>.*?</ul>)', sesres, re.DOTALL)
        episode_url = ''
        for sezon in sezony:
            sesx = parseDOM(sezon, 'span')
            ses = ''
            if sesx:
                mch = re.search(r'(\d+)', sesx[0], re.DOTALL)
                ses = mch[1] if mch else '0'
            eps = parseDOM(sezon, 'li')
            for ep in eps:
                href = parseDOM(ep, 'a', ret='href')[0]
                tyt2 = parseDOM(ep, 'a')[0]
                epis = re.findall(r's\d+e(\d+)', tyt2)[0]
                if int(ses) == int(season) and int(epis) == int(episode):
                    episode_url = href
        return episode_url

    def sources(self, url, hostDict, hostprDict):
        out = []
        html = self.sess.get(url, headers=self.headers2, timeout=15, verify=False).text
        source = []
        result = parseDOM(html, 'tbody')
        if result:
            result = result[0]
            videos = parseDOM(result, 'tr')
            for vid in videos:
                hosthrefquallang = re.findall(r'href\s*=\s*"([^"]+).*?<td>([^<]+).*?<td>([^<]+)', vid, re.DOTALL)
                for href, lang, qual in hosthrefquallang:
                    host = urlparse(href).netloc
                    out.append({'href': href, 'host': host, 'lang': lang, 'qual': qual})
            if out:
                for x in out:
                    host = x.get('host')
                    href = x.get('href')
                    lang = x.get('lang')
                    if href:
                        stream_url = href
                        if stream_url:
                            source.append({'source': host, 'quality': '720p', 'language': 'pl', 'url': stream_url,
                                           'info': lang, 'direct': False, 'debridonly': False})
        return source

    def resolve(self, url):
        return str(url).replace('\\/', '/')
