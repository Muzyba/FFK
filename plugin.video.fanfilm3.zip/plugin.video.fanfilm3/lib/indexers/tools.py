
import sys  # for sys.exit
from typing import Optional

from ..ff.routing import route, subobject, RouteObject
from ..ff.menu import directory
from ..ff.tmdb import tmdb
from ..ff.trakt2 import trakt
from ..ff.control import refresh, infoDialog, yesnoDialog, busy_section
from ..ff.db import state
from ..kolang import L
from .navigator import nav
from const import const


def yes_no(name: Optional[str] = None) -> bool:
    lines = [L(32056, 'Are you sure?')]
    if name is not None:
        lines.insert(0, name)
    return yesnoDialog(*lines)


class Cache(RouteObject):
    """Podmenu: /narzędzia/cache."""

    CLEAR_SOURCES_LABEL = L(30252, 'Clear cached source list')
    CLEAR_SEARCH_LABEL = L(30253, 'Clear search history')

    @route('/')
    def cache(self):
        with directory(view=const.indexer.tools.view, thumb='tools.png') as kdir:
            # kdir.action(32807, "clearCacheBookmarks")
            # kdir.action(32052, "clearCache")
            # kdir.action(32639, "clearCacheMeta")
            kdir.action(self.CLEAR_SOURCES_LABEL, self.clear_sources)  # sources, clearCacheProviders
            kdir.action(self.CLEAR_SEARCH_LABEL, self.clear_search)       # clearCacheSearch
            # kdir.action(32794, "clearCacheAll")

    @route
    def clear_sources(self) -> None:
        from ..ff import cache
        if yes_no(self.CLEAR_SOURCES_LABEL):
            with busy_section(complete_notif=True):
                cache.cache_clear_sources()
                cache.cache_clear_providers()

    @route
    def clear_search(self) -> None:
        from ..ff.db.db import db_manager
        if yes_no(self.CLEAR_SEARCH_LABEL):
            with busy_section(complete_notif=True):
                db_manager.remove_db('search')


class Tools(RouteObject):
    """Głowne menu FanFilm."""

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        with directory(view=const.indexer.tools.view) as kdir:
            kdir.action(L(32806, 'Settings'), nav.settings, thumb='tools.png')
            if tmdb.credentials():
                kdir.action(L(30183, 'TMDB: Revoke authorization'), self.tmdb_revoke, thumb='tmdb.png')
            else:
                kdir.action(L(30184, 'TMDB: Authorize'), self.tmdb_auth, thumb='tmdb.png')
            if trakt.credentials():
                kdir.action(L(30185, 'TRAKT: Revoke authorization'), self.trakt_revoke, thumb='trakt.png')
                if const.indexer.trakt.show_sync_entry:
                    kdir.action(L(30186, 'TRAKT: Synchronize'), self.trakt_sync, thumb='trakt.png')
            else:
                kdir.action(L(30187, 'TRAKT: Authorize'), self.trakt_auth, thumb='trakt.png')
            kdir.folder(L(30254, 'Cache'), self.cache, thumb='tools.png')

    @route('/tmdb/auth')
    def tmdb_auth(self) -> None:
        if tmdb.auth():
            infoDialog(L(30188, 'Authorization successful'), L(30189, '[FanFilm] TMDB authorization'), 'default')
        else:
            infoDialog(L(30190, 'Authorization FAILED'), L(30189, '[FanFilm] TMDB authorization'), 'ERROR')
        refresh()

    @route('/tmdb/revoke')
    def tmdb_revoke(self) -> None:
        if not tmdb.credentials or not yesnoDialog(L(32056, 'Are you sure?'), heading=L(30183, 'TMDB: Revoke authorization')):
            return
        if tmdb.unauth():
            infoDialog(L(30191, 'Revoke authorization successful'), L(30192, '[FanFilm] TMDB revoke authorization'), 'default')
        else:
            infoDialog(L(30193, 'Revoke authorization FAILED'), L(30192, '[FanFilm] TMDB revoke authorization'), 'ERROR')
        refresh()

    @route('/trakt/auth')
    def trakt_auth(self) -> None:
        if trakt.auth():
            infoDialog(L(30188, 'Authorization successful'), L(30194, '[FanFilm] Trakt.tv authorization'), 'default')
            state.add_job('service', 'trakt.sync', sender='plugin')
            refresh()
        else:
            infoDialog(L(30190, 'Authorization FAILED'), L(30194, '[FanFilm] Trakt.tv authorization'), 'ERROR')

    @route('/trakt/revoke')
    def trakt_revoke(self) -> None:
        if not trakt.credentials or not yesnoDialog(L(32056, 'Are you sure?'), heading=L(30185, 'TRAKT: Revoke authorization')):
            return
        if trakt.unauth():
            infoDialog(L(30191, 'Revoke authorization successful'), L(30195, '[FanFilm] Trakt.tv revoke authorization'), 'default')
        else:
            infoDialog(L(30193, 'Revoke authorization FAILED'), L(30195, '[FanFilm] Trakt.tv revoke authorization'), 'ERROR')
        refresh()

    @route('/trakt/sync')
    def trakt_sync(self) -> None:
        if not trakt.credentials:
            return
        status = trakt.sync()
        if status is not None:
            # TODO: notify about changed (True)?
            infoDialog(L(30196, 'Synchronize successful'), L(30197, '[FanFilm] Trakt.tv synchronize'), 'default')
        else:
            infoDialog(L(30198, 'Synchronize FAILED'), L(30197, '[FanFilm] Trakt.tv synchronize'), 'ERROR')

    @route('/colorpicker/open/{service}')
    def colorpicker(self, service: str, default: Optional[str] = None) -> None:
        from lib.ff.colorpicker import ColorPicker
        colorpicker = ColorPicker('ColorPicker.xml', default_color=default)
        colorpicker.run(service)
        sys.exit()

    @route('/colorpicker/save/{service}/{color}')
    def colorpicker_save(self, service: str, color: str) -> None:
        from lib.ff.colorpicker import ColorPicker
        colorpicker = ColorPicker('ColorPicker.xml')
        colorpicker.save_color(service, color)
        sys.exit()

    @subobject
    def cache(self) -> Cache:
        """Cache submenu."""
        return Cache()
