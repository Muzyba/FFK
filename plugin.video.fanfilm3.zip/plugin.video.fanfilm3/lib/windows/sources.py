import re
from datetime import datetime, timedelta
from html import unescape
from threading import Thread
from urllib.parse import unquote
from typing import Optional, Union, Any, List, Dict, TYPE_CHECKING

from xbmcgui import ListItem, Window
from xbmcgui import (
    ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN,
)

from ..ff.control import addonPath, run_plugin, settings, busy_dialog, close_busy_dialog
from ..ff.log_utils import fflog, fflog_exc
from ..ff import control
if TYPE_CHECKING:
    from ..ff.sources import sources as Sources, Item, SourceSearchQuery
    SourceItem = Item
    Meta = Item

from .base_window import BaseDialog, CANCEL_ACTIONS, MENU_ACTIONS
from .context import ContextMenu
from const import const

ITEM_LIST = 5000
NO_ITEMS_LABEL = 5001
RESCAN = 5005
EDIT_SEARCH = 5006


class RescanSources(Exception):
    """Force rescan sources again."""

    def __init__(self, *, query: Optional['SourceSearchQuery']) -> None:
        super().__init__()
        self.query: Optional['SourceSearchQuery'] = query


def endtime(minutes: Union[int, str]) -> str:
    if not minutes:
        return '–'
    end = datetime.now() + timedelta(minutes=int(minutes))
    return end.strftime("%H:%M")


def clear_source(source):
    return source.rsplit(".", 1)[0]


def format_info(label):
    try:
        return re.sub(r"(\d+(?:[.,]\d+)?\s*[GMK]B)", r"[COLOR ffffffff]\1[/COLOR]", label)
    except Exception:
        return label


class Panel(BaseDialog):

    XML = 'SourcesPanel.xml'

    def onAction(self, action):
        action_id = action.getId()
        fflog(f' ######### {action_id = }, {action = }')
        if action_id in CANCEL_ACTIONS:
            self.close()


class EditDialog(BaseDialog):

    XML = 'SourcesEdit.xml'
    CUSTIMZED_XML = True

    #: Edit controls (101..110):
    EDIT_CONTROLS = {
        101: 'localtitle',
        102: 'title',
        103: 'originalname',
        104: 'year',
        105: 'premiered',
        106: 'imdb',
        107: 'tmdb',
        108: 'tvshowtitle',
        109: 'season',
        110: 'episode',
    }

    SCAN_BUTTON = 31

    def __init__(self, *args, query: Dict[str, str], raise_rescan: bool = True, **kwargs):
        super().__init__(*args, **kwargs)
        self.raise_rescan = raise_rescan
        self.query = query
        if query.get('episode'):
            mtype = 'episode'
        else:
            mtype = 'movie'
        fflog(f' ... {mtype = }, {query = }')
        self.setProperty('search.media_type', mtype)

    def get_query(self) -> 'SourceSearchQuery':
        def value(ctl_id: int, key: str) -> Any:
            ctl = self.getControl(ctl_id)
            val = ctl.getText(ctl_id)
            if key in ('season', 'episode'):
                return int(val) if val else None
            if key in ('year',):
                return int(val or 0)
            return val

        return {key: value(ctl_id, key) for ctl_id, key in self.EDIT_CONTROLS.items()}

    def onInit(self) -> None:
        # ctl = self.getControl(5099)
        # ctl.setLabel('Dupa blada', 'font_tiny', '0xFF00FFFF')
        for ctl_id, key in self.EDIT_CONTROLS.items():
            ctl = self.getControl(ctl_id)
            ctl.setText(str(self.query.get(key) or ''))
        self.setFocus(self.getControl(self.SCAN_BUTTON))

    def onAction(self, action):
        action_id = action.getId()
        fflog(f' ######### {action_id = }, {action = }')
        if action_id in CANCEL_ACTIONS:
            self.close()

    def onClick(self, controlId: int) -> None:
        control_id = controlId
        if control_id == 31:  # Scan button.
            query = self.get_query()
            if self.raise_rescan:
                self.raise_exception(RescanSources(query=query))
            self.close(query)
        elif control_id == 32:  # Cancel button.
            self.close()


class SourceDialog(BaseDialog):

    XML = 'SourcesDialog.xml'

    def __init__(self, xmlFilename: Optional[str] = None, scriptPath: str = control.addonPath, *args,
                 sources: 'Sources', item: 'FFItem', items: List['SourceItem'], query: Dict[str, str],
                 edit_search: bool = False,
                 **kwargs) -> None:
        if xmlFilename is None:
            xmlFilename = self.XML
        fflog(f'WIN  {xmlFilename=}, {scriptPath=}, {args=}')
        super().__init__(xmlFilename, scriptPath, *args)
        self.sources: 'Sources' = sources
        self.item: 'FFItem' = item
        self.items: List['SourceItem'] = items
        self.lists = self.list_items(self.items)
        self.resolved = ''
        self.focused_constrol_id: int = 0
        self.query = dict(query)
        self._call_edit_search: bool = edit_search

    def doModal(self) -> str:
        super().doModal()
        if self.resolved:
            return self.resolved
        else:
            return 'empty'

    def onInit(self) -> None:
        default_color = settings.getString('default.color.identify2')
        duration_in_mins = int(self.item.vtag.getDuration() / 60)

        self.setProperty('item.title', str(self.item.title))
        self.setProperty('item.tvshowtitle', self.item.vtag.getTvShowTitle())
        self.setProperty('item.year', str(self.item.year))
        self.setProperty('item.season', str(self.item.season))
        self.setProperty('item.episode', str(self.item.episode))
        self.setProperty('item.duration', str(duration_in_mins) if duration_in_mins else '–')
        self.setProperty('item.art.poster', self.item.getArt('poster'))
        self.setProperty('item.art.fanart', self.item.getArt('fanart'))
        self.setProperty('item.endtime', endtime(duration_in_mins))
        self.setProperty('item.colored.default', default_color)
        self.setProperty('sources.edit_button', 'true' if const.sources_dialog.edit_search.in_dialog else 'false')
        self.setProperty('panel.visible', 'false')
        # colors MUST be set in known window, HOME is very know :-D
        home = Window(10000)
        home.setProperty('fanfilm.sources_dialog.info.index.color', const.sources_dialog.index_color)
        # items
        self.add_items(ITEM_LIST, self.lists)
        if self.lists:
            self.setProperty('noitem', 'false')
            self.getControl(NO_ITEMS_LABEL).setVisible(False)
            self.setFocus(self.getControl(ITEM_LIST))
        else:
            self.setProperty('noitem', 'true')
            self.setFocus(self.getControl(RESCAN))
        if self._call_edit_search:
            if not self.edit_search():
                self.close()  # force close on "back"

    def handle_source(self):
        try:
            busy_dialog()

            position = self.getControl(ITEM_LIST).getSelectedPosition()
            auto_select = settings.getBool('auto.select.next.item.to.play')

            if auto_select:
                for i in range(position, len(self.items)):
                    if resolved := self.sources.sourcesResolve(self.items[i]):
                        self.resolved = resolved
                        self.close()
                        break
            else:
                resolved = self.sources.sourcesResolve(self.items[position])

                if resolved:
                    self.resolved = resolved
                    self.close()
                else:
                    close_busy_dialog()
        except Exception:
            fflog_exc()

    def handle_rescan(self):
        self.close()
        url = f"{control.plugin_url}rescan/{self.item.dbid}"
        run_plugin(url)

    def handle_download(self):
        position = self.getControl(ITEM_LIST).getSelectedPosition()
        resolved = self.sources.sourcesResolve(self.items[position])
        if resolved:
            from lib.ff.downloader import download
            thread = Thread(target=download, args=(self.item.title, self.getProperty("item.art.poster"), resolved))
            thread.start()

    def handle_rebuy(self):
        position = self.getControl(ITEM_LIST).getSelectedPosition()
        resolved = self.sources.sourcesResolve(self.items[position], for_resolve={"buy_anyway": True})
        if resolved:
            self.resolved = resolved
            self.close()

    def edit_search(self) -> bool:
        if query := EditDialog(query=self.query, raise_rescan=False).doModal():
            self.raise_exception(RescanSources(query=query))
            self.close()
            return True
        return False

    def onClick(self, controlId: int) -> None:
        control_id = controlId
        if control_id == ITEM_LIST:
            self.handle_source()
        elif control_id == RESCAN:
            if const.sources_dialog.rescan_edit:
                self.edit_search()
            else:
                self.handle_rescan()
        elif control_id == EDIT_SEARCH:
            self.edit_search()

    def onAction(self, action):
        action_id = action.getId()
        fflog(f' ######### {action_id = }, {action = }')
        if action_id in CANCEL_ACTIONS:
            self.close()
        elif action_id in MENU_ACTIONS:
            context_menu_items = []
            if settings.getBool("downloads"):
                context_menu_items.append((control.lang(30115), self.handle_download))
            item_no = self.getControl(ITEM_LIST).getSelectedPosition()
            provider = self.lists[item_no].getProperty("item.provider")
            if provider == "tb7" or provider == "xt7":
                context_menu_items.append((control.lang(30116), self.handle_rebuy))
            if len(context_menu_items) >= 1:
                ContextMenu("ContextMenu.xml", addonPath).open(context_menu_items)
        # elif self.focused_constrol_id == ITEM_LIST and action_id == ACTION_MOVE_LEFT:
        #     Panel().doModal()

    def onFocus(self, controlId: int) -> None:
        control_id = controlId
        self.focused_constrol_id = control_id
        fflog(f' ######### {control_id = }')
        if control_id == 5011:
            # self.setProperty('panel.visible', 'true')
            Panel().doModal()
            self.setFocusId(ITEM_LIST)

    def list_items(self, items):
        return [self.create_list_item(item) for item in items]

    def create_list_item(self, item):
        source = clear_source(item['source'])

        fflog(f'[WINDOWS]:  {item=}')
        li = ListItem(label=item['label'])
        li.setProperty('item.info', format_info((item.get('info') or '–––').strip()))
        li.setProperty('item.source', source)
        li.setProperty('item.colored', item.get('color_identify'))
        li.setProperty('item.colored.default', settings.getString("default.color.identify2"))

        if item.get('on_account'):
            li.setProperty('item.on_account_expires', item.get('on_account_expires') if item.get('on_account_expires') else 'konto')

        for key in ["provider", "url", "info2", "language", "quality"]:
            if item.get(key) is None:
                fflog(f'[WINDOWS]: ERORR: No key {key!r} in item {item!r} !!!')
            li.setProperty(f"item.{key}", (item.get(key) or '').strip())

        if not li.getProperty('item.info2'):
            li.setProperty('item.info', li.getProperty('item.info').lstrip('| '))

        if settings.getBool("sources.filename_in_2nd_line"):
            filename = item.get("filename")
            if filename:
                filename = unescape(unquote(filename))
            li.setProperty('item.id', filename)

        if settings.getBool('icon.external') and (icon := item.get('icon')):
            li.setProperty('item.icon', icon)
        return li

# Fonts:
#   - title / heading: ~40, font40_title (Estuary), font38_title/font40 (Eestouchy), font_topbar (AH2R)
