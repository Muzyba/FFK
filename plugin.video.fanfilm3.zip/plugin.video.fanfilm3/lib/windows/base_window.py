from typing import Optional, Union, Any, Tuple, Dict, Sequence, Callable, Type, NamedTuple, ClassVar, TYPE_CHECKING
import re
from threading import Thread, Condition
from queue import Queue
from pathlib import Path
from attrs import frozen, field
from wrapt.wrappers import ObjectProxy
from xbmc import getSkinDir
from xbmcgui import WindowXML, WindowXMLDialog, ControlList
from xbmcgui import (
    ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_STOP, ACTION_NAV_BACK,
    ACTION_MOUSE_RIGHT_CLICK, ACTION_MOUSE_LONG_CLICK, ACTION_CONTEXT_MENU,
)
from ..ff import control
from ..ff.tricks import MISSING
from ..ff.log_utils import fflog, fflog_exc
if TYPE_CHECKING:
    from xbmcgui import ListItem


Args = Tuple[Any, ...]
KwArgs = Dict[str, Any]

#: Actions (keys) to close / cancel / escape.
CANCEL_ACTIONS = {
    ACTION_PARENT_DIR,
    ACTION_PREVIOUS_MENU,
    # ACTION_PAUSE,
    ACTION_STOP,
    ACTION_NAV_BACK,
}

#: Actions (keys) for context-menu.
MENU_ACTIONS = {
    ACTION_MOUSE_RIGHT_CLICK,
    ACTION_MOUSE_LONG_CLICK,
    ACTION_CONTEXT_MENU,
}


@frozen
class SkinDescr:
    id: str
    font: Dict[str, str] = field(factory=dict)


DEFAULT_SKIN = SkinDescr('',
                         font={'heading': 'heading'},
                         )

SKINS: Dict[str, SkinDescr] = {skin.id: skin for skin in (
    SkinDescr('skin.estuary',
              font={
                  'heading': 'font40_title',
                  'small': 'font10',
              },
              ),
    SkinDescr('skin.arctic.zephyr.2.resurrection.mod',
              font={
                  'heading': 'font_title',
                  'small': 'font_tiny',
              },
              ),
)}

#: Regex for set <font>.
RX_FONT = re.compile(r'(<font\s+(?:"[^"]*"|(?!ff:style)[^>])*\bff:style="([^"]*)"(?:"[^"]*"|(?!ff:)[^>])*>)([^<]*)(</font>)')


class WindowCommand(NamedTuple):
    method: Callable
    args: Args
    kwargs: KwArgs


class WindowThread(Thread):
    """Thread to call window's doModal() in thread (non blocking)."""

    def __init__(self,
                 win_class: Type,
                 name: Optional[str] = None,
                 args: Args = (),
                 kwargs: KwArgs = {},  # noqa: B006
                 ) -> None:
        super().__init__(name=name)
        #: Window class to create the window.
        self.win_class: Type = win_class
        #: Arguments for window create.
        self.args: Args = args
        #: Keyword arguments for window create.
        self.kwargs: KwArgs = kwargs
        #: The window.
        self.win: WindowXML = None
        #: Thread condition variable for window creation.
        self.win_ready = Condition()
        #: Window commands (doModal) queue.
        self.win_commands = Queue()

    def run(self) -> None:
        """Do job. Main thread proc."""
        fflog(f'••• [TH] create win {self.win_class}, {self.args}, {self.kwargs}')
        self.win = self.win_class(*self.args, **self.kwargs)
        try:
            fflog('••• [TH] notify')
            with self.win_ready:
                self.win_ready.notify()
            while True:
                fflog('••• [TH] wait for command')
                cmd: WindowCommand = self.win_commands.get()
                fflog(f'••• [TH] {cmd=}')
                if not cmd:
                    break
                cmd.method(*cmd.args, **cmd.kwargs)
                self.win_commands.task_done()
        finally:
            fflog('••• [TH] close')
            self.win.close()
        fflog('••• [TH] finished')

    def command(self, method: Callable, *args, **kwargs) -> None:
        """Postpone window method call."""
        self.win_commands.put(WindowCommand(method, args, kwargs))


class _WindowMetaClass(type):
    """Base Window meta-class to modify __init__ arguments."""

    def __call__(self, *args, **kwargs):
        return super().__call__(*args, **kwargs).__wrapped__


class AbstractWindow:

    XML: ClassVar[str] = ''
    CUSTIMZED_XML: ClassVar[bool] = False

    if TYPE_CHECKING:
        _customised_xml: bool

    @classmethod
    def _resolve_args(cls,
                      xmlFilename: Optional[str] = None,
                      scriptPath: Optional[str] = None,
                      defaultSkin: Optional[str] = None,
                      defaultRes: Optional[str] = None,
                      ) -> Tuple[str, str, str, str, Path]:
        if xmlFilename is None:
            xmlFilename = cls.XML
        if scriptPath is None:
            scriptPath = control.addonPath
        if defaultSkin is None:
            defaultSkin = 'Default'
        if defaultRes is None:
            defaultRes = '1080i'  # kodi default: 720p
        path = Path(scriptPath) / 'resources' / 'skins' / defaultSkin / defaultRes / xmlFilename
        return xmlFilename, scriptPath, defaultSkin, defaultRes, path


class BaseWindow(AbstractWindow, WindowXML):

    def __new__(cls,
                xmlFilename: Optional[str] = None,
                scriptPath: str = control.addonPath,
                defaultSkin: str = 'Default',
                defaultRes: str = '1080i',  # '720p',
                *args,
                **kwargs) -> 'BaseWindow':
        xmlFilename, scriptPath, defaultSkin, defaultRes, xml_path = cls._resolve_args(xmlFilename, scriptPath, defaultSkin, defaultRes)
        if customized_xml := kwargs.pop('customized_xml', cls.CUSTIMZED_XML):
            _cutomize_xml(xml_path)
        obj = super().__new__(cls, xmlFilename, scriptPath, defaultSkin, defaultRes, *args)
        obj.__init__(xmlFilename, scriptPath, defaultSkin, defaultRes, *args, **kwargs)
        obj._customised_xml = customized_xml
        return ObjectProxy(obj)  # to avoid __init__ call, _WindowMetaClass will remove ObjectProxy

    def add_items(self, control_id: int, items: Sequence[Union[str, 'ListItem']]) -> None:
        control = self.getControl(control_id)
        if isinstance(control, ControlList):
            control.reset()
            control.addItems(items)  # type: ignore - ControlList.addItems() accepts Sequence[]

    def onClosing(self) -> None:
        """Custom function called when window goint to close."""

    def onClose(self) -> None:
        """Custom function called on window close."""

    def close(self) -> None:
        self.onClosing()
        super().close()
        self.onClose()


class BaseDialog(AbstractWindow, WindowXMLDialog):

    if TYPE_CHECKING:
        _result: Any
        _exception: Optional[BaseException]
        _closed: bool
        _thread: Optional[WindowThread]

    def __new__(cls,
                xmlFilename: Optional[str] = None,
                scriptPath: Optional[str] = None,
                defaultSkin: Optional[str] = None,
                defaultRes: Optional[str] = None,
                *args,
                modal: bool = True,
                _call_init: bool = True,
                **kwargs) -> 'BaseDialog':
        fflog(f'BaseDialog.__new__({cls=}, {xmlFilename=}, {scriptPath=}, {defaultSkin=}, {defaultRes=}, {args=}, {modal=}, {_call_init=}, {kwargs=})')
        xmlFilename, scriptPath, defaultSkin, defaultRes, xml_path = cls._resolve_args(xmlFilename, scriptPath, defaultSkin, defaultRes)
        if customized_xml := kwargs.pop('customized_xml', cls.CUSTIMZED_XML):
            _cutomize_xml(xml_path)
        if not modal:
            # for non-blocking dialogs, window is created in thread
            th: WindowThread = WindowThread(super().__new__, args=(cls, xmlFilename, scriptPath, defaultSkin, defaultRes, *args))
            fflog(f'••• start thread {th}')
            th.start()
            with th.win_ready:
                if not th.win:
                    fflog('••• wait for window')
                    th.win_ready.wait()
            obj = th.win
            obj._thread: WindowThread = th
        else:
            obj = super().__new__(cls, xmlFilename, scriptPath, defaultSkin, defaultRes)
            obj._thread: WindowThread = None
        obj._closed = False
        obj._result = None
        obj._exception = None
        obj._customised_xml = customized_xml
        if _call_init:
            fflog('••• init')
            obj.__init__(xmlFilename, scriptPath, defaultSkin, defaultRes, *args, **kwargs)
        fflog('••• created')
        return ObjectProxy(obj)  # to avoid __init__ call, _WindowMetaClass will remove ObjectProxy

    def __init__(self, *args, **kwargs) -> None:
        """Useless, because WindowXMLDialog uses __new__ only."""
        pass

    def onClosing(self) -> None:
        """Custom function called when window goint to close."""

    def onClose(self) -> None:
        """Custom function called on window close."""

    def raise_exception(self, exception: BaseException) -> None:
        """Set exception to raise from doModal()."""
        self._exception = exception

    def close(self, result: Any = MISSING) -> None:
        self._closed = True
        if result is not MISSING:
            self._result = result
        self.onClosing()
        if self._thread:
            fflog('••• postpone exit')
            self._thread.win_commands.put(None)
        fflog('••• close')
        super().close()
        fflog('••• onClose')
        self.onClose()
        fflog('••• finished')

    def doModal(self) -> Any:
        """Ececute the window. Call doModal direct (modal) or in thread (modeless)."""
        if self._thread:
            self.show()
            fflog(f'••• postopne {self.doModal}')
            self._thread.command(super().doModal)
            fflog(f'••• snet {self.doModal}')
        else:
            super().doModal()
        if not self._closed:
            self._closed = True
            self.onClose()
        if self._exception:
            raise self._exception
        return self._result

    def is_modal(self) -> bool:
        """Return True if dialog is modal."""
        return not self._thread

    def destroy(self) -> None:
        """Close and clean up."""
        self.close()
        if self._thread:
            self._thread.join()

    def add_items(self, control_id: int, items: Sequence[Union[str, 'ListItem']]) -> None:
        control = self.getControl(control_id)
        if isinstance(control, ControlList):
            control.reset()
            control.addItems(items)  # type: ignore - ControlList.addItems() accepts Sequence[]


def _cutomize_xml(xml_path: Path) -> None:
    """Fix window/dialog source XML to handle what kodi can not."""
    def repl(mch: re.Match) -> str:
        open, style, value, close = mch.groups()
        font = skin.font.get(style, style)
        return f'{open}{font}{close}'

    skin_id = getSkinDir()
    skin = SKINS.get(skin_id, DEFAULT_SKIN)
    try:
        xml = xml_path.read_text()
        xml = RX_FONT.sub(repl, xml)
        xml_path.write_text(xml)
    except IOError:
        fflog_exc()


