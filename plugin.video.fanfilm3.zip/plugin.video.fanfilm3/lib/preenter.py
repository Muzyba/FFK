"""Some stuff to do berfore main() is called."""

from pathlib import Path
from const import const


if const.debug.autoreload:
    from .service.reload import ReloadMonitor
    ffpath: Path = Path(__file__).parent
    reload_monitor = ReloadMonitor([
        ffpath / '*.py',
        ffpath / 'ff/**',
        ffpath / 'api',
        ffpath / 'indexers',
        ffpath / 'sources',
        ffpath / 'windows',
    ])
else:
    reload_monitor = None


def preinit():
    """Run on begeining, before run count."""
    if reload_monitor:
        reload_monitor.check()


def premain():
    """Run just before main."""
